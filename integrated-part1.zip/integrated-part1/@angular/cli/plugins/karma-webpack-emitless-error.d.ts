export declare class KarmaWebpackEmitlessError {
    constructor();
    apply(compiler: any): void;
}
