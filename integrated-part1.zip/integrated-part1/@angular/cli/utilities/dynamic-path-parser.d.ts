export declare function dynamicPathParser(project: any, entityName: string, appConfig: any): {
    appRoot: string;
    sourceDir: any;
    root: string;
    dir: string;
    base: string;
    ext: string;
    name: string;
};
