
	/* DO NOT EDIT. THIS FILE IS GENERATED */
	export const builddate = "Fri Jun 30 2017 12:38:47 GMT-0700 (Pacific Daylight Time)";
	