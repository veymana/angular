/**
 * environment.ts
 * 
 * This is the DEVELOPMENT (NON_PRODUCTION) configuration file.
 * 
 * Production configuration file is environment.prod.ts
 * 
 */
import { builddate } from './builddate';
import {
    ISettingsRest,
    ISettingsWebSockets,
    ISettingsInactivity,
    ISettingsErrorSinkConfig,
    ISettingsPopupServiceConfig,
    ISettingsFlowServiceConfig,
    ISettingsBroswerConfig,
    ISettingsLanguageConfig,
    ISettingsDmsConfig,
    ISettingsStartupConfig,
    ISettingsGlobalNavigationConfig
} from './interfaces';

import { JumpStartKitFlowService } from 'core/jump-start-kit/services/jump-start-kit-flow.service';

/** NEVER EDIT environment const! */
export const environment: any = {
    production: false,
    buildDate: builddate || "ERROR: PLEASE RUN THE BUILD SCRIPT!"
};

// FlowService flow
import * as FLOWS from '#compiled-data/flows.json';

/* Language Settings */
import * as EN from '#compiled-data/language/en.json';
// A factory must be used since AOT needs an exports {StaticSymbol} object.
export function LANGUAGE_CONFIG_FACTORY(): ISettingsLanguageConfig {
    return {
        defaultLanguage: "en",
        notFoundPrefix: "NOTFOUND_",
        prefix: "K_",
        languageDefinitions: {
            en: EN
        },
        commonResolutions: {
            applicationName: AppSettings.APP_NAME
        }
    };
}

/**
 * Defines Application Settings
 */
export class AppSettings {

    /**
     * Application Information
     * 
     * @static
     * @type {string}
     * @memberOf AppSettings
     */
    public static readonly APP_NAME: string = 'One Interface JSK (NON PRODUCTION!)';

    /**
     * Version information
     * This version usually is the release number.
     * 
     * @static
     * @type {string}
     * @memberOf AppSettings
     */
    public static readonly VERSION: string = "3.17";

    /**
     * Company information
     * 
     * @static
     * @type {string}
     * @memberOf AppSettings
     */
    public static readonly COMPANY: string = "Wells Fargo";

    /**
     * Used to match functionIdentifier1 based on /user REST call.
     * 
     * @static
     * @type {"UIAUTH"}
     * @memberof AppSettings
     */
    public static readonly FUNCTION_IDENTIFIER_1: string = "UIAUTH";

    /**
     * Application ID (functionIdentifier2)
     * Used for matching with authorized application based on /user REST call.
     * 
     * @static
     * @type {"STGDIR"}
     * @memberof AppSettings
     */
    public static readonly APPID: string = "STGDIR";

    /**
     * Startup info primarily used for logging.
     * 
     * @readonly
     * @static
     * @type {string}
     * @memberOf AppSettings
     */
    public static get STARTUPINFO(): string {
        return `${AppSettings.APP_NAME} Version ${AppSettings.VERSION} - Copyright © ${new Date().getFullYear()} - ${AppSettings.COMPANY} - [Build ${AppSettings.VERSION} - ${environment.buildDate}]`;
    }

    /**
     * REST Service Configuration
     * 
     * @static
     * @type {ISettingsRest}
     * @memberOf AppSettings
     */
    public static REST: ISettingsRest = {

        // Service EndPoints
        // use keyword "[[relative]]" to make endpoint relative to <base href> of the <head> tag
        endPoints: {
            default: "http://localhost:4200",
            assetsData: "assets/data",
        },
        resource: {
            appLogger: {
                name: "AppLogger",
                resource: "tabletlog",
                timeout: 5 * 1000
            },
            interactions: {
                name: "Interactions",
                resource: "api/v1.0/interactions"
            },
            interaction: {
                name: "Interaction",
                resource: "api/v1.0/interaction",
                timeout: 2 * 60 * 1000,
                isTickFirst: false,
                retryCount: 2
            },
            customer: {
                name: "Customer",
                resource: "customer"
            },
            customers: {
                name: "Customers",
                resource: "customers"
            },
            reasons: {
                name: "VisitReasons",
                resource: "visitreasons"
            },
            bankers: {
                name: "Bankers",
                resource: "bankers",
                isCacheToNative: true
            },
            appointmentsByEmailAddress: {
                name: "Appointments",
                resource: "api/v1.0/appointments"
            },
            appointmentsByStoreAU: {
                name: "Appointments",
                resource: "appointments" //this rest service is not SCC component and hence host do not require api/v1.0
            },
            user: {
                name: "User",
                resource: "user",
                timeout: 15 * 1000
            },
            terminateSession: {
                name: "TerminateSession",
                resource: "terminatesession",
                timeout: 30 * 1000
            },
            dms: {
                name: "DeviceManagementService",
                resource: "",
                endPoint: "http://sp080d21d7abb31.ent.wfb.bank.corp:8095/dms"
            },
            inactivitycheck: {
                name: "InactivityCheck",
                resource: "inactivitycheck",
                timeout: 20 * 2 * 1000
            },
            branchconfig:
            {
                name: "BranchConfig",
                resource: "branchconfig",
                isCacheToNative: false
            }
        },
        commonHeaders: {
            "Content-Type": "application/json; charset=utf-8",
            "WF-User-Session-ID": null, // Set by restclientbase
            "WF-Session-ID": null, // Set by restclientbase
            "WF-Initiator-ID": null, // Set by restclientbase
            "WF-Initiator-Type": "TABLET",
            "WF-Initiator-Version": AppSettings.VERSION,
            "WF-Message-ID": null
        },
        // Rest Timeout (in milliseconds)
        defaultTimeout: 60 * 1000
    };

    /**
     * WEBSOCKETS configuration
     * 
     * @static
     * @type {ISettingsWebSockets}
     * @memberOf AppSettings
     */
    public static readonly WEBSOCKETS: ISettingsWebSockets = {
        /**
         * Since WebSockets do NOT have an onConnect/Open callback on failure, we need
         * to check status after a period of time. When connecting, after this period,
         * if connection is successful, websocket readyState should be OPEN (websocket.OPEN constant)
         */
        checkReadyStateInMs: 2000,

        /** 
         * On Connection failure, attempt to reconnect after this.
         * A value of 0 (zero) will cause immediate reconnect.
         * A negative value will disable reconnect.
         * Can be overridden by the WebSocketDefinition class.
         */
        retryDurationInMs: 2000,
        connections: {
            queue: {
                base: "[[relative]]",
                path: "/websocket/events",
                relativeTo: AppSettings.REST.endPoints.default,
                isCacheToNative: false,
                isRetryOnConnectionFailure: true,
                retryDurationInMs: 2000
            }
        }
    };

    /**
     * INACTIVITY service configuration
     * 
     * @static
     * @type {ISettingsInactivity}
     * @memberOf AppSettings
     */
    public static readonly INACTIVITY: ISettingsInactivity = {
        isLogRemainderToConsole: false,
        warningInSeconds: 2 * 60,  // Warning will fire this number of seconds before timeout.
        timeoutInSeconds: 15 * 60, // Timeout will fire (user will be logged off)

        // NOTE on inactivity durations.
        // Warning in seconds will fire this number of seconds before timeout is fired.
        // So if timeout is 100 seconds, and warning is 10 seconds, warning will fire at 90 seconds (100-90)
        // After warning is reached, if user does not react, user will be logged off after 10 seconds (waningInSeconds).
        // So, timeoutInSeconds is the ENTIRE duration in which user will be logged off if the user does not react after the warning.

        ignoredKeys: [
            // Some keys may be needed to ignore such as those keys sent programmatically (like volume keys)
            // You can either use keycodes, or actual keys.
            // For example, you can use 32 (must be NUMBER) or "SPACE" (MUST BE STRING) or actual " " for space.
            // You can also use "KeyA" or "A" for the letter A on the keyboard input.
            // For getting the keyboard code, I always use http://keycode.info ;) -Lucky

            "NUMLOCK",
            174, // VOLUME DOWN
            175  // VOLUME UP
        ],
        eventsToMonitor: [
            'keydown',
            'mousedown',
            'touchstart',
            'dragstart',
            'click'
        ]
    };

    /**
     * ErrorSink Service configuration
     * 
     * @static
     * @type {ISettingsErrorSinkConfig}
     * @memberOf AppSettings
     */
    public static readonly ErrorSinkConfig: ISettingsErrorSinkConfig = {
        rethrowError: true,
        stacktraceMaxLines: 7
    };


    /**
     * Named router-Outlet for the popups.
     * 
     * @static
     * @type {ISettingsPopupServiceConfig}
     * @memberOf AppSettings
     */
    public static readonly PopupServiceConfig: ISettingsPopupServiceConfig = {
        route: "popup",
        outlet: "overlay"
    };

    /**
     * FlowService Settings
     * 
     * @static
     * @type {ISettingsFlowServiceConfig}
     * @memberof AppSettings
     */
    public static readonly FlowServiceSetting: ISettingsFlowServiceConfig = {
        possibleDataLossCallback: JumpStartKitFlowService.onPossibleDataLossEntryCallback,
        flows: FLOWS
    };

    /**
     * Browser configurable options.
     * Set to false to disable.
     * Set to a Function to create an event handler.
     * Set to true (or remove/unset) setting to keep default.
     * 
     * the property keys are the eventNames that will be hooked to the document.body.
     * For example,
     * ...
     * contextmenu: false
     * This will add a oncontextmenu=function(){return false;} to the document.body to disable contex menus.
     * Another example:
     * contextmenu: () => { alert("stop right clicks!") } 
     * 
     * @static
     * @type {ISettingsBroswerConfig}
     * @memberof AppSettings
     */
    public static readonly BrowserConfig: ISettingsBroswerConfig = {
        contextmenu: true,
        copy: true,
        cut: true,
        paste: true
    };

    /**
      * Matches /user functionIdentifier2
      * 
      * @static
      * @type {{ [key: string]: string[] }}
      * @memberof AppSettings
      */
    public static readonly UrlToFunctionIdentifier2Mapping: { [key: string]: string[] } = {
        "selectreason": [
            "ADDAPPT",
            "EDTAPPT",
            "CLMCUST",
            "DELCUST"
        ],
        "listappointments": [
            "ADDAPPT",
            "EDTAPPT",
            "CLMCUST",
            "DELCUST"
        ]
    };

    /**
     * Language Module configuration factory
     * 
     * @static
     * @type {any}
     * @memberof AppSettings
     */
    public static readonly LanguageConfigFactory: any = LANGUAGE_CONFIG_FACTORY;


    /**
     * DMS Settings
     * 
     * @static
     * @type {ISettingsDmsConfig}
     * @memberof AppSettings
     */
    public static DeviceManagentServiceConfig: ISettingsDmsConfig = {
        timeouts: {
            cardrdr: {
                getInfo: 500,
                read: 2 * 60 * 1000
            }
        }
    };

    /**
     * Startup Service settings
     * 
     * @static
     * @type {ISettingsStartupConfig}
     * @memberof AppSettings
     */
    public static StartupConfig: ISettingsStartupConfig = {
        requiredQueryParams: [
            "storeau",
            "computername"
        ]
    };

    /**
         * Global Navigation Settings
         * 
         * @static
         * @type {ISettingsGlobalNavigationConfig}
         * @memberof AppSettings
         */
    public static GlobalNavigationConfig: ISettingsGlobalNavigationConfig = {
        isCheckFlowBeforeNavigatingToLink: true,
        fallbackApplicationList: [
            {
                id: "a35fb089-1487-435f-a4d0-0e10446535de",
                displayOrder: 1,
                name: "Teamworks",
                category: "enterprise",
                icon: {
                    color: "#BB0826"
                },
                isShow: true,
                isExternal: true,
                text: "Teamworks",
                url: "http://portal.teamworks.wellsfargo.com",
                functionId: "_OPEN_",
                isAuthorized: true
            }
        ]
    };
}

