import { IWebSocketDefinition } from 'core/web-socket.service';
import { RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import { IApplicationLink } from 'core/global-navigation/models';

export interface IRestDetail {
    name: string;
    resource: string;
    isCacheToNative?: boolean;
    timeout?: number;
    endPoint?: string;
    requestOptions?: RequestOptions;
    isTickFirst?: boolean;
    retryCount?: number;
    resolvedUrl?: string;
}

/**
 * Settings for REST Endpoints
 * 
 * @export
 * @interface ISettingsRest
 */
export interface ISettingsRest {
    /**
     * List of Endpoints
     * 
     * @type {({
     *         default: string | "[[relative]]";
     *         [key: string]: string | "[[relative]]"
     *     })}
     * @memberof ISettingsRest
     */
    endPoints: {
        /**
         * The default endpoint for ALL rest services.
         * Can be overridden by the specific resource (IRestDetail)
         * Keywords: Use [[relative]] to use the endpoint relative to <base href>
         * @type {(string | "[[relative]]")}
         */
        default: string | "[[relative]]";
        [key: string]: string | "[[relative]]"
    },
    resource: {
        [key: string]: IRestDetail
    },
    commonHeaders: any,
    defaultTimeout: number
};

export interface ISettingsWebSockets {
    checkReadyStateInMs: number,
    retryDurationInMs: number,
    connections: { [key: string]: IWebSocketDefinition }
}

export interface ISettingsInactivity {
    isLogRemainderToConsole?: boolean,
    warningInSeconds: number,
    timeoutInSeconds: number,
    ignoredKeys: any[],
    eventsToMonitor: string[]
}

export interface ISettingsErrorSinkConfig {
    rethrowError: boolean,
    stacktraceMaxLines: number
}

export interface ISettingsPopupServiceConfig {
    outlet: string;
    route: string;
}

export interface ISettingsFlowServiceConfig {
    /**
     * If set, a callback will be called whenever FlowService detects
     * a scenario where data loss may occur.
     * The promise or Observable must emit/resolve a boolean value. True means continue, false otherwise.
     * @memberof ISettingsFlowServiceConfig
     */
    possibleDataLossCallback?: () => (Promise<boolean> | Observable<boolean>);
    readonly flows: any;
}

/**
 * Interface for AppSetting.BrowserConfig
 * 
 * @export
 * @interface ISettingsBroswerConfig
 */
export interface ISettingsBroswerConfig {
    // /**
    //  * Set to false to disable or set value to a function that will be invoked.
    //  * 
    //  * @type {(boolean | Function)}
    //  * @memberof ISettingsBroswerConfig
    //  */
    // contextmenu?: boolean | Function;
    // /**
    // * Set to false to disable or set value to a function that will be invoked.
    // * 
    // * @type {(boolean | Function)}
    // * @memberof ISettingsBroswerConfig
    // */
    // copy?: boolean | Function;
    // /**
    //  * Set to false to disable or set value to a function that will be invoked.
    //  * 
    //  * @type {(boolean | Function)}
    //  * @memberof ISettingsBroswerConfig
    //  */
    // cut?: boolean | Function;
    // /**
    //  * Set to false to disable or set value to a function that will be invoked.
    //  * 
    //  * @type {(boolean | Function)}
    //  * @memberof ISettingsBroswerConfig
    //  */
    // paste?: boolean | Function;

    [key: string]: boolean | Function;
}

export interface ISettingsLanguageConfig {
    defaultLanguage: "en" | string;
    notFoundPrefix?: "U2P" | string;
    prefix: "K_" | string;
    languageDefinitions: {
        [languageKey: string]: any
    };
    commonResolutions?: { [resolutionkey: string]: any; };
}

export interface ISettingsDmsConfig {
    /**
     * Specific timeout per call in ms
     * @example
     * cardrdr: {
     *  getInfo: 1000,
     *  read: 2*60*1000
     * }
     * 
     * @type {{ [key: string]: { [key: string]: number; } }}
     * @memberof ISettingsDmsConfig
     */
    timeouts: { [key: string]: { [key: string]: number; } }
}

/**
 * StartupService settings
 * 
 * @export
 * @interface ISettingsStartup
 */
export interface ISettingsStartupConfig {
    requiredQueryParams: string[];
}


/**
 * Global Navigation Settings
 * 
 * @export
 * @interface ISettingsGlobalNavigationConfig
 */
export interface ISettingsGlobalNavigationConfig {
    // If this is true, before navigating to another app/link,
    // a confirmation popup will be shown to the user if the user is in
    // the middle of a flow.
    isCheckFlowBeforeNavigatingToLink?: boolean;
    fallbackApplicationList: Array<IApplicationLink>;
}