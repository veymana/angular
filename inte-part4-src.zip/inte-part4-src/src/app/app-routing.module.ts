import { BlankboardComponent } from './shared/blankboard/blankboard.component';
import { Tv2Component } from './tv2/tv2.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes, ExtraOptions } from '@angular/router';
import { AppComponent } from './app.component';
import { AuthorizationGuardsAndResolves } from 'core/authorization-guards-and-resolves.service';
import { RouterEventsService } from 'core/router-events.service';
import { environment } from '#environments/environment';


import { PopupComponent } from '#shared/popup';

import { JumpStartKitFlowService } from 'core/jump-start-kit/services/jump-start-kit-flow.service';
import { CardReader } from 'core/dms/devices/card-reader';
import { DeviceManagementService } from 'core/dms/device-management.service';
import { QueueComponent } from "./oneui/queue/queue/queue.component";

const extraOptions: any = {
  enableTracing: !environment.production,
  useHash: true
};

const routes: Routes = [

  { path: 'tv', component: Tv2Component, outlet: 'tv' },
  { path: 'cashbox', component: BlankboardComponent, outlet: 'cashbox' },

  {
    path: '**',
    redirectTo: '/',
  }
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
