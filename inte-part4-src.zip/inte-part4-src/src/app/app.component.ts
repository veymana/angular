import { Component, OnInit, OnDestroy, ViewChild, Renderer, ElementRef, HostListener, AfterViewInit, AfterViewChecked, NgZone, ChangeDetectorRef } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/throttleTime';
import 'rxjs/add/observable/fromEvent';
import { Router, RouterOutlet } from '@angular/router';
import { UsageTrackingService } from './oneui/usage-tracking/usage-tracking.service';
import { UserService } from './oneui/core/user.service';
import { QueueService } from './oneui/queue/queue.service';
import { User } from './oneui/shared/user.model';
import { JumpStartKitFlowService } from 'core/jump-start-kit/services/jump-start-kit-flow.service';
import { IFlowMeta } from 'core/flow/models/interfaces';
import { RouterEventsService } from 'core/router-events.service';
import { AppSettings } from '#environments/environment';

import { HeaderService } from 'core/services';

import { QueueEntries, IGroupedQueueEntries } from 'app/oneui/queue/models';
import { BaseComponent } from 'core/base/base.component';

import { UtilsService } from 'core/utils.service';

import { ButtonModule } from 'primeng/primeng';
import { TellerFlowService } from "./common/teller-flow.service";

@Component({
  selector: 'main-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent extends BaseComponent implements OnInit, AfterViewChecked, AfterViewInit {
  @ViewChild(RouterOutlet)
  private defaultRouterOutlet: RouterOutlet;


  user: User;
  userSubscription: Subscription;

  private flowSubscription: Subscription;

  public name: string = "AppComponent";


  public headerMinimized: boolean = false;
  display: boolean = true;

  constructor(private router: Router,
    private userService: UserService,
    private usageTrackingService: UsageTrackingService,
    private tellerFlowService: TellerFlowService,

  ) {
    super(tellerFlowService);
  }



  ngOnInit(): void {

    this.tellerFlowService
  }

  ngOnDestroy(): void {
    this.usageTrackingService.logInteraction(null, 'APPLICATION_CLOSE', null);
    this.usageTrackingService.destroy();
    this.userSubscription.unsubscribe();
    this.flowSubscription.unsubscribe();
    this.scrollSubscription.unsubscribe();
  }


}


