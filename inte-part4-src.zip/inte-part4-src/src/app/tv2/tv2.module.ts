import { BlankboardComponent } from './../shared/blankboard/blankboard.component';
import { Tv2Service } from './tv2.service';
import { Tv2Component } from './tv2.component';
import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MenubarModule, MenuItem } from 'primeng/primeng';
import { CheckboxModule } from 'primeng/primeng';
import { DataTableModule, SharedModule } from 'primeng/primeng';
import { ButtonModule } from 'primeng/primeng';
import { DialogModule } from 'primeng/primeng';
import { OverlayPanelModule } from 'primeng/primeng';
import { FieldsetModule } from 'primeng/primeng';
import { MessagesModule } from 'primeng/primeng';
import { TabViewModule } from 'primeng/primeng';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { OrderListModule } from 'primeng/primeng';

@NgModule({
    imports: [CommonModule,
        ButtonModule,
        DialogModule,
        MenubarModule,
        CheckboxModule,
        DataTableModule,
        SharedModule,
        ButtonModule,
        DialogModule,
        BrowserAnimationsModule,
        OverlayPanelModule,
        FieldsetModule,
        MessagesModule,
        TabViewModule,
        OrderListModule
    ],
    declarations: [
        Tv2Component,
        BlankboardComponent
    ],
    exports: [Tv2Component]
})
export class Tv2Module {
    static forRoot(): ModuleWithProviders {
        return {
            ngModule: Tv2Module,
            providers: [Tv2Service]
        }
    }
}