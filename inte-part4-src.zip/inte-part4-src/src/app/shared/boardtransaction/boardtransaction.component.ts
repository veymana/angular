import { EDebitItem } from '../models/edebit-item.model';
import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { MenubarModule, MenuItem } from 'primeng/primeng';
import { CheckboxModule } from 'primeng/primeng';
import { DataTableModule, SharedModule } from 'primeng/primeng';
import { ButtonModule } from 'primeng/primeng';
import { DialogModule } from 'primeng/primeng';
import { OverlayPanelModule } from 'primeng/primeng';
import { FieldsetModule } from 'primeng/primeng';
import { MessagesModule } from 'primeng/primeng';
import { TabViewModule } from 'primeng/primeng';
import { BoardItem } from '../models/board-item.model';
import { LessCashItem } from '../models/lcash-item.model';
import { TransactionModel } from '../models/transaction.model';

@Component({
  selector: 'board-transaction',
  templateUrl: 'boardtransaction.component.html',
  styleUrls: ['boardtransaction.component.scss']
})
export class BoardTransactionComponent implements OnInit {
  title = 'Store Vision Teller';
  items: MenuItem[];
  selectedValues: string[] = [];
  accounts;
  @Input()
  display = true;
  @Input("trnxModel") trnxModel: TransactionModel;

  @Output() onItemCashingClose = new EventEmitter<boolean>();
  @Output() onTv2Close = new EventEmitter<boolean>();

  @Output() addDbtItemEvnt = new EventEmitter<boolean>();
  @Output() submitEvnt = new EventEmitter<boolean>();
  @Output() completeEvnt = new EventEmitter<boolean>();



  pinSelect: boolean = false;

  tab1Display: string = "none";
  tab2Display: string = "block";
  hostUpdateDlg: boolean = false;
  submitEnabled: boolean = true;
  submitTitle: string = "Submit";
  hostStatus: string = "none";
  transState: string = "construct";
  summaryDlg: boolean = false;
  lessCashAmt: number = 0.00;
  isBoardGreen: boolean = false;
  dlgWidth: number = 800;
  dlgHeight: number = 800;
  pinpadStatus: string = "PINPad ready"

  itemCashingTab: boolean = false;
  detailsTab: boolean = true;

  debitItems: BoardItem[] = [];
  lessCashItem: LessCashItem;

  creditItems: BoardItem[] = [];

  constructor() {
    this.dlgWidth = window.screen.width - 20;
    this.dlgHeight = window.screen.height - 10;

  }

  ngOnInit() {
    console.log("Transaction model");
    console.log(this.trnxModel);
    this.creditItems.push(new LessCashItem());
    this.lessCashItem = new LessCashItem();
  }

  showDialog() {
    this.display = true;
  }

  closeSession() {

    this.transState = "summary";

    this.itemCashingTab = false;
    this.detailsTab = true;

    this.hostStatus = "none";
    this.submitTitle = "submitt";

    this.tab2Display = "block";
    this.tab1Display = "none";

    this.submitEnabled = true;
    this.summaryDlg = false;
    this.onItemCashingClose.emit(false);
  }


  mainWindow() {
    this.onItemCashingClose.emit(false);
  }

  addDebitItem() {
    this.addDbtItemEvnt.emit();
  }


  submitHost() {

    if ("conclude" === this.transState) {
      this.summaryDlg = true;
      this.transState = "summary";
      return;
    }
    this.hostUpdateDlg = true;
    //Prototype purpose only
    setTimeout(() => {
      this.hostUpdateDlg = false;
      this.submitEnabled = false;
      this.submitTitle = "Complete";
      this.hostStatus = "block";
      this.transState = "conclude";
    }, 1000);
  }
  onTv2CloseHandle(agreed: boolean) {
    this.display = false;
  }

  closeTv2() {
    this.onTv2Close.emit(false);
  }

  continueNextTab() {
    this.tab2Display = "none";
    this.tab1Display = "block";

    this.itemCashingTab = true;
    this.detailsTab = false;

    this.submitEnabled = false;

    this.transState = "collect";
    this.isBoardGreen = true;
  }

  registerHotKey($event) {

    if ($event.keyCode == 35 && "summary" == this.transState) {
      this.closeSession();
    }
    if ($event.keyCode == 13 && "collect" == this.transState) {
      this.submitHost();
    }
    if ($event.keyCode == 13 && "conclude" == this.transState && this.isBoardGreen) {
      this.submitHost();
    }

    if (($event.keyCode == 116 || $event.keyCode == 84) && $event.altKey) {
      // $event.stopPropagation();
      //  $event.preventDefault();

      if (this.display) {
        //this.display=false;
      }
      else {
        /// this.display=true;
      }

    }
  }

}
