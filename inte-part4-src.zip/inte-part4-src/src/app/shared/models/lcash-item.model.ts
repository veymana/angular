import { ElectronicItem } from './eitem.model';

export class LessCashItem extends ElectronicItem {
    debitIcon: string;
    statusIcon: string;
    amount: number;

    constructor() {
        super();
        this.debitIcon = "assets/images/less-cash.png";
        this.statusIcon = "assets/images/check-error.png";
        this.amount = 0.00;
    }
}