import {
    IInteraction,
    IQueueScope,
    ICustomer,
    ITransaction,
    ITeller,
    ITellers,
    DynamicDate,
    IMongoDbObjectId,
    IBranchVisit
} from '.';

export class QueueEntry implements IInteraction {

    public _id?: string = void 0;
    public idAsString: string = void 0;
    public id?: IMongoDbObjectId = void 0;
    public creationTimestamp?: DynamicDate = void 0;
    public lastUpdateTimestamp?: DynamicDate = void 0;
    public scope: IQueueScope = {
        status: "UNKNOWN"
    };
    public customer?: ICustomer = void 0;
    public branchVisit: IBranchVisit = void 0;
    public creatorApp?: string = void 0;

    public constructor() {
        this.creationTimestamp = new Date();
    }

    /**
     * Converts IInteraction to an instance of QueueEntry
     * 
     * @static
     * @param {IInteraction} interaction 
     * @returns 
     * 
     * @memberOf QueueEntry
     */
    public static convert(interaction: IInteraction) {
        let retVal: QueueEntry = new QueueEntry();
        if (!!interaction === false)
            return retVal;

        retVal.id = interaction.id;
        retVal.idAsString = interaction.idAsString;
        retVal.creationTimestamp = this.toDate(interaction.creationTimestamp || "").toISOString();
        retVal.lastUpdateTimestamp = this.toDate(<string>interaction.lastUpdateTimestamp || "").toISOString();
        retVal.scope = interaction.scope;
        retVal.customer = interaction.customer;
        retVal.branchVisit = interaction.branchVisit;
        retVal.creatorApp = interaction.creatorApp;
        return retVal;
    }

    private static toDate(input: DynamicDate) {
        if (typeof (input) === "string")
            return new Date(<string>input || "")

        if (typeof (input) === "object")
            return input;

        if (typeof (input) === "number")
            return new Date(+input)

        return null;
    }
}
