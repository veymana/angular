import {
    ITeller,
    IInteraction,
    IAddress,
    ICustomer,
    IQueueAction
} from './interfaces';

import { QueueEntry } from './queue-entry.model';

export type QueueEntries = QueueEntry[];

export type IAddresses = IAddress[];

export type IInteractions = IInteraction[];

export type ITellers = ITeller[];

export type DynamicDate = Date | string | number;

export type ICustomers = ICustomer[];

export type AuthenticationMethodTypeEnum =
    "NONE" |
    "DRIVERS_LICENSE" |
    "PIN";

export declare type QueueStatusTypeEnum =
    "interaction" |
    "notification" |
    "events";

export type ReceiptTypeEnum =
    "NONE" |
    "PRINT" |
    "EMAIL" |
    "TEXT" |
    "WFINBOX";

export type TransactionTypeEnum =
    "DEPOSIT" |
    "DEPOSIT" |
    "CASH_ITEM" |
    "E_WITHDRAWAL" |
    "PAYMENT" |
    "CASHIER_CHECK_MONEY_ORDER" |
    "CASH_ADVANCE" |
    "TRANSFER" |
    "TEMP_CHECKS" |
    "OTHER";

export type CustomerTypeEnum =
    "GUEST" |
    "CUSTOMER";

export type EventTypeEnum =
    "CREATE" |
    "UPDATE" |
    "DELETE";

export type InteractionStatusTypeEnum =
    "UNKNOWN" |
    "WAITING" |
    "CLAIMED" |
    "COMPLETED" |
    "CANCELED" |
    "ALL";

export type IQueueActions = IQueueAction[];