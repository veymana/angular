import {
    DynamicDate,
    AuthenticationMethodTypeEnum,
    QueueStatusTypeEnum,
    ReceiptTypeEnum,
    TransactionTypeEnum,
    ITellers,
    CustomerTypeEnum,
    IAddresses,
    EventTypeEnum,
    InteractionStatusTypeEnum,
    QueueEntries
} from './types';


/**
 * Account interface
 * 
 * @export
 * @interface IAccount
 */
export interface IAccount {
    accountNumber: number;
    /**
     * Account number
     * 
     * @type {number}
     * @memberOf IAccount
     */
    accountCompanyNumber: number;
    /**
     * Account product code
     * 
     * @type {string}
     * @memberOf IAccount
     */
    productCode: string;
    /**
     * Current balance of account
     * 
     * @type {number}
     * @memberOf IAccount
     */
    currentBalance: number;
    /**
     * Account nickname
     * 
     * @type {string}
     * @memberOf IAccount
     */
    accountNickname: string;
    /**
     * Authority
     * 
     * @type {boolean}
     * @memberOf IAccount
     */
    hasTransactionAuthority: boolean;
    /**
     * Is account closed or not
     * 
     * @type {boolean}
     * @memberOf IAccount
     */
    isClosed: boolean;
};

/**
 * Customer interface
 * 
 * @export
 * @interface ICustomer
 */
export interface ICustomer {
    /**
     * Customer number.
     * This is different from account and card numbers
     * 
     * @type {number}
     * @memberOf ICustomer
     */
    customerNumber?: number;
    /**
     * Company number
     * 
     * @type {string}
     * @memberOf ICustomer
     */
    companyNumber?: number;

    /**
     * Account holder first name
     * 
     * @type {string}
     * @memberOf ICustomer
     */
    firstName?: string;
    /**
     * Account holder last name
     * 
     * @type {string}
     * @memberOf ICustomer
     */
    lastName?: string;
    /**
     * Full name
     * 
     * @type {string}
     * @memberOf ICustomer
     */
    fullName?: string;
    /**
     * Entity type
     * 
     * @type {string}
     * @memberOf ICustomer
     */
    entityType?: string;
    /**
     * Customer type
     * 
     * @type {string}
     * @memberOf ICustomer
     */
    customerType?: string;
    /**
     * High value code
     * 
     * @type {string}
     * @memberOf ICustomer
     */
    highValueCode?: string;
    /**
     * Private bank client code
     * 
     * @type {string}
     * @memberOf ICustomer
     */
    privateBankClientCode?: string;
    /**
     * Private bank cilent description
     * 
     * @type {string}
     * @memberOf ICustomer
     */
    privateBankClientDescription?: string;
    /**
     * Segment Dimension code
     * 
     * @type {string}
     * @memberOf ICustomer
     */
    segmentDimensionCode?: string;
    /**
     * Segment Dimension Description
     * 
     * @type {string}
     * @memberOf ICustomer
     */
    segmentDimensionDescription?: string;
    /**
     * Status code
     * 
     * @type {string}
     * @memberOf ICustomer
     */
    statusCode?: string;
    /**
     * True if customer is an employee
     * 
     * @type {boolean}
     * @memberOf ICustomer
     */
    employeeIndicator?: boolean;
    /**
     * Tax ID
     * 
     * @type {string}
     * @memberOf ICustomer
     */
    taxIdNumber?: string;
    /**
     * Type of Tax ID
     * 
     * @type {string}
     * @memberOf ICustomer
     */
    taxIdType?: string;
    /**
     * Address
     * 
     * @type {IAddresses}
     * @memberOf ICustomer
     */
    addresses?: IAddresses;
    /**
     * Email Address
     * 
     * @type {string}
     * @memberOf ICustomer
     */
    emailAddress?: string;
    /**
     * Data account was opened
     * 
     * @type {StringOrDate}
     * @memberOf ICustomer
     */
    openDate?: DynamicDate;
    /**
     * Customer Since
     * 
     * @type {string}
     * @memberOf ICustomer
     */
    customerSince?: DynamicDate;
    /**
     * Date of birth
     * 
     * @type {StringOrDate}
     * @memberOf ICustomer
     */
    birthday?: DynamicDate;
    /**
     * Date of birth (Short date)
     * 
     * @type {string}
     * @memberOf ICustomer
     */
    birthdayShortFormat?: string;
    /**
     * Mobile phone
     * 
     * @type {string}
     * @memberOf ICustomer
     */
    mobilePhone?: string;
    /**
     * Alias
     * 
     * @type {string}
     * @memberOf ICustomer
     */
    alias?: string;
    /**
     * 
     * 
     * @type {string}
     * @memberOf ICustomer
     */
    segmentation?: string;
    /**
     * 
     * 
     * @type {string}
     * @memberof ICustomer
     */
    language?: string;
}

/**
 * Address Interface
 * 
 * @export
 * @interface IAddress
 */
export interface IAddress {
    /**
     * Line list (Street address)
     * 
     * @type {string[]}
     * @memberOf IAddress
     */
    lineList: string[];
    /**
     * city
     * 
     * @type {string}
     * @memberOf IAddress
     */
    city?: string;
    /**
     * Postal code
     * 
     * @type {string}
     * @memberOf IAddress
     */
    postalCode?: string;
    /**
     * Zip Code
     * 
     * @type {string}
     * @memberOf IAddress
     */
    zipCode?: string;
    /**
     * State
     * 
     * @type {string}
     * @memberOf IAddress
     */
    stateCode?: string;
    /**
     * Province
     * 
     * @type {string}
     * @memberOf IAddress
     */
    provinceCode?: string;
    /**
     * Country Code
     * 
     * @type {string}
     * @memberOf IAddress
     */
    countryCode?: string;
    /**
     * Country name
     * 
     * @type {string}
     * @memberOf IAddress
     */
    countryName?: string;
}

export interface IMongoDbObjectId {
    timestamp?: number;
    machineIdentifier?: number;
    processIdentifier?: number;
    counter?: number;
    timeSecond?: number;
    date?: number;
    time?: number;
}

/**
 * Interaction Interface
 * 
 * @export
 * @interface IInteraction
 */
export interface IInteraction {
    /**
     * Id as String
     * This should match QueueEvent's objectRef.oid
     * 
     * @type {string}
     * @memberOf IInteraction
     */
    idAsString?: string;
    /**
     * Id (from mongo Db)
     * 
     * @type {IMongoDbObjectId}
     * @memberOf IInteraction
     */
    id?: IMongoDbObjectId;
    /**
     * DateTime it was created
     * 
     * @type {StringOrDate}
     * @memberOf IInteraction
     */
    creationTimestamp?: DynamicDate;
    /**
     * DateTime last updated
     * 
     * @type {StringOrDate}
     * @memberOf IInteraction
     */
    lastUpdateTimestamp?: DynamicDate;
    /**
     * Scope of interaction
     * 
     * @type {IQueueScope}
     * @memberOf IInteraction
     */
    scope?: IQueueScope;
    /**
     * Customer in this interaction
     * 
     * @type {ICustomer}
     * @memberOf IInteraction
     */
    customer?: ICustomer;

    /**
     * Visit information
     * REQUIRED
     * 
     * @type {IBranchVisit}
     * @memberOf IInteraction
     */
    branchVisit: IBranchVisit;

    /**
     * Which application created this transaction
     * 
     * @type {string}
     * @memberOf IInteraction
     */
    creatorApp?: string;

    /**
     * Life Cycle of interaction
     * 
     * @type {ILifeCycleStage}
     * @memberOf IInteraction
     */
    interactionLifeCycle?: IInteractionLifeCycle[];
};

/**
 * Branch Visit interface
 * 
 * @export
 * @interface IBranchVisit
 */
export interface IBranchVisit {
    optionalNotes?: string;
    assignedBanker?: IBankerInfo;
    appointment?: IAppointment;
    customerType: CustomerTypeEnum;
    reasonForVisit: Array<IReasonDetails>;
    languageSelected?: string;
}

/**
 * 
 * 
 * @export
 * @interface IReasonDetails
 */
export interface IReasonDetails {
    code: string;
    text: string;
}
/**
 * Banker Info interface
 * 
 * @export
 * @interface IBankerInfo
 */
export interface IBankerInfo {
    optionSelected?: optionSelectedEnum;
    bankerDetails?: Array<IBankerDetails>;
    bankerOverridden?: boolean;
}

export type optionSelectedEnum = "NO_PREFERENCE" | "ALL_BANKERS" | "SPECIFIC";
/**
 * 
 * 
 * @export
 * @interface BankerDetails
 */
export interface IBankerDetails {
    employeeId?: string;
    name: IName;
}

/**
 * Name interface
 * 
 * @export
 * @interface IName
 */
export interface IName {
    firstName?: string;
    lastName?: string;
}

/**
 * Appointment Interface
 * 
 * @export
 * @interface IAppointment
 */
export interface IAppointment {
    firstName?: string;
    lastName?: string;
    appointmentTime?: DynamicDate;
    appointmentDurationMinutes?: number;
    reason?: string;
    comments?: string;
    confirmationNumber?: string;
    bankerName?: string;
    locationId?: string;
    email?: string;
}

/**
 * Life cycle stage Interface
 * 
 * @export
 * @interface ILifeCycleStage
 */
export interface IInteractionLifeCycle {
    deviceId?: string;
    status?: InteractionStatusTypeEnum;
    teamMemberId?: string;
    timeStamp?: DynamicDate;
    appName?: string;
}

/**
 * Object Ref Interface
 * 
 * @export
 * @interface IQueueDbObjectRef
 */
export interface IQueueDbObjectRef {
    /**
     * Collection identifier
     * 
     * @type {string}
     * @memberOf IQueueDbObjectRef
     */
    collection: string;
    /**
     * Object Reference Id.
     * This should match the Interaction's idAsString
     * 
     * @type {string}
     * @memberOf IQueueDbObjectRef
     */
    oid: string;
}

/**
 * QueueEvent Interface
 * 
 * @export
 * @interface IQueueEvent
 */
export interface IQueueEvent {
    /**
     * Id of QueueEvent
     * 
     * @type {string}
     * @memberOf IQueueEvent
     */
    id?: string;
    objectRef: IQueueDbObjectRef;
    timestamp?: Date;
    scope?: IQueueScope;
    type?: QueueStatusTypeEnum;
    status?: InteractionStatusTypeEnum;
    eventType?: EventTypeEnum;
}

/**
 * Queue Scope interface
 * 
 * @export
 * @interface IQueueScope
 */
export interface IQueueScope {
    /**
     * AU
     * 
     * @type {string}
     * @memberOf IQueueScope
     */
    accountingUnit?: string;
    /**
     * Type
     * 
     * @type {string}
     * @memberOf IQueueScope
     */
    type?: string;
    /**
     * Status
     * 
     * @type {string}
     * @memberOf IQueueScope
     */
    status?: InteractionStatusTypeEnum;
    /**
      * Status
      * 
      * @type {string}
      * @memberOf IQueueScope
      */
    previousStatus?: InteractionStatusTypeEnum;
    [key: string]: string;
}


/**
 * Teller Interface
 * 
 * @export
 * @interface ITeller
 */
export interface ITeller {
    /**
     * Employee Id
     * 
     * @type {string}
     * @memberOf ITeller
     */
    employeeId: string;
    /**
     * First name
     * 
     * @type {string}
     * @memberOf ITeller
     */
    firstName?: string;
    /**
     * Last Name
     * 
     * @type {string}
     * @memberOf ITeller
     */
    lastName: string;
    /**
     * Email
     * 
     * @type {string}
     * @memberOf ITeller
     */
    emailAddress: string;
    /**
     * User/Network ID
     * 
     * @type {string}
     * @memberOf ITeller
     */
    userId: string;
}

/**
 * Transaction Interface
 * 
 * @export
 * @interface ITransaction
 */
export interface ITransaction {
    /**
     * Transaction Type
     * 
     * @type {TransactionTypeEnum}
     * @memberOf ITransaction
     */
    transactionType?: TransactionTypeEnum;
    /**
     * Selected account in this transaction
     * 
     * @type {IAccount}
     * @memberOf ITransaction
     */
    selectedAccount: IAccount;
    /**
     * Amount
     * 
     * @type {number}
     * @memberOf ITransaction
     */
    amount: number;
    /**
     * Amount minus transaction amount
     * 
     * @type {number}
     * @memberOf ITransaction
     */
    lessCashAmount: number;
    /**
     * Receipt
     * 
     * @type {ReceiptTypeEnum}
     * @memberOf ITransaction
     */
    receiptType: ReceiptTypeEnum;
    /**
     * Auth method
     * 
     * @type {AuthenticationMethodTypeEnum}
     * @memberOf ITransaction
     */
    authenticationMethod: AuthenticationMethodTypeEnum;
    /**
     * Teller who created this interaction
     * 
     * @type {ITeller}
     * @memberOf ITransaction
     */
    createdBy: ITeller;
    /**
     * Tellers who serviced this interaction
     * 
     * @type {ITellers}
     * @memberOf ITransaction
     */
    servicedBy?: ITellers;
}


/**
 * Actions
 * 
 * @export
 * @enum {number}
 */
export enum QueueActionEnum {
    assist = 0,
    edit,
    remove
}

/**
 * QueueAction
 * 
 * @export
 * @interface IQueueAction
 */
export interface IQueueAction {
    displayText: string;
    type: QueueActionEnum;
    onErrorCallback?: (err?: any) => void;
}


export interface IGroupedQueueEntries {
    [status: string]: QueueEntries;
    UNKNOWN: QueueEntries;
    WAITING: QueueEntries;
    CLAIMED: QueueEntries;
    COMPLETED: QueueEntries;
    CANCELED: QueueEntries;
    ALL?: QueueEntries;
};
