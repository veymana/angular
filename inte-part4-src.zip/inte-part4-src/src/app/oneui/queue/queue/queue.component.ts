import { Component, OnInit, ElementRef } from '@angular/core';
import { QueueService } from '../queue.service';
import { ICustomer } from '../models/interfaces';
import { Subscription } from 'rxjs/Subscription';
import { TitleCasePipe } from '#shared/title-case.pipe';
import { QueueEntry, QueueActionEnum, IQueueActions, IQueueAction, QueueEntries, IBranchVisit } from '../models';
import { IUserMessage, IUserMessageButton, IUserMessages, IUserMessageOnClickEvent } from '#shared/popup/models';
import { PopupService } from '#shared/popup/popup.service';
import { FlowService } from "core/flow/flow.service";
import { Dimensions } from 'core/base/dimensions';
import { Observable } from 'rxjs';
import { UtilsService } from "core/services";
import { HeaderService } from "core/header/header.service";
@Component({
  selector: 'queue',
  templateUrl: './queue.component.html',
  styleUrls: ['./queue.component.scss']
})
export class QueueComponent extends Dimensions implements OnInit {

  private currentlyOpenedQueueEntryId: string = null;

  /**
   * Queue colapases when editing a customer .
   * returns active outlet Id 
   * 
   * @param {string} outletName 
   * 
   * @memberOf HeaderService
   */
  private toggleQueue() {
    let id:string = this.headerService.getActiveOutletId('right-panel');
    this.headerService.toggle(id);
  }

  public get queueEntries(): QueueEntries {
    let withAppointments: QueueEntries = [];
    let withoutAppointments: QueueEntries = [];
    // Sort and filter in one pass:
    for (let qEntry of this.queueService.queueEntries["WAITING"]) {
      if (qEntry && qEntry.branchVisit && qEntry.branchVisit.appointment && qEntry.branchVisit.appointment.confirmationNumber) {
        withAppointments.push(qEntry);
      } else {
        withoutAppointments.push(qEntry);
      }
    }
    return withAppointments.reverse().concat(withoutAppointments);
  }

  public getMainElement(): ElementRef {
    return this.elementRef;
  }

  /**
   * Creates an instance of QueueComponent.
   * @param {QueueService} queueService 
   * @param {TitleCasePipe} titleCasePipe 
   * @param {PopupService} popupService 
   * 
   * @memberOf QueueComponent
   */
  constructor(private queueService: QueueService,
    private titleCasePipe: TitleCasePipe,
    private popupService: PopupService,
    private flowService: FlowService,
    private elementRef: ElementRef,
    private headerService: HeaderService
  ) {
    super();
  }

  ngOnInit(): void {
  }
  ngOnDestroy(): void {
  }

  onDropDownSelection(event: { action: IQueueAction, queueEntry: QueueEntry }): void {
    if (!!event === false || !!event.action === false || !!event.queueEntry === false) {
      console.warn(`${QueueComponent.name}: Unable to proceed with selection.`, event);
      return;
    }

    if (event.action.type === QueueActionEnum.remove) {
      let visitorFullName: string = event.queueEntry.customer && (event.queueEntry.customer.fullName || (event.queueEntry.customer.firstName + ' ' + event.queueEntry.customer.lastName));

      // Check if user is removing the customer he is also currently editing:
      let popupId: string = "CONTINUEWILLCANCEL";
      if (this.flowService.currentChannelId === "edit") {
        const metadata: any = this.flowService.getFlowData("metadata");
        const originalIdAsAString: any = metadata["originalQueueEntry"] && metadata["originalQueueEntry"]["idAsString"];
        if (event.queueEntry.idAsString === originalIdAsAString) {
          popupId = "CONTINUEWILLCANCEL";
        }
      }

      this.popupService.show(popupId, {
        visitor: this.titleCasePipe.transform(visitorFullName || "visitor"),
        queueEntry: event.queueEntry
      })
        .subscribe((clickEvent: IUserMessageOnClickEvent) => {
          this.onPopupClick(clickEvent)
            .subscribe(
            (success: any) => { },
            (error: any) => {
              event.action.onErrorCallback();
            });
        }
        );
    }
    if (event.action.type === QueueActionEnum.edit) {
      this.toggleQueue();
      let mergedBranchVisit: IBranchVisit = null;
      if (event.queueEntry.branchVisit.appointment && event.queueEntry.branchVisit.appointment.confirmationNumber) {
        // Construct the BranchVisit values for Appointment
        let updatedbranchVisit: IBranchVisit = {
          optionalNotes: event.queueEntry.branchVisit.appointment.reason || undefined,
          customerType: event.queueEntry.branchVisit.customerType,
          reasonForVisit: [{ code: "GEN:OTH", text: "GENERAL:Other" }],
          assignedBanker: event.queueEntry.branchVisit.assignedBanker,
          languageSelected: event.queueEntry.branchVisit.languageSelected
        };
        mergedBranchVisit = Object.assign({}, event.queueEntry.branchVisit, updatedbranchVisit);
      }
      let initialData: any = {
        metadata: {
          data: { originalQueueEntry: event.queueEntry },
          constants: {
            visitortype: event.queueEntry.branchVisit.customerType,
            idAsString: event.queueEntry.idAsString
          }
        },
        reason: { data: event.queueEntry.branchVisit.reasonForVisit.length > 0 ? event.queueEntry.branchVisit : mergedBranchVisit },
        visitor: { data: event.queueEntry.customer, isComplete: true },
        banker: { data: { assignedBanker: event.queueEntry.branchVisit.assignedBanker, languageSelected: event.queueEntry.branchVisit.languageSelected } }
      };
      this.flowService.start("edit", initialData, { queryParams: { id: event.queueEntry.idAsString } }, true);
    }
  }

  private onPopupClick(usermessageClickEvent: IUserMessageOnClickEvent): Observable<any> {
    let retVal: Observable<any> = Observable.empty();
    let queueEntry: QueueEntry = usermessageClickEvent.userMessage.context && usermessageClickEvent.userMessage.context["queueEntry"];
    if (!!queueEntry === false) {
      console.warn(`${QueueComponent.name}: Unable to proceed with onPopupClick.`, event);
      return;
    }

    switch (usermessageClickEvent.userMessage.name) {
      case "CONTINUEWILLCANCEL": {
        switch (usermessageClickEvent.button.action) {
          case "CONTINUE":
            retVal = this.queueService.cancel(queueEntry);
            this.popupService.close();
            if (usermessageClickEvent.userMessage.name === "CONTINUEWILLCANCEL") {
              setTimeout((_: any) => {
                this.flowService.start(null, null, null, true, true); // Go back to initial (default) flow
              });
            }
            break;
          default:
          case "CLOSE":
            this.popupService.close();
            break;
        }
        break;
      }
    }
    return retVal;
  }

  private onCardOpened($event: any): void {
    if (this.currentlyOpenedQueueEntryId !== $event)
      this.currentlyOpenedQueueEntryId = $event;
    else
      this.currentlyOpenedQueueEntryId = null;
  }
}
