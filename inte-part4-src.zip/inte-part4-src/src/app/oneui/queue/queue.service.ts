import { Injectable, Optional } from '@angular/core';
import { QueueEntry, QueueEntries } from 'app/oneui/queue/models';
import { WebSocketService, WebSocketDefinition, WebSocketEvent, WebSocketEventType, IWebSocketDefinition } from 'core/web-socket.service';
import { Subscription, Observable, BehaviorSubject, Subject } from 'rxjs/Rx';
import { AppSettings } from '#environments/environment';
import { IQueueEvent, IInteraction, IInteractions, InteractionStatusTypeEnum, IInteractionLifeCycle, IGroupedQueueEntries } from './models';
import { InteractionsRestclientService } from 'core/restclient/interactions-restclient.service';
import { Restclient } from 'core/restclient/restclient-base.service';
import { Http, XHRBackend, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { RestResource } from 'core/restclient/rest-resource'
import { OneInterfaceService } from '@one-interface/one-interface.service';
import { UserService } from 'core/services';


/**
 * QueueService handles websocket connection and event handling.
 * Responsible for
 * - retrieving interactions from REST services.
 * - posting new interactions to REST services.
 * - adding/removing from queue
 * - providing subscription for queue/interaction events. * 
 * 
 * @export
 * @class QueueService
 */
@Injectable()
export class QueueService {

  private queueWebSocketSubject: BehaviorSubject<WebSocketEvent>;

  private wsSetting: IWebSocketDefinition = AppSettings.WEBSOCKETS.connections["queue"];
  private get queueWebSocketObservable(): Observable<WebSocketEvent> {
    return this.queueWebSocketSubject && this.queueWebSocketSubject.asObservable();
  }

  /**
   * Contains all queue entries in relation to their ID.
   * 
   * @private
   * @type {{ [id: string]: QueueEntries }}
   * @memberof QueueService
   */
  private flatQueue: { [id: string]: QueueEntry } = {};

  /**
   * Array of all QueueEntry grouped by InteractionStatusTypeEnum
   * 
   * @type {QueueEntries}
   * @memberOf QueueService
   */
  public queueEntries: IGroupedQueueEntries = {
    "UNKNOWN": [],
    "WAITING": [],
    "CLAIMED": [],
    "COMPLETED": [],
    "CANCELED": []
  };

  /**
   * Subject that others can subscribe to when used with asObvervable
   * 
   * @type {BehaviorSubject<QueueEntries>}
   * @memberOf QueueService
   */
  public readonly queueEntriesSubject: BehaviorSubject<IGroupedQueueEntries> = new BehaviorSubject<IGroupedQueueEntries>(this.queueEntries);

  /**
   * Creates an instance of QueueService.
   * @param {WebSocketService} webSocketService 
   * 
   * @memberOf QueueService
   */
  constructor(private webSocketService: WebSocketService,
    private interactionsRestClientService: InteractionsRestclientService,
    private userService: UserService,
    private ois: OneInterfaceService
  ) {

    Object.defineProperty(this.queueEntries, "ALL", {
      get: () => {
        let all: Array<QueueEntry> = new Array<QueueEntry>();
        for (let key in this.queueEntries) {
          if (key !== "ALL")
            all = all.concat(this.queueEntries[key]);
        }
        return all;
      }
    });

    // Initialize after user is authenticated
    userService.getUserObservable().subscribe(
      user => {
        if ((user != null) && (user.isAuthenticated)) {
          this.init();
        }
      },
      error => {
        console.log("QueueService: could not initialize: " + error);
      });
  }

  /**
   * Setup/Initialization
   * 
   * @private
   * @returns {void} 
   * 
   * @memberOf QueueService
   */
  private init(): void {
    if (!!this.wsSetting === false) {
      throw new Error("QueueService.init() invalid wsSetting");
    }

    let wsDefinition: WebSocketDefinition = new WebSocketDefinition(this.wsSetting);
    this.queueWebSocketSubject = this.webSocketService.create(wsDefinition);
    this.subscribeToWebSocketObs();

    // Get all interactions from this morning (12 AM)
    this.getInteractionsFromStartOfDay();
  }

  /**
   * Retrieves all interactions from start of day (Current date with 00:00:00 or 12 AM)
   * 
   * @private
   * 
   * @memberOf QueueService
   */
  private getInteractionsFromStartOfDay(): void {
    let startOfDay: Date = new Date();
    startOfDay.setHours(0, 0, 0, 0);
    let waitingStatus: InteractionStatusTypeEnum = "ALL";

    let obsOfIInteractions: Observable<IInteractions> = this.interactionsRestClientService.get(startOfDay, waitingStatus);
    let obsOfQueueEntries: Observable<QueueEntries> = obsOfIInteractions.map(
      (val: IInteractions) => {
        let retVal: QueueEntries = new Array<QueueEntry>();
        for (let ia of val) {
          retVal.push(QueueEntry.convert(ia));
        }
        return retVal;
      }
    );

    obsOfQueueEntries.subscribe(
      (val: QueueEntries) => {
        for (let qEntry of val) {
          let status: InteractionStatusTypeEnum = (qEntry && qEntry.scope && qEntry.scope.status) || "UNKNOWN";
          this.queueEntries[status].push(qEntry);
        }
        this.sortAndUniqueQueueEntries();
        this.queueEntriesSubject.next(this.queueEntries);
      }
    )
  }

  /**
   * Sorts queueEntries and removes duplicates
   * Filtered to return only WAITING
   * 
   * @private
   * 
   * @memberOf QueueService
   */
  private sortAndUniqueQueueEntries() {
    for (let status in this.queueEntries) {
      if (status === "ALL")
        continue;

      this.queueEntries[status].sort((a, b) => {
        return ((new Date(a.creationTimestamp.toString())).getTime() - (new Date(b.creationTimestamp.toString())).getTime());
      });

      // At this point, the freshest ones are on top (from sort above)
      // So we can traverse through each items and check if it already exist in the fresh array.
      // Uniqueness will be based from idAsString
      let freshQueueEntries = new Array<QueueEntry>();
      for (let qEntry of this.queueEntries[status]) {
        let index: number = freshQueueEntries.findIndex(q => q.idAsString === qEntry.idAsString);
        if (index === -1) {
          freshQueueEntries.push(qEntry);
          this.flatQueue[qEntry.idAsString] = qEntry;
        }
      }

      this.queueEntries[status] = freshQueueEntries;
    }
  }

  /**
   * Subscribes to the websocket obvervable.
   * 
   * @private
   * 
   * @memberOf QueueService
   */
  private subscribeToWebSocketObs(): void {
    this.queueWebSocketObservable &&
      this.queueWebSocketObservable.subscribe(
        (wsData: WebSocketEvent) => {

          switch (wsData && wsData.type) {

            case WebSocketEventType.opened:
              this.onWsOpened(wsData);
              break;

            case WebSocketEventType.closed:
              this.onWsClosed(wsData);
              break;

            case WebSocketEventType.sent:
              this.onWsMessageToServer(wsData)
              break;
            case WebSocketEventType.received:
              this.onWsMessageFromServer(wsData)
              break;

            case WebSocketEventType.error:
              this.onWsError(wsData);
              break;

            default:
            case WebSocketEventType.message:
              this.onWsAnythingElse(wsData);
              break;
          }
        },
        (error: any) => { this.onWsError(error); }
      );
  }

  /**
   * Event handler when websocket connection was opened
   * 
   * @private
   * @param {WebSocketEvent} wsData 
   * 
   * @memberOf QueueService
   */
  private onWsOpened(wsData: WebSocketEvent): void {
    console.info(`${QueueService.name}.webSocket.onWsOpened: ${JSON.stringify(wsData)}`);
  }

  /**
   *  Event handler when websocket connection was closed
   * 
   * @private
   * @param {WebSocketEvent} wsData 
   * 
   * @memberOf QueueService
   */
  private onWsClosed(wsData: WebSocketEvent): void {
    console.info(`${QueueService.name}.webSocket.onWsClosed: ${JSON.stringify(wsData)}`);
  }

  /**
   *  Event handler when websocket connection sends data to server
   * 
   * @private
   * @param {WebSocketEvent} wsData 
   * 
   * @memberOf QueueService
   */
  private onWsMessageToServer(wsData: WebSocketEvent): void {
    console.info(`${QueueService.name}.webSocket.onWsMessageToServer: ${JSON.stringify(wsData)}`);
  }

  /**
   *  Event handler when websocket connection receives data from server
   * 
   * @private
   * @param {WebSocketEvent} wsData 
   * @returns {void} 
   * 
   * @memberOf QueueService
   */
  private onWsMessageFromServer(wsData: WebSocketEvent): void {
    console.info(`${QueueService.name}.webSocket.onWsMessageFromServer: ${JSON.stringify(wsData)}`);
    let data: IQueueEvent;

    try {
      data = JSON.parse(wsData.data) as IQueueEvent;
    } catch (e) {
      this.queueWebSocketSubject.error(new WebSocketEvent("Unable to parse data", WebSocketEventType.error));
    }

    if (!(data && data.objectRef && data.objectRef.oid)) {
      console.error(`${QueueService.name}.webSocket.onWsMessageFromServer: objectRef.oid does not exist}`, data);
      return;
    }

    this.getInteractionFromHost(data.objectRef.oid.toString());
  }

  /**
   * Any other events from websocketevent evety types
   * 
   * @private
   * @param {WebSocketEvent} wsData 
   * 
   * @memberOf QueueService
   */
  private onWsAnythingElse(wsData: WebSocketEvent): void {
    console.info(`${QueueService.name}.webSocket.onWsAnythingElse: ${JSON.stringify(wsData)}`);
  }

  /**
   *  Event handler when websocket connection error occurs
   * 
   * @private
   * @param {*} error 
   * 
   * @memberOf QueueService
   */
  private onWsError(error: any): void {
    console.error(`${QueueService.name}.webSocket.onWsError: ${JSON.stringify((error && error.data && error.data.message) || error)}`);
  }

  /**
   * Adds QueueEntry to array of queues
   * 
   * @private
   * @param {QueueEntry} entry 
   * 
   * @memberOf QueueService
   */
  private addToQueueEntries(entry: QueueEntry): void {
    console.debug("Adding to queue.", entry);

    this.queueEntries[entry.scope.status.toUpperCase()].push(entry);
    this.sortAndUniqueQueueEntries();
    this.queueEntriesSubject.next(this.queueEntries);
  }



  /**
   * Retrieves queue length
   * 
   * @returns 
   * 
   * @memberOf QueueService
   */
  getQueueLength(status: string) {
    return (this.queueEntries[status] || []).length;
  }


  /**
   * Retrieves interaction from host through REST
   * 
   * @private
   * 
   * @memberOf QueueService
   */
  private getInteractionFromHost(oid: string): void {
    let httpCallResult: Observable<IInteraction> = this.interactionsRestClientService.get(oid);
    if (httpCallResult instanceof Observable) {
      httpCallResult
        .subscribe(
        (res: IInteraction) => this.onInteractionReceived(res),
        (error: any) => {
          console.error(`${QueueService.name}.getInteractionFromHost Error`, error);
        },
        () => { }
        );
    }
  }

  /**
   * Event handler when the HTTP.get receives interaction from Host REST Service
   * 
   * @private
   * @param {IInteraction} interaction 
   * 
   * @memberOf QueueService
   */
  private onInteractionReceived(interaction: IInteraction, isUpdate: boolean = false): void {
    let queueEntry: QueueEntry = QueueEntry.convert(interaction);

    // find previous value.
    if (queueEntry !== null && queueEntry.scope && queueEntry.scope.previousStatus) {
      // Found the QEntry. We need to remove it from previous bucket!
      let idx: number = this.queueEntries[queueEntry.scope.previousStatus].findIndex(q => q.idAsString === queueEntry.idAsString);
      if (idx > -1) {
        this.queueEntries[queueEntry.scope.previousStatus].splice(idx, 1);
      }
    }

    if (queueEntry && queueEntry.scope && queueEntry.scope.status) {
      //  QEntry already in queue in same status. We need to remove it!
      let idx: number = this.queueEntries[queueEntry.scope.status].findIndex(q => q.idAsString === queueEntry.idAsString);
      if (idx > -1) {
        this.queueEntries[queueEntry.scope.status].splice(idx, 1);
      }
      this.queueEntries[queueEntry.scope.status].push(queueEntry);
    }
    this.sortAndUniqueQueueEntries();
    this.queueEntriesSubject.next(this.queueEntries);
  }

  /**
   * Posts interaction to Host through REST
   * 
   * @param {IInteraction} interaction 
   * 
   * @memberOf QueueService
   */
  public postInteractionToHost(interaction: IInteraction | QueueEntry, isUpdate: boolean = false): Observable<IInteraction> {

    // Add required data if missing:
    if (!!(<IInteraction>interaction).creatorApp === false) {
      interaction.creatorApp = `${AppSettings.APP_NAME} v${AppSettings.VERSION}`;
    }
    let previousStatusBeforePost: InteractionStatusTypeEnum = interaction.scope.previousStatus;
    let obs: Observable<IInteraction> = this.interactionsRestClientService.postInteraction(<IInteraction>interaction, isUpdate);
    obs.take(1).subscribe(
      (interaction: IInteraction) => {
        // Add to internal list on success:
        this.onInteractionReceived(interaction, isUpdate);
      },
      (error: any) => {
        interaction.scope.status = previousStatusBeforePost;
        console.error(`QueueService.postInteractionToHost Error:`, error);
      },
      () => { }
    );
    return obs;
  }

  /**
   * Alias of postInteractionToHost
   * 
   * @param {(IInteraction | QueueEntry)} interaction
   * @returns {Observable<IInteraction>}
   * 
   * @memberOf QueueService
   */
  public add(interaction: IInteraction | QueueEntry): Observable<IInteraction> {
    return this.postInteractionToHost(<IInteraction>interaction);
  }

  /**
   * Updates an interaction or queue.
   * The update parameter can be the delta (only changes) or the
   * entire duplicated interaction with the changes in it already.
   * 
   * Update also adds to the interactionLifeCycle array.
   * 
   * @param {(IInteraction | QueueEntry)} interaction 
   * @returns {Observable<IInteraction>} 
   * 
   * @memberOf QueueService
   */
  public update(interactionOrId: IInteraction | QueueEntry | string): Observable<IInteraction> {
    let ia: IInteraction = null;

    if (typeof (interactionOrId) === "string") {
      ia = this.getQueueById(<string>interactionOrId);
    } else {
      ia = interactionOrId;
    }

    let newInteractionLifeCycle: IInteractionLifeCycle = this.getNewInteractionLifeCycle((<IInteraction>interactionOrId).scope.status);

    if (!Array.isArray(ia.interactionLifeCycle))
      ia.interactionLifeCycle = [];
    ia.interactionLifeCycle.push(newInteractionLifeCycle);

    return this.postInteractionToHost(ia, true);
  }

  /**
   * Claims an interaction 
   * and removes from Queue
   * @param {(IInteraction | QueueEntry)} interaction 
   * @returns {Observable<IInteraction>} 
   * 
   * @memberOf QueueService
   */
  public claim(interactionOrId: IInteraction | QueueEntry | string): Observable<IInteraction> {
    let ia: IInteraction = null;

    // Parameter is the ID:
    if (typeof (interactionOrId) === "string") {
      ia = this.getQueueById(interactionOrId);
    }
    else {
      ia = interactionOrId;
    }

    if (!!ia === false) {
      console.warn(`${QueueService.name} unable to claim.`);
      return;
    }
    ia.scope.previousStatus = ia.scope.status;
    ia.scope.status = "CLAIMED";
    return this.update((<IInteraction>ia));
  }


  /**
   * Cancels the interaction/queue
   * 
   * @param {(IInteraction | QueueEntry | string)} interactionOrid 
   * @returns {Observable<IInteraction>} 
   * 
   * @memberof QueueService
   */
  public cancel(interactionOrid: IInteraction | QueueEntry | string): Observable<IInteraction> {
    let ia: IInteraction = null;

    // Parameter is the ID:
    if (typeof (interactionOrid) === "string") {
      ia = this.getQueueById(<string>interactionOrid);
    }
    else {
      ia = interactionOrid;
    }

    if (!!ia === false) {
      console.warn(`${QueueService.name} unable to cancel.`);
      return;
    }
    ia.scope.previousStatus = ia.scope.status;
    ia.scope.status = "CANCELED";

    return this.update((<IInteraction>ia));
  }

  /**
   * Returns the queue based on id
   * 
   * @public
   * @param {string} id 
   * @returns 
   * 
   * @memberOf QueueService
   */
  public getQueueById(id: string): QueueEntry {
    return this.flatQueue && this.flatQueue[id] || null;
  }

  /**
   * Returns the status of the queue entry
   * 
   * @param {(string | QueueEntry)} queueEntryOrId 
   * @returns {InteractionStatusTypeEnum} 
   * 
   * @memberof QueueService
   */
  public getQueueEntryStatus(queueEntryOrId: string | QueueEntry): InteractionStatusTypeEnum {
    let queue: QueueEntry = null;

    if (!!queueEntryOrId === false) {
      console.warn(`${QueueService.name}.getQueueEntryStatus: Invalid parameter`);
      return "UNKNOWN";
    }

    if (typeof (queueEntryOrId) === "string") {
      queue = this.getQueueById(queueEntryOrId);
    }
    else if (queueEntryOrId instanceof QueueEntry) {
      queue = queueEntryOrId;
    }
    else {
      console.warn(`${QueueService.name}.getQueueEntryStatus: Unable to find queue`);
      return "UNKNOWN";
    }

    if (!!queue === false || !!queue.scope === false || !!queue.scope.status === false) {
      console.warn(`${QueueService.name}.getQueueEntryStatus: QueueEntry found but scope.status is invalid`);
      return "UNKNOWN";
    }

    return queue.scope.status;
  }

  /**
   * Creates a new Interaction Life Cycle
   * 
   * @param {string} status 
   * @returns {IInteractionLifeCycle} 
   * 
   * @memberof QueueService
   */
  public getNewInteractionLifeCycle(status: InteractionStatusTypeEnum): IInteractionLifeCycle {

    return {
      appName: `${AppSettings.APP_NAME} v${AppSettings.VERSION}`,
      deviceId: this.ois.systemDeviceInformation.deviceId,
      status: status,
      teamMemberId: this.userService.user.employeeId,
      timeStamp: new Date().toISOString()
    }
  }

}
