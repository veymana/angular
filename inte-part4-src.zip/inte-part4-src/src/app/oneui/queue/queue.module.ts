import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { QueueComponent } from './queue/queue.component';
import { QueueEntryComponent } from './queue-entry/queue-entry.component';
import { QueueService } from './queue.service';


import { SharedModule } from 'app/oneui/shared/shared.module';

@NgModule({
  imports: [
    CommonModule,
    BrowserModule,
    NgbModule,
    SharedModule
  ],
  declarations: [
    QueueComponent,
    QueueEntryComponent
  ],
  providers: [
    QueueService
  ],
  exports: [
    CommonModule,
    QueueComponent,
    QueueEntryComponent
  ]
})
export class QueueModule {
  constructor() {

  }
}