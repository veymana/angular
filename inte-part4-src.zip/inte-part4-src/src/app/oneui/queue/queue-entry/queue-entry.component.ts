import { Component, Input, OnInit, OnDestroy, Output, EventEmitter, ViewChild, ElementRef } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { IInteraction, QueueEntry, QueueActionEnum, IQueueActions, IQueueAction, IBankerDetails, } from '../models';
import { QueueService } from 'app/oneui/queue/queue.service';
import { NgbDropdown } from '@ng-bootstrap/ng-bootstrap';
import { ScrollToShowDirective } from '#shared/scroll-to-show.directive';
import { UtilsService } from 'core/services';
import { IContextualMessage } from 'core/flow/models';

@Component({
  selector: 'queue-entry',
  templateUrl: './queue-entry.component.html',
  styleUrls: ['./queue-entry.component.scss']
})
export class QueueEntryComponent extends NgbDropdown implements OnInit {
  @Input()
  public queueEntry: QueueEntry;

  @Output("onDropDownSelection")
  private onDropDownSelectionEmitter: EventEmitter<{ action: IQueueAction, queueEntry: QueueEntry }> = new EventEmitter<{ action: IQueueAction, queueEntry: QueueEntry }>();

  @Output("onCardOpened")
  private onCardOpenedEmitter: EventEmitter<string> = new EventEmitter<string>();

  @Input()
  public currentlyOpenedQueueEntryId: string = void 0;

  @ViewChild(NgbDropdown)
  private queueEntryDropDownMenu: NgbDropdown;

  @ViewChild(ScrollToShowDirective)
  private scrollToShowDirectiveViewChild: ScrollToShowDirective;

  public contextualMessage: IContextualMessage | null | undefined = void 0;

  public waitingMinutes: number;
  private waitingUpdateSubscription: Subscription;
  private queueActions: IQueueActions = [
    {
      displayText: "Edit",
      type: QueueActionEnum.edit,
      onErrorCallback: this.onErrorCallback.bind(this)
    },
    {
      displayText: "Remove",
      type: QueueActionEnum.remove,
      onErrorCallback: this.onErrorCallback.bind(this)
    }
  ];

  /**
   * Creates an instance of QueueEntryComponent.
   * @param {QueueService} queueService 
   * 
   * @memberOf QueueEntryComponent
   */
  constructor(private queueService: QueueService, private elementRef: ElementRef) {
    super({
      up: false,
      autoClose: true
    });
  }

  ngOnInit() {
    let age = UtilsService.moment.duration(UtilsService.moment().diff(UtilsService.moment(this.queueEntry.creationTimestamp)));
    this.waitingMinutes = (60 * age.hours()) + age.minutes();
    let nextTick = 60 - age.seconds(); // number of seconds until queue entry becomes one minute older

    // Create observable that emits a value every time the queue entry becomes one minute older.
    // The first argument is the delay for the first value emission and it is a partial minute.
    // Then emit values every minute (60000ms).
    this.waitingUpdateSubscription = Observable.timer(nextTick * 1000, 60000).subscribe(value => {
      this.waitingMinutes++;
    });
  }

  ngOnDestroy() {
    this.waitingUpdateSubscription.unsubscribe();
  }

  onQueueTileClick() {
    this.onCardOpenedEmitter.emit(this.queueEntry.idAsString);

    setTimeout(_ => {
      if (this.isMyCardOpened()) {
        let selfBottom = this.elementRef.nativeElement.getBoundingClientRect().bottom;
        let parentHeight = document.documentElement.clientHeight;
        if ((+selfBottom + 150) > parentHeight)
          this.queueEntryDropDownMenu.up = true;
        else
          this.queueEntryDropDownMenu.up = false;

        if (!!this.scrollToShowDirectiveViewChild === true) {
          this.scrollToShowDirectiveViewChild.scrollToShow();
        }
      }
    });
  }

  onDropDownSelection(action: IQueueAction) {
    this.onDropDownSelectionEmitter.emit({
      action: action,
      queueEntry: this.queueEntry
    });
  }

  onAssist() {
    console.log("Queue Entry: " + this.queueEntry);
    this.queueService.claim(this.queueEntry)
      .subscribe(
      success => { },
      err => this.onErrorCallback(err)
      );

  }

  onStopEvent(e) {
    e.stopPropagation();
  }

  public isMyCardOpened(): boolean {
    return this.currentlyOpenedQueueEntryId === this.queueEntry.idAsString;
  }

  /**
   * Retrieves banker details
   * 
   * @param {QueueEntry} queueEntry 
   * 
   * @memberof QueueEntryComponent
   */
  public getBankerDetails(queueEntry: QueueEntry) {
    let retVal: IBankerDetails = null;
    let bankerDetails: Array<IBankerDetails> = UtilsService.getNestedProperty(queueEntry, "branchVisit.assignedBanker.bankerDetails");
    if (Array.isArray(bankerDetails) && bankerDetails.length > 0)
      retVal = bankerDetails[0];

    return retVal;
  }

  /**
   * Returns banker name
   * 
   * @param {QueueEntry} queueEntry 
   * 
   * @memberof QueueEntryComponent
   */
  public getBankerName(bankerDetail: IBankerDetails) {
    // let bankerDetail: IBankerDetails = this.getBankerDetails(queueEntry);
    let firstName = UtilsService.getNestedProperty(bankerDetail, "name.firstName") || "";
    let lastName = UtilsService.getNestedProperty(bankerDetail, "name.lastName") || "";
    let fullName = `${firstName} ${lastName}`.trim() || "Any";
    return fullName;
  }

  /**
   * Returns the style for segmentation
   * 
   * @returns {string} 
   * 
   * @memberof QueueEntryComponent
   */
  public getBadgeClass(): string {
    let badgeVal: string = '';
    setTimeout(_ => {
      if (this.queueEntry.customer && this.queueEntry.customer.segmentation) {
        if (this.queueEntry.customer.segmentation.indexOf('High Value Customer') !== -1) {
          badgeVal = 'badge-highvalue-customer';
        } else if (this.queueEntry.customer.segmentation === 'The Private Bank') {
          badgeVal = 'badge-private-customer';
        } else if (this.queueEntry.customer.segmentation === 'Business Bank Wholesale') {
          badgeVal = 'badge-business-customer';
        }
      } else if (this.queueEntry.branchVisit.customerType.toUpperCase() === 'GUEST') {
        badgeVal = 'badge-guest';
      }
    });
    return badgeVal;
  }

  public onErrorCallback(err: any) {
    //TODO
    this.contextualMessage = { message: "Error: TODO!", type: "FAIL" };
  }
}
