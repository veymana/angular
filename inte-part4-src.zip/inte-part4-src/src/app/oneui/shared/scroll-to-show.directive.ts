import { Inject, Directive, OnInit, ElementRef, Input } from '@angular/core';
import { WindowRefService } from 'core/window-ref.service';
import { DOCUMENT } from '@angular/platform-browser';

/**
 * Automatically scrolls the page so that the element is in view.
 * ### Usage:
 * To scroll itself:
 * ```
 * <div scrollIntoView>looooong and tall content</div>
 * ```
 * To scroll all the way to parent
 * ```
 * <div scrollToShow>looooong and tall content</div> 
 * ```
 * To scroll into an element:
 * call scrollToShow(element) in controller through the scrollToShow reference.
 * For example:
 * ```
 * ... @ViewChild(ScrollToShowDirective) private scrollToShowRef: ScrollToShowDirective;
 * ngOnInit() {
 *  this.scrollToShowRef.scrollToShow(someElement);
 * }
 * ```
* 
 * To stop element from scrolling on ngOnInit, add the option (which is true by default):
 * ```
 * <div scrollIntoView [scrollIntoViewOptions]="{isScrollOnInit:false}">looooong and tall content</div>
 * ```
 * 
 * ### Scroll Strategy:
 * By default, scroll strategy is to scroll just barely until the element is shown on viewable area, but 
 * browsers themselves have scrollIntoView() function, which can align elements on top or below of the offsetParent.
 * https://developer.mozilla.org/en-US/docs/Web/API/Element/scrollIntoView
 * 
 * to use scrollIntoView, set the proper option:
 * ```
 * <div scrollToShow [scrollToShowOptions]="{strategy:'scrollIntoView'}">looooong and tall content</div> 
 * ```
 * 
 * ..but scrollIntoView also has its own option, which is behavior and block:
 * ```
 * {
 *    behavior: "auto"  | "instant" | "smooth",
 *    block:    "start" | "end"
 * }
 * ```
 * 
 * By default, we will use
 * ```
 * { behavior: "auto", block: "start" } 
 * ```
 * 
 * but you can override this by explicitly setting it:
 * ```
 * <div scrollToShow [scrollToShowOptions]="{strategy:'scrollIntoView', scrollIntoViewOptions: { behavior: 'smooth', block: 'end' }}">looooong and tall content</div> 
 * ```
 * @export
 * @class ScrollIntoViewDirective
 * @implements {OnInit}
 */
@Directive({
  selector: '[scrollToShow]'
})
export class ScrollToShowDirective implements OnInit {
  @Input('scrollToShowOptions')
  private scrollToShowOptions: {
    isScrollOnInit?: boolean,
    strategy?: "default" | "scrollIntoView",
    scrollIntoViewOptions?: {
      behavior?: "auto" | "instant" | "smooth",
      block?: "start" | "end"
    }
  };

  private defaultScrollToShowOptions: { [key: string]: any } = {
    isScrollOnInit: true,
    strategy: "default",
    scrollIntoViewOptions: {
      behavior: "auto",
      block: "start"
    }
  };

  /**
   * Creates an instance of ScrollIntoViewDirective.
   * @param {ElementRef} elementRef 
   * 
   * @memberOf ScrollIntoViewDirective
   */
  constructor(private elementRef: ElementRef, @Inject(DOCUMENT) private documentRef: any) {

  }

  public scrollToShow(element?: Element | ElementRef) {
    let el: Element = this.getNativeElement(element || this.elementRef);
    setTimeout(_ => {
      // Myself:
      let mySelf: Element = el; // Just for clarity
      let mySelf_bottom: number = mySelf.getBoundingClientRect().bottom;

      // Scroller:
      let scroller: Element = this.findParentThatScrollsVertically(el);
      let scroller_bottom: number = this.getBottomMost(scroller, true);

      let isOverflowed: boolean = mySelf_bottom > scroller_bottom;
      // if not inside overflow, do nothing :)
      if (isOverflowed === false)
        return;



      // Default Strategy
      if (this.scrollToShowOptions.strategy === "default") {
        scroller.scrollTop += Math.abs(scroller_bottom - mySelf_bottom);
        return;
      }

      // ScrollIntoView Strategy

      el.scrollIntoView(this.scrollToShowOptions.scrollIntoViewOptions);

    });
  }

  ngOnInit() {
    this.scrollToShowOptions = Object.assign({}, this.defaultScrollToShowOptions, this.scrollToShowOptions);

    if (this.scrollToShowOptions.isScrollOnInit)
      this.scrollToShow(this.elementRef);
  }

  private getComputedStyle(element: Element | ElementRef): CSSStyleDeclaration {
    let el: Element = this.getNativeElement(element);
    return WindowRefService.nativeWindow.getComputedStyle(el);
  }

  private getBottomMost(element: Element | ElementRef, isToBottomOfContentAreaOnly: boolean = false): number {
    let el: Element = this.getNativeElement(element);
    let retVal: number = 0;
    let boundingClientRect: ClientRect = el.getBoundingClientRect();

    if (isToBottomOfContentAreaOnly === false) {
      retVal = boundingClientRect.bottom;
    }
    else {
      let computedStyle: CSSStyleDeclaration = WindowRefService.nativeWindow.getComputedStyle(el);
      retVal = el.clientTop
        + boundingClientRect.top
        + el.clientHeight
        - (parseFloat(computedStyle.paddingBottom) || 0);
    }

    return retVal;
  }

  private findParentThatScrollsVertically(el: Element | ElementRef): Element {
    let parent: Element = this.elementRef.nativeElement.parentElement;
    while (parent !== this.documentRef.body) {
      let overFlowY: string = WindowRefService.nativeWindow.getComputedStyle(parent).overflowY;
      if (overFlowY === "auto" || overFlowY === "scroll")
        break;
      parent = parent.parentElement;
    }

    return parent;
  }

  private getNativeElement(el: Element | ElementRef): Element {
    return el instanceof ElementRef ? el.nativeElement : el;
  }



}
