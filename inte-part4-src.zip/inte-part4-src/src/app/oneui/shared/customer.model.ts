export class Customer {
  ecn: string;
  firstName: string;
  lastName: string;
}
