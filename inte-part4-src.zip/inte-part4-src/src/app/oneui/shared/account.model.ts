export class Account {
  accountNumber: string;
  nickname: string;
  product: string;
  accountType: string;
  availableBalance: number;
}