import { Component, OnInit } from '@angular/core';
import { PopupService, IUserMessage, IUserMessageButton, IUserMessageOnClickEvent } from '.';

@Component({
  selector: 'popup',
  templateUrl: './popup.component.html',
  styleUrls: ['./popup.component.scss']
})
export class PopupComponent implements OnInit {
  public get userMessage(): IUserMessage {
    return this.popupService.current;
  }

  constructor(private popupService: PopupService) { }

  ngOnInit() {

  }

  /**
   * Buttons are clicked INSIDE the popup
   * 
   * @public
   * @param {IUserMessage} userMessage 
   * @param {IUserMessageButton} button 
   * 
   * @memberOf PopupComponent
   */
  public onPopupClick(userMessage: IUserMessage, button: IUserMessageButton): void {
    let clickEvent: IUserMessageOnClickEvent = {
      button: button,
      userMessage: userMessage
    };
    this.popupService.onPopupClick(clickEvent);
  }

  /**
   * Something OUTSIDE the popup was clicked.
   * 
   * @private
   * 
   * @memberOf PopupComponent
   */
  public onOutsideClick() {
    if (this.popupService.current.type !== "CONFIRM" && this.popupService.current.type !== "DEADEND") {
      this.popupService.close();
    }
  }


  /**
   * Inner click
   * 
   * @private
   * @param {any} $event 
   * 
   * @memberOf PopupComponent
   */
  public noop($event) {
    $event.stopPropagation();
  }


}
