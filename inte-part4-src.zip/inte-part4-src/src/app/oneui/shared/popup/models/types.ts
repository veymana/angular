import { IUserMessage } from '.';
import { IFlattenedObject } from 'core/services';
export type IUserMessagesFlattenedArray = Array<IUserMessage & IFlattenedObject>;