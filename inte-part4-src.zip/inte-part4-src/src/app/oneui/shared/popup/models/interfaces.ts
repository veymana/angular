export interface IUserMessageButton {
    /**
     * Text to display
     * 
     * @type {string}
     * @memberOf IUserMessageButton
     */
    text?: string;
    /**
     * CSS class to add
     * Note: classes will have a btn- prefix.
     * So if this is primary, then 'btn-primary' is the actual class that is used
     * 
     * @type {string}
     * @memberOf IUserMessageButton
     */
    class?: string;
    /**
     * Action of the button so that handler can differentiate
     * 
     * @type {("CLOSE" | "CONTINUE" | "CANCEL")}
     * @memberOf IUserMessageButton
     */
    action: "CLOSE" | "CONTINUE" | "CANCEL" | "EXIT" | "RELAUNCH";

    /**
     * The order in which the buttons are displayed
     * 
     * @type {number}
     * @memberOf IUserMessageButton
     */
    order?: number;
}

export interface IUserMessage {

    /**
     * Popup Type.
     * If a popup is NOT of type CONFIRM, then any click outside the popup will close it.
     * If a popup is CONFIRM type, then only selecting the buttons will close it.
     * If a popup is DEADEND type, user will have no choice but to exit application.
     * 
     * @type {("CONFIRM" | "MESSAGE" | "NOTIFICATION" | "DEADEND")}
     * @memberOf IUserMessage
     */
    type: "CONFIRM" | "MESSAGE" | "NOTIFICATION" | "DEADEND"
    /**
     * name of the user message
     * 
     * @type {string}
     * @memberOf IUserMessage
     */
    name?: string;
    /**
     * ID of the usermessage
     * 
     * @type {number}
     * @memberOf IUserMessage
     */
    id?: number;
    /**
     * header text (language db)
     * 
     * @type {string}
     * @memberOf IUserMessage
     */
    header: string;
    /**
     * Body text (langauge db)
     * 
     * @type {string}
     * @memberOf IUserMessage
     */
    body: string;
    /**
     * Buttons for the popup
     * 
     * @type {IUserMessageButton}
     * @memberOf IUserMessage
     */
    buttons?: Array<IUserMessageButton>;

    /**
     * To send data to the popup.
     * Generically for use with translation.
     * 
     * @type {*}
     * @memberOf IUserMessage
     */
    context?: any;
}

export interface IUserMessages {
    [key: string]: IUserMessage;
}

export interface IUserMessageOnClickEvent {
    userMessage: IUserMessage;
    button: IUserMessageButton;
}

