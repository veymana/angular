import { Injectable } from '@angular/core';
import { IUserMessage, IUserMessageButton, IUserMessages, IUserMessagesFlattenedArray, IUserMessageOnClickEvent } from './models';
import { Observable, Subject, Observer } from 'rxjs/Rx';
import { Router, ActivatedRoute } from '@angular/router';
import { UtilsService, IFlattenedObject } from 'core/services';
import { AppSettings } from '#environments/environment';
import { TerminatesessionService } from 'core/restclient/terminate-session-restclient.service';

// DATA FILE
import * as usermessages$json from '#compiled-data/usermessages.json';


@Injectable()
export class PopupService {

  private readonly _usermessages$json: IUserMessages = usermessages$json as any;
  private readonly usermessages: IUserMessages = this._usermessages$json as IUserMessages;
  private readonly usermessagesFlatArray: IUserMessagesFlattenedArray = UtilsService.flatten<IUserMessage>(this.usermessages, "___METADATA");
  private onClickSubject: Subject<IUserMessageOnClickEvent> = null;

  /**
   * The Current User Message Shown
   * 
   * @type {IUserMessage}
   * @memberOf PopupService
   */
  public current: IUserMessage = null;

  private queryParams: { [key: string]: any };

  /**
   * The Observable that other entities can subscribe to.
   * 
   * @readonly
   * @type {Observable<IUserMessageOnClickEvent>}
   * @memberOf PopupService
   */
  public get onClickObservable(): Observable<IUserMessageOnClickEvent> {
    return this.onClickSubject.asObservable().share();
  }

  /**
   * Creates an instance of PopupService.
   * @param {Router} router 
   * 
   * @memberOf PopupService
   */
  constructor(private router: Router,
    private activatedRoute: ActivatedRoute,
    private terminatesessionService: TerminatesessionService) {
    this.onClickSubject = new Subject<IUserMessageOnClickEvent>();
    activatedRoute.queryParams.subscribe(
      (p: any) => { this.queryParams = p; }
    );
  }

  /**
   * Shows the Popup.
   * 
   * 
   * ### Usage
   * By ID:
   * show(12345)
   * 
   * By Name:
   * show("CONTINUEWILLCANCEL")
   * 
   * By IUserMessage:
   * show({
   *  "name": "test"
   *  "header": "K_TESTHEADERKEY",
   *  "body": "K_TESTBODYKEY"
   * })
   * 
   * Let's assume the popup (MyVisitorPopup) has a body text with ${visitor} variable. To send this data, use the following:
   * show("MyVisitorPopup", { visitor: "lucky"});
   * 
   * The return value is an observable that will only emit if the click event came from the idOrNameOrIUserMessage.
   * 
   * @param {(number | IUserMessage | string)} idOrNameOrIUserMessage 
   * @memberOf PopupService
   */
  public show(idOrNameOrIUserMessage: number | IUserMessage | string, context?: any): Observable<IUserMessageOnClickEvent> {
    let usermessage: IUserMessage = null;
    if (typeof (idOrNameOrIUserMessage) === "number") {
      // ID was passed:
      usermessage = this.usermessagesFlatArray.find((um: any) => um.id === <number>idOrNameOrIUserMessage);
    } else if (typeof ((<IUserMessage>idOrNameOrIUserMessage).id) !== "undefined"
      || typeof ((<IUserMessage>idOrNameOrIUserMessage).header) !== "undefined"
      || typeof ((<IUserMessage>idOrNameOrIUserMessage).body) !== "undefined") {
      // IUserMessage was passed.
      // This is either created on the fly
      // or through usermessages.json
      usermessage = <IUserMessage>idOrNameOrIUserMessage;
    }
    else if (typeof (idOrNameOrIUserMessage) === "string") {
      // String was passed. Mostly the "name"
      usermessage = this.usermessages[<string>idOrNameOrIUserMessage];
    }
    else {
      usermessage = idOrNameOrIUserMessage;
    }

    this.current = usermessage;
    if (!!this.current === false)
      return;

    this.current.context = context || this.current.context;
    this.router.navigate([this.getOutlet(true)], { queryParams: this.queryParams }).then(
      () => this.router.navigate([this.getOutlet()], { queryParams: this.queryParams })
    );

    if (!!usermessage.id === false || usermessage.type === "DEADEND")
      return Observable.empty();

    return Observable.zip(Observable.of(usermessage), this.onClickSubject.asObservable())
      .filter((v: any) => {
        let usermessage: any = v[0];
        let clickEvent: any = v[1];
        return usermessage.name === clickEvent.userMessage.name
          && usermessage.id === clickEvent.userMessage.id;
      })
      .map((v: any) => {
        let clickEvent: any = v[1];
        return clickEvent;
      });
  }

  /**
   * Retreives the outlet for the Popup.
   * Configurable in AppSettings.
   * 
   * @private
   * @param {boolean} [isNullify=false] 
   * @returns 
   * 
   * @memberOf PopupService
   */
  private getOutlet(isNullify: boolean = false): any {
    let outlet: any = {};

    if (isNullify) {
      outlet[AppSettings.PopupServiceConfig.outlet] = null;
    } else {
      outlet[AppSettings.PopupServiceConfig.outlet] = AppSettings.PopupServiceConfig.route;
    }

    return { outlets: outlet };
  }

  /**
   * Closes the popup.
   * 
   * @param {boolean} [isRetain=false] If True, the Usermessage is not cleared from memory.
   * 
   * @memberOf PopupService
   */
  public close(isRetain: boolean = false): void {
    setTimeout((_: any) => {
      this.router.navigate([this.getOutlet(true)], { queryParams: this.queryParams });
      if (isRetain === false)
        this.current = null;
    });
  }

  /**
   * Default handler if there are no observers to the subject.
   * 
   * @private
   * @param {IUserMessageOnClickEvent} onClickEvent 
   * 
   * @memberOf PopupService
   */
  private defaultPopupClickObserver(onClickEvent: IUserMessageOnClickEvent): void {
    switch (onClickEvent.button.action) {
      case "EXIT": {
        this.terminatesessionService.terminate(true, false);
        break;
      }
      default:
      case "CLOSE": {
        this.close();
        break;
      }
    }
  }

  /**
   * On Popup Click. Invokes the subscribers next()
   * 
   * @param {IUserMessageOnClickEvent} onClickEvent 
   * 
   * @memberOf PopupService
   */
  public onPopupClick(onClickEvent: IUserMessageOnClickEvent): void {
    if (!!this.onClickSubject === false || !!this.onClickSubject.observers === false || this.onClickSubject.observers.length <= 0) {
      this.defaultPopupClickObserver(onClickEvent);
    } else {
      this.onClickSubject.next(onClickEvent);
    }
  }

  /**
   * Shows please wait blocking modal
   * 
   * @returns {Promise<boolean>} 
   * 
   * @memberof PopupService
   */
  public showPleaseWait(): Promise<boolean> {
    console.log("Please wait popup active");
    return this.router.navigate([{ outlets: { "pleasewait": "pleasewait" } }]);
  }

  /**
   * Hides the please wait blocking modal
   * 
   * @returns {Promise<boolean>} 
   * 
   * @memberof PopupService
   */
  public hidePleaseWait(): Promise<boolean> {
    console.log("Please wait popup inactive");
    return this.router.navigate([{ outlets: { "pleasewait": null } }]);
  }

  /**
   * Returns true if usermessageid is defined.
   * 
   * @param {string} userMessageId 
   * @returns {boolean} 
   * @memberof PopupService
   */
  public has(userMessageId: string): boolean {
    return !!this._usermessages$json[userMessageId];
  }

  /**
   * Returns the usermessage metadata
   * 
   * @param {string} userMessageId 
   * @returns {IUserMessage} 
   * @memberof PopupService
   */
  public get(userMessageId: string): IUserMessage {
    return this.has(userMessageId) && Object.assign({}, this._usermessages$json[userMessageId]);
  }
}
