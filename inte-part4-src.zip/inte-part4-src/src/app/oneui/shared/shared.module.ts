import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { AgePipe } from './age.pipe';
import { TitleCasePipe } from './title-case.pipe';
import { PopupComponent, PopupService } from '#shared/popup';
import { ScrollToShowDirective } from './scroll-to-show.directive';
import { TextAreaDirective } from './input.directive';
import { DuplicatorDirective } from './duplicator.directive';

import { PleaseWaitComponent } from './please-wait/please-wait.component';
import { VersioninfoDirective } from './versioninfo.directive';

@NgModule({
  imports: [
    CommonModule,
    FormsModule
  ],
  providers: [
    PopupService,
    TitleCasePipe
  ],
  declarations: [
    AgePipe,
    TitleCasePipe,
    PopupComponent,
    ScrollToShowDirective,

    TextAreaDirective,
    DuplicatorDirective,

    VersioninfoDirective
  ],
  exports: [
    CommonModule,
    FormsModule,
    AgePipe,
    TitleCasePipe,
    ScrollToShowDirective,
    TextAreaDirective,
    DuplicatorDirective,
    VersioninfoDirective
  ]
})
export class SharedModule {
  constructor() {

  }
}
