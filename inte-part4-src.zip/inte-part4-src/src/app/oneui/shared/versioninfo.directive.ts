import {
  Directive,
  OnInit,
  ViewEncapsulation,
  ChangeDetectionStrategy,
  ElementRef,
  HostListener
} from '@angular/core';
import { PopupService } from '#shared/popup';
import { StartupService } from 'core/startup.service';
import { IUserMessage } from '#shared/popup/models';
import { AppSettings } from '#environments/environment';
import { builddate } from '#environments/builddate';
import { UtilsService } from 'core/utils.service';

@Directive({
  selector: '[versioninfo]'
})
export class VersioninfoDirective implements OnInit {

  constructor(private elementRef: ElementRef,
    private popupService: PopupService,
    private startupService: StartupService) {
  }

  private currentClickCount: number = 0;
  private readonly clickTrigger: number = 28;

  ngOnInit(): void {
  }

  @HostListener('window:click', ['$event'])
  public onClick(clickEvent: MouseEvent): void {
    if (this.elementRef.nativeElement.contains(event.target)) {
      this.currentClickCount++;
    }
    else {
      this.currentClickCount = 0;
    }
    let mDur: any = UtilsService.moment.duration(this.startupService.uptimeInMilliseconds, "milliseconds");
    let uptime: string = Math.floor(mDur.asHours()) + UtilsService.moment.utc(mDur.asMilliseconds()).format("[h] m[m] ss[s]");
    if (this.currentClickCount >= this.clickTrigger) {
      this.currentClickCount = 0;
      if (prompt("?").toUpperCase().replace(" ", "") === "LUCKYCHARMS") {
        let body: string = `<pre>\
                            \nApp: ${AppSettings.APP_NAME} ver. ${AppSettings.VERSION}\
                            \nBuild Date: ${builddate}\
                            \nUptime: ${uptime}\
                            \n</pre>`;

        let context: any = {
          "_header": "Version Info",
          "_body": body
        };

        this.popupService.show(<IUserMessage>{
          header: "${_header}",
          body: "${_body}",
          type: "MESSAGE",
          context: context
        });
      }
    }

  }
}
