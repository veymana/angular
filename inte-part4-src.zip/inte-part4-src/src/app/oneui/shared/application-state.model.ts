export class ApplicationState {
  name: string;

  constructor(name: string) {
    this.name = name;
  }
}
