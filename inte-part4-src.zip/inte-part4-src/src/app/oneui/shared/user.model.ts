import { Osuser } from '@one-interface/models/osuser';
import { UtilsService } from 'core/utils.service';
import { IUserServerData, IFunction } from 'core/models/interfaces';
import { Observable } from 'rxjs';
import { AppSettings } from '#environments/environment';


/**
 * 
 * 
 * @export
 * @class User
 */
export class User {
  /**
   * Emp ID
   * 
   * @type {string}
   * @memberOf User
   */
  public employeeId: string = "";

  /**
   * Is Authenticated
   * 
   * @type {boolean}
   * @memberOf User
   */
  public isAuthenticated: boolean = false;

  /**
   * User Name
   * 
   * @type {string}
   * @memberOf User
   */
  public userName: string = "";

  /**
   * 
   * 
   * @type {string}
   * @memberOf User
   */
  public firstName: string = "";

  /**
   * 
   * 
   * @type {string}
   * @memberOf User
   */
  public lastName: string = "";

  /**
   * 
   * 
   * @type {string}
   * @memberOf User
   */
  public middleInitial: string = "";

  /**
   * 
   * 
   * @type {string}
   * @memberOf User
   */
  public preferredFirstName: string = "";

  /**
   * 
   * 
   * @type {string}
   * @memberOf User
   */
  public preferredLastName: string = "";

  /**
   * 
   * 
   * @type {string}
   * @memberOf User
   */
  public emailAddress: string = "";

  /**
   * 
   * 
   * @type {string}
   * @memberOf User
   */
  public jobCode: string = "";

  /**
   * 
   * 
   * @type {string}
   * @memberOf User
   */
  public jobCodeDescription: string = "";

  /**
   * 
   * 
   * @type {string}
   * @memberOf User
   */
  public displayName: string = "";

  /**
   * 
   * 
   * @type {string}
   * @memberOf User
   */
  public get thumbnailURL(): string {
    return this.profilePhoto.small;
  }

  /**
   * 
   * 
   * 
   * @memberOf User
   */
  public functionList: IFunction[] = [];

  /**
   * 
   * 
   * @type {string}
   * @memberOf User
   */
  public get networkIdString(): string {
    return `${this.networkDomain || ""}_${this.networkId || ""}`;
  }

  /**
   * 
   * 
   * @type {*}
   * @memberOf User
   */
  public get profilePhoto(): { small: string, large: string } {
    return {
      small: `http://teammemberimage.hosting.wellsfargo.com/home/SharepointFormat?filename=${this.networkIdString}_s`,
      large: `http://teammemberimage.hosting.wellsfargo.com/home/SharepointFormat?filename=${this.networkIdString}_l`
    };
  }

  /**
   * 
   * 
   * @type {string}
   * @memberOf User
   */
  public networkDomain: string = "AD-ENT";

  /**
   * 
   * 
   * 
   * @type {string}
   * @memberOf User
   */
  public networkId: string = "";

  private _userServerData: IUserServerData = void 0;

  public userSessionId: string = void 0;

  /**
   * Raw user data retrieved from Host server
   * 
   * @readonly
   * @type {IUserServerData}
   * @memberof User
   */
  public get userServerData(): IUserServerData {
    return this._userServerData;
  }

  /**
   * Array of authorized applications/paths (funcitonIdentifier2)
   * 
   * @type {string[]}
   * @memberof User
   */
  public authorizedApplicationsOrPaths: string[] = [];

  /**
   * Error bucket.
   * 
   * @type {*}
   * @memberof User
   */
  public error: any = false;

  /**
   * Creates an instance of User.
   * 
   * @param {Osuser} [osUser] OsUser can be passed. OsUser can be created by OIS.
   * 
   * @memberOf User
   */
  public constructor(osUser?: Osuser) {
    if (!!osUser == true) {

      UtilsService.setIfExists("isAuthenticated", osUser, this);
      UtilsService.setIfExists("profilePhoto", osUser, this);

      let networkInfoParts = (osUser.networkIdString || "").split("\\");
      if (networkInfoParts.length >= 2) {
        this.networkDomain = networkInfoParts[0];
        this.networkId = networkInfoParts[1];
      }
    }
  }

  public mapServerData(serverData?: IUserServerData): Observable<User> {

    serverData = serverData || this.userServerData;

    if (!!serverData === false)
      return Observable.of(this);

    this.userSessionId = UtilsService.getNestedProperty(serverData, "userSessionId");
    this.employeeId = UtilsService.getNestedProperty(serverData, "teamMemberInformationResponse.teamMemberInformationDataList.0.employeeId");
    this.networkId = UtilsService.getNestedProperty(serverData, "teamMemberLanId");
    this.firstName = UtilsService.getNestedProperty(serverData, "teamMemberInformationResponse.teamMemberInformationDataList.0.basicInformation.firstName");
    this.lastName = UtilsService.getNestedProperty(serverData, "teamMemberInformationResponse.teamMemberInformationDataList.0.basicInformation.lastName");
    this.displayName = UtilsService.getNestedProperty(serverData, "teamMemberInformationResponse.teamMemberInformationDataList.0.basicInformation.displayName");
    this.middleInitial = UtilsService.getNestedProperty(serverData, "teamMemberInformationResponse.teamMemberInformationDataList.0.basicInformation.middleInitial");
    this.preferredFirstName = UtilsService.getNestedProperty(serverData, "teamMemberInformationResponse.teamMemberInformationDataList.0.basicInformation.preferredFirstName");
    this.preferredLastName = UtilsService.getNestedProperty(serverData, "teamMemberInformationResponse.teamMemberInformationDataList.0.basicInformation.preferredLastName");
    this.emailAddress = UtilsService.getNestedProperty(serverData, "teamMemberInformationResponse.teamMemberInformationDataList.0.basicInformation.emailAddress");
    this.jobCode = UtilsService.getNestedProperty(serverData, "teamMemberInformationResponse.teamMemberInformationDataList.0.basicInformation.jobCode");
    this.jobCodeDescription = UtilsService.getNestedProperty(serverData, "teamMemberInformationResponse.teamMemberInformationDataList.0.basicInformation.jobCodeDescription");
    this.functionList = UtilsService.getNestedProperty(serverData, "teamMemberInformationResponse.teamMemberInformationDataList.0.functionList");

    this._userServerData = serverData;
    this.constructAuthorizedApplications();
    return Observable.of(this);


  }

  /**
   * Constructs the list (string[]) of authorized applications.
   * 
   * @private
   * 
   * @memberof User
   */
  private constructAuthorizedApplications(): void {
    if (Array.isArray(this.functionList) && this.functionList.length > 0) {
      let authorizedApplications: IFunction[] = UtilsService.lodash.filter(this.functionList, (f: IFunction) => {
        let isIdentifier1Authorized: boolean = UtilsService.getNestedProperty(f, "functionIdentifier.functionIdentifier1") === AppSettings.FUNCTION_IDENTIFIER_1;
        let isFunctionAuthorityListAuthorized: boolean = UtilsService.getNestedProperty(f, "functionAuthorityList.0.assignedAuthorityValue") === "Y";
        return isIdentifier1Authorized && isFunctionAuthorityListAuthorized;
      });
      for (let func of authorizedApplications) {
        this.authorizedApplicationsOrPaths.push(UtilsService.getNestedProperty(func, "functionIdentifier.functionIdentifier2"));
      }
    }
  }






}
