import { Pipe, PipeTransform } from '@angular/core';
import { UtilsService } from 'core/utils.service';

/**
 * Calculates age
 * Usage:
 * @example
 * {{ 'March 28, 1984' | age }} will return age (in years) from today's date (defaults to years)
 * {{ 'March 28, 1984' | age : 'months' }} will return age (in months) from today's date
 * Second Argument can be years, months, weeks, hours, days, seconds, milliseconds, etc.
 * 
 * @export
 * @class AgePipe
 * @implements {PipeTransform}
 */
@Pipe({
  name: 'age'
})
export class AgePipe implements PipeTransform {

  transform(birthdate: Date | string, args?: any): any {
    let type = (args && args[0]) || "years";
    return UtilsService.moment().diff(birthdate, type)

  }
}
