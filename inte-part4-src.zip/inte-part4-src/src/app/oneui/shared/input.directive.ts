import { Directive, Input, Renderer, ElementRef, OnInit } from '@angular/core';

export class NoAuto implements OnInit {

  @Input("autocomplete")
  private autocomplete: string;

  @Input("autocorrect")
  private autocorrect: string;

  @Input("autocapitalize")
  private autocapitalize: string;

  constructor(private renderer: Renderer, private elementRef: ElementRef) { }

  ngOnInit() {
    this.renderer.setElementAttribute(this.elementRef.nativeElement, "autocapitalize", this.autocapitalize || "off");
    this.renderer.setElementAttribute(this.elementRef.nativeElement, "autocorrect", this.autocorrect || "off");
    this.renderer.setElementAttribute(this.elementRef.nativeElement, "autocomplete", this.autocomplete || "off");
  }

}


@Directive({
  selector: 'input'
})
export class InputAutoCompleteDirective extends NoAuto implements OnInit {
  constructor(renderer: Renderer, elementRef: ElementRef) {
    super(renderer, elementRef);
  }
}

@Directive({
  selector: 'textarea'
})
export class TextAreaDirective extends NoAuto implements OnInit {
  constructor(renderer: Renderer, elementRef: ElementRef) {
    super(renderer, elementRef);
  }
}