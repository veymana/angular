import { Directive, Input, ElementRef, AfterViewChecked } from '@angular/core';

/**
 * This directive can duplicate any content/component.
 * ### Usage:
 * ```
 * <div #elementToDuplicate>Hello</div>
 * <div [duplicator]="elementToDuplicate"></div>
 * 
 * When rendered, the second div above will have the same HTML as the one it duplicated.
 * Note: innerHTML is set, so parent <div> can be retained and styled.
 * ```
 * @export
 * @class DuplicatorDirective
 * @implements {AfterViewChecked}
 */
@Directive({
  selector: '[duplicator]'
})
export class DuplicatorDirective implements AfterViewChecked {

  @Input("duplicator")
  private duplicatedElement: ElementRef = void 0;

  constructor(private myself: ElementRef) { }

  ngAfterViewChecked() {
    let dupe: HTMLElement = this.getHTMLElement(this.duplicatedElement);

    if (!!dupe && (<HTMLElement>this.myself.nativeElement).innerHTML !== dupe.innerHTML) {
      (<HTMLElement>this.myself.nativeElement).innerHTML = dupe.innerHTML;
    }
  }

  /**
   * Gets the native element in HTMLElement type
   * 
   * @private
   * @param {(ElementRef | HTMLElement)} e 
   * @returns 
   * 
   * @memberof DuplicatorDirective
   */
  private getHTMLElement(e: ElementRef | HTMLElement) {
    if (!!e === false)
      return null;

    if ("nativeElement" in e)
      return (<ElementRef>e).nativeElement;

    if (e instanceof HTMLElement)
      return e;
  }

}
