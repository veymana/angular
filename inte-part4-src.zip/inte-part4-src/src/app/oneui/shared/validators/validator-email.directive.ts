import { Directive, forwardRef, Input } from '@angular/core';
import { NG_VALIDATORS, AbstractControl, ValidationErrors, Validators } from '@angular/forms';
import { ValidatorNames } from './validator-names';
import { IValidator } from './ivalidator';
import { UtilsService } from 'core/utils.service';

@Directive({
  selector: '[validatorEmail][formControlName],[validatorEmail][formControl],[validatorEmail][ngModel]',
  providers: [
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => ValidatorEmailDirective),
      multi: true
    }
  ]
})
export class ValidatorEmailDirective {

  /**
   * The pattern to use.
   * 
   * @private
   * @type {(string | RegExp)}
   * @memberof ValidatorEmailDirective
   */
  @Input("validatorEmail")
  private inputParams: string | RegExp | string[];
  public readonly validationKey: string = ValidatorNames.email;

  constructor() { }

  /**
   * Validates the control value based on email regular expression/pattern
   * If Regular expression is not passed, Angular's Validators.email is used.
   * 
   * @example <textarea [validatorEmail]="regExpPatternInController"></textarea>
   * @example <textarea [validatorEmail]="/someRegEx/"></textarea>
   * @example <textarea validatorEmail></textarea>
   * 
   * To ignore if empty:
   * @example <textarea [validatorEmail]="[regExpPatternInController, true]"></textarea>
   * 
   * To Access errors:
   * @example <textarea validatorEmail [ngModel]="someModel" #modelRef="ngModel"></textarea><span *ngIf="modelRef.errors">{{modelRef.errors | json}}</span>
   * If you use FormGroup, you can check for errors using formgroupObj.hasError('errorKey');
   * 
   * @param {AbstractControl} abstractControl 
   * @returns {{ [key: string]: any }} 
   * @memberof ValidatorEmailDirective
   */
  validate(abstractControl: AbstractControl) {


  }

  public createReturnValue(isValid: boolean): ValidationErrors | never {
    let retVal: ValidationErrors = null;
    if (isValid) return null;

    retVal = {};
    retVal[this.validationKey] = true;
    return retVal;
  }

}
