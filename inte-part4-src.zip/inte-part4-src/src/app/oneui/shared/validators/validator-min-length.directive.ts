import { Directive, forwardRef, Input } from '@angular/core';
import { NG_VALIDATORS, AbstractControl, ValidationErrors, Validators } from '@angular/forms';
import { ValidatorNames } from './validator-names';
import { IValidator } from './ivalidator';
import { UtilsService } from 'core/utils.service';

@Directive({
  selector: '[validatorMinLength][formControlName],[validatorMinLength][formControl],[validatorMinLength][ngModel]',
  providers: [
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => ValidatorMinLengthDirective),
      multi: true
    }
  ]
})
export class ValidatorMinLengthDirective implements IValidator {
  @Input("validatorMinLength")
  private inputParams: number | string[];
  public readonly validationKey: string = ValidatorNames.minLength;

  constructor() { }

  /**
   * @description Validates the control value based on min length.
   * @example <textarea [ngModel]="someModel" validatorMinLength="5"></textarea>
   * @example <textarea formControlName="someFormGroupControl" validatorMinLength="5"></textarea>
   * 
   * To ignore if empty:
   * @example <textarea formControlName="someFormGroupControl" [validatorMinLength]="[5, true]"></textarea>
   * 
   * To Access errors:
   * @example <textarea [ngModel]="someModel" validatorMinLength="5" #someModel="ngModel"></textarea><span *ngIf=someModel.errors>{{someModel.errors | json}}</span>
   * If you use FormGroup, you can check for errors using formgroupObj.hasError('errorKey');
   * 
   * @param {AbstractControl} abstractControl 
   * @returns {ValidationErrors} 
   * @memberof ValidatorMinLengthDirective
   */
  validate(abstractControl: AbstractControl): ValidationErrors {
    let isIgnoreIfEmpty: boolean = false;
    let minLength: number = void 0;
    if (Array.isArray(this.inputParams)) {
      let params: string[] = Object.assign({}, this.inputParams);
      minLength = +params[0];
      isIgnoreIfEmpty = ("" + params[1]).trim().toLowerCase() === "true";
    } else {
      minLength = +this.inputParams;
    }

    if ("" + isIgnoreIfEmpty === "true" && UtilsService.isNullOrUndefinedOrWhitespace(abstractControl.value))
      return this.createReturnValue(true);

    if ((+minLength).toString() === "NaN")
      throw new Error("ValidatorMinLengthDirective: minLength is not a number!");

    return Validators.minLength(minLength)(abstractControl);
  }

  public createReturnValue(isValid: boolean): ValidationErrors {
    let retVal: ValidationErrors = null;
    if (isValid) return null;

    retVal = {};
    retVal[this.validationKey] = true;
    return retVal;
  }

}
