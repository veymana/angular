import { Validator, ValidationErrors } from '@angular/forms';
export interface IValidator extends Validator {
    readonly validationKey: string;
    createReturnValue: (isValid: boolean) => ValidationErrors | never;
}
