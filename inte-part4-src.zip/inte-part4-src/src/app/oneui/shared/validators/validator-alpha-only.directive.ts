import { Directive, forwardRef, Input } from '@angular/core';
import { NG_VALIDATORS, AbstractControl, ValidationErrors, Validators } from '@angular/forms';
import { ValidatorNames } from './validator-names';
import { IValidator } from './ivalidator';
import { UtilsService } from 'core/utils.service';

@Directive({
  selector: '[validatorAlphaOnly][formControlName],[validatorAlphaOnly][formControl],[validatorAlphaOnly][ngModel]',
  providers: [
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => ValidatorAlphaOnlyDirective),
      multi: true
    }
  ]
})
export class ValidatorAlphaOnlyDirective implements IValidator {
  @Input("validatorAlphaOnly")
  private inputParams: boolean = false;
  public readonly validationKey: string = ValidatorNames.alphaOnly;
  constructor() { }

  /**
   * @description Validates the control and checks if value is alpha only.
   * @example <textarea [ngModel]="someModel" validatorAlphaOnly></textarea>
   * 
   * To ignore validation when empty:
   * @example <textarea [ngModel]="someModel" validatorAlphaOnly="true"></textarea>
   * 
   * To Access errors:
   * @example <textarea [ngModel]="someModel" validatorAlphaOnly #modelRef="ngModel"></textarea><span *ngIf="someModel.errors">{{someModel.errors | json}}</span>
   * If you use FormGroup, you can check for errors using formgroupObj.hasError('errorKey');
   * 
   * @param {AbstractControl} abstractControl 
   * @returns {ValidationErrors} 
   * @memberof ValidatorAlphaOnlyDirective
   */
  validate(abstractControl: AbstractControl): ValidationErrors | never {
    let isIgnoreIfEmpty: boolean = ("" + this.inputParams).trim().toLowerCase() === "true";
    if (isIgnoreIfEmpty && UtilsService.isNullOrUndefinedOrWhitespace(abstractControl.value))
      return this.createReturnValue(true);

    return this.createReturnValue(new RegExp("/^[a-z]+$/i").test(abstractControl && abstractControl.value));
  }

  public createReturnValue(isValid: boolean): ValidationErrors | never {
    let retVal: ValidationErrors = null;
    if (isValid) return null;

    retVal = {};
    retVal[this.validationKey] = true;
    return retVal;
  }

}
