export class ValidatorNames {
    public static email: string = "email";
    public static minLength: string = "minLength";
    public static maxLength: string = "maxLength";
    public static dateFormat: string = "dateFormat";
    public static required: string = "required";
    public static numericOnly: string = "numericOnly";
    public static alphaOnly: string = "alphaOnly";
    public static zipCode: string = "zipCode";
    public static pattern: string = "pattern";
    // Can't use length since length is a keyword
    public static valueLength: string = "length";
}
