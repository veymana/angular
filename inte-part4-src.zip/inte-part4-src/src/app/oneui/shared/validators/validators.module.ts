import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ValidatorEmailDirective } from './validator-email.directive';
import { ValidatorMinLengthDirective } from './validator-min-length.directive';
import { ValidatorMaxLengthDirective } from './validator-max-length.directive';
import { ValidatorDateFormatDirective } from './validator-date-format.directive';
import { ValidatorAlphaOnlyDirective } from './validator-alpha-only.directive';
import { ValidatorNumericOnlyDirective } from './validator-numeric-only.directive';
import { ValidatorRequiredDirective } from './validator-required.directive';
import { ValidatorZipCodeDirective } from './validator-zipcode.directive';
import { ValidatorIsEmptyDirective } from './validator-is-empty.directive';
import { ValidatorPatternDirective } from './validator-pattern.directive';
import { ValidatorLengthDirective } from './validator-length.directive';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    ValidatorEmailDirective,
    ValidatorMinLengthDirective,
    ValidatorMaxLengthDirective,
    ValidatorDateFormatDirective,
    ValidatorAlphaOnlyDirective,
    ValidatorNumericOnlyDirective,
    ValidatorRequiredDirective,
    ValidatorZipCodeDirective,
    ValidatorIsEmptyDirective,
    ValidatorPatternDirective,
    ValidatorLengthDirective
  ],
  exports: [
    ValidatorEmailDirective,
    ValidatorMinLengthDirective,
    ValidatorMaxLengthDirective,
    ValidatorDateFormatDirective,
    ValidatorAlphaOnlyDirective,
    ValidatorNumericOnlyDirective,
    ValidatorRequiredDirective,
    ValidatorZipCodeDirective,
    ValidatorIsEmptyDirective,
    ValidatorPatternDirective,
    ValidatorLengthDirective
  ]
})
export class ValidatorsModule { }
