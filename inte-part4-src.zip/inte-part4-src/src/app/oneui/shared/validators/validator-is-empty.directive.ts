import { Directive, forwardRef, Input } from '@angular/core';
import { NG_VALIDATORS, AbstractControl, ValidationErrors, Validators } from '@angular/forms';
import { ValidatorNames } from './validator-names';
import { IValidator } from './ivalidator';
import { UtilsService } from 'core/utils.service';

@Directive({
  selector: '[validatorIsEmpty][formControlName],[validatorIsEmpty][formControl],[validatorIsEmpty][ngModel]',
  providers: [
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => ValidatorIsEmptyDirective),
      multi: true
    }
  ]
})
export class ValidatorIsEmptyDirective implements IValidator {
  public readonly validationKey: string = ValidatorNames.zipCode;
  constructor() { }

  /**
   * @description Validates to test if value is empty/null/undefined/whitespace
   * @example <textarea [ngModel]="someModel" validatorIsEmpty></textarea>
   * 
   * To Access errors:
   * @example <textarea [ngModel]="someModel" validatorIsEmpty #modelRef="ngModel"></textarea><span *ngIf="someModel.errors">{{someModel.errors | json}}</span>
   * If you use FormGroup, you can check for errors using formgroupObj.hasError('errorKey');
   * 
   * @param {AbstractControl} abstractControl 
   * @returns {ValidationErrors} 
   * @memberof ValidatorIsEmptyDirective
   */
  validate(abstractControl: AbstractControl): ValidationErrors | never {
    let currentValue: string = abstractControl.value || "";

    return this.createReturnValue(UtilsService.isNullOrUndefinedOrWhitespace(currentValue) === false);
  }

  public createReturnValue(isValid: boolean): ValidationErrors | never {
    let retVal: ValidationErrors = null;
    if (isValid) return null;

    retVal = {};
    retVal[this.validationKey] = true;
    return retVal;
  }

}
