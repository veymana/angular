import { Directive, forwardRef, Input } from '@angular/core';
import { NG_VALIDATORS, AbstractControl, ValidationErrors, Validators } from '@angular/forms';
import { ValidatorNames } from './validator-names';
import { IValidator } from './ivalidator';
import { UtilsService } from 'core/utils.service';

@Directive({
  selector: '[validatorLength][formControlName],[validatorLength][formControl],[validatorLength][ngModel]',
  providers: [
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => ValidatorLengthDirective),
      multi: true
    }
  ]
})
export class ValidatorLengthDirective implements IValidator {
  @Input("validatorLength")
  private inputParams: string | number | string[];
  public readonly validationKey: string = ValidatorNames.valueLength;

  constructor() { }

  /**
   * @description Validates the control value based on length. Length can be a range: 1-3 or 3-19
   * 
   * To validate based on length:
   * @example <textarea [ngModel]="someModel" validatorLength="5"></textarea>
   * 
   * To validate based on a from-to length: (from 5 to 20)
   * @example <textarea [ngModel]="someModel" validatorLength="5-20"></textarea>
   * 
   * To ignore validation when empty:
   * @example <textarea [ngModel]="someModel" [validatorLength]="['5-20', true]"></textarea>
   * 
   * To Access errors:
   * @example <textarea [ngModel]="someModel" validatorLength="5" #someModel="ngModel"></textarea><span *ngIf=someModel.errors>{{someModel.errors | json}}</span>
   * If you use FormGroup, you can check for errors using formgroupObj.hasError('errorKey');
   * 
   * @param {AbstractControl} abstractControl 
   * @returns {ValidationErrors} 
   * @memberof ValidatorLengthDirective
   */
  validate(abstractControl: AbstractControl): ValidationErrors {
    let isIgnoreIfEmpty: boolean = false;
    let theFromAndTo: string | number = void 0;

    if (Array.isArray(this.inputParams)) {
      let params: string[] = Object.assign({}, this.inputParams);
      theFromAndTo = params[0];
      isIgnoreIfEmpty = ("" + params[1]).trim().toLowerCase() === "true";
    } else {
      theFromAndTo = this.inputParams;
    }

    if ("" + isIgnoreIfEmpty === "true" && UtilsService.isNullOrUndefinedOrWhitespace(abstractControl.value))
      return this.createReturnValue(true);


    let from: number = null;
    let to: number = null;
    if (typeof (theFromAndTo) === "number") {
      from = theFromAndTo;
      to = theFromAndTo;
    } else if (typeof (theFromAndTo) === "string") {
      let parts: string[] = theFromAndTo.split("-");
      if (parts.length === 1) {
        from = +parts[0];
        to = +parts[0];
      } else {
        from = +parts[0];
        to = +parts[1];
      }
    }

    return Validators.compose([Validators.minLength(from), Validators.maxLength(to)])((abstractControl));
  }

  public createReturnValue(isValid: boolean): ValidationErrors {
    let retVal: ValidationErrors = null;
    if (isValid) return null;

    retVal = {};
    retVal[this.validationKey] = true;
    return retVal;
  }

}
