import { Directive, forwardRef, Input } from '@angular/core';
import { NG_VALIDATORS, AbstractControl, ValidationErrors, Validators } from '@angular/forms';
import { ValidatorNames } from './validator-names';
import { IValidator } from './ivalidator';
import { UtilsService } from 'core/utils.service';

@Directive({
  selector: '[validatorDateFormat][formControlName],[validatorDateFormat][formControl],[validatorDateFormat][ngModel]',
  providers: [
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => ValidatorDateFormatDirective),
      multi: true
    }
  ]
})
export class ValidatorDateFormatDirective implements IValidator {
  @Input("validatorDateFormat")
  private inputParams: string | string[];
  public readonly validationKey: string = ValidatorNames.dateFormat;

  constructor() { }

  /**
   * @description Validates the control value based on min length.
   * @example <textarea [ngModel]="someModel" validatorDateFormat="mm/dd/yyyy"></textarea>
   * 
   * To ignore validation if empty:
   * @example <textarea [ngModel]="someModel" [validatorDateFormat]="['mm/dd/yyyy', true]"></textarea>
   * 
   * To Access errors:
   * @example <textarea [ngModel]="someModel" validatorDateFormat="mm/dd/yyyy" #modelRef="ngModel"></textarea><span *ngIf="someModel.errors">{{someModel.errors | json}}</span>
   * If you use FormGroup, you can check for errors using formgroupObj.hasError('errorKey');
   * 
   * @param {AbstractControl} abstractControl 
   * @returns {ValidationErrors} 
   * @memberof ValidatorDateFormatDirective
   */
  validate(abstractControl: AbstractControl): ValidationErrors | never {
    let isIgnoreIfEmpty: boolean = false;
    let dateFormat: string = void 0;
    let currentValue: Date | string = abstractControl.value;

    if (Array.isArray(this.inputParams)) {
      let params: string[] = Object.assign({}, this.inputParams);
      dateFormat = params[0];
      isIgnoreIfEmpty = ("" + params[1]).trim().toLowerCase() === "true";
    } else {
      dateFormat = this.inputParams;
    }

    if (UtilsService.isNullOrUndefinedOrWhitespace(dateFormat)) {
      // Throw error so developers can fix.
      throw new Error("validatorDateFormat must have a correct parameter.");
    }

    if (isIgnoreIfEmpty === true && UtilsService.isNullOrUndefinedOrWhitespace(currentValue))
      return this.createReturnValue(true);

    return this.createReturnValue(UtilsService.isValidDateFormat(currentValue, dateFormat));
  }

  public createReturnValue(isValid: boolean): ValidationErrors | never {
    let retVal: ValidationErrors = null;
    if (isValid) return null;

    retVal = {};
    retVal[this.validationKey] = true;
    return retVal;
  }

}
