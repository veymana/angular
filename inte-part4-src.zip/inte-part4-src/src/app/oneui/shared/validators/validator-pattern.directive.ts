import { Directive, forwardRef, Input } from '@angular/core';
import { NG_VALIDATORS, AbstractControl, ValidationErrors, Validators } from '@angular/forms';
import { ValidatorNames } from './validator-names';
import { IValidator } from './ivalidator';
import { UtilsService } from 'core/utils.service';

@Directive({
  selector: '[validatorPattern][formControlName],[validatorPattern][formControl],[validatorPattern][ngModel]',
  providers: [
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => ValidatorPatternDirective),
      multi: true
    }
  ]
})
export class ValidatorPatternDirective implements IValidator {
  constructor() { }

  /**
   * The pattern to use.
   * 
   * @private
   * @type {(string | RegExp)}
   * @memberof ValidatorEmailDirective
   */
  @Input("validatorPattern")
  private inputParams: string | RegExp;

  public readonly validationKey: string = ValidatorNames.zipCode;

  /**
   * @description Validates pattern
   * @example <textarea [ngModel]="someModel" validatorPattern="[a-z]*"></textarea>
   * 
   * To Ignore if empty:
   * @example <textarea [ngModel]="someModel" [validatorPattern]="['[a-z]*', true]"></textarea>
   * 
   * To Access errors:
   * @example <textarea [ngModel]="someModel" validatorPattern="[a-z]*" #modelRef="ngModel"></textarea><span *ngIf="someModel.errors">{{someModel.errors | json}}</span>
   * If you use FormGroup, you can check for errors using formgroupObj.hasError('errorKey');
   * 
   * @param {AbstractControl} abstractControl 
   * @returns {ValidationErrors} 
   * @memberof ValidatorPatternDirective
   */
  validate(abstractControl: AbstractControl): ValidationErrors | never {
    let patternToUse: string | RegExp = void 0;
    let isIgnoreIfEmpty: boolean = false;

    if (Array.isArray(this.inputParams)) {
      let params: string[] = Object.assign({}, this.inputParams);
      patternToUse = params[0];
      isIgnoreIfEmpty = ("" + params[1]).trim().toLowerCase() === "true";
    } else {
      patternToUse = this.inputParams;
    }

    return Validators.pattern(patternToUse)(abstractControl);
  }

  public createReturnValue(isValid: boolean): ValidationErrors | never {
    let retVal: ValidationErrors = null;
    if (isValid) return null;

    retVal = {};
    retVal[this.validationKey] = true;
    return retVal;
  }

}
