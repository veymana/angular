import { Directive, forwardRef, Input } from '@angular/core';
import { NG_VALIDATORS, AbstractControl, ValidationErrors, Validators } from '@angular/forms';
import { ValidatorNames } from './validator-names';
import { IValidator } from './ivalidator';
import { UtilsService } from 'core/utils.service';


@Directive({
  selector: '[validatorMaxLength][formControlName],[validatorMaxLength][formControl],[validatorMaxLength][ngModel]',
  providers: [
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => ValidatorMaxLengthDirective),
      multi: true
    }
  ]
})
export class ValidatorMaxLengthDirective implements IValidator {
  @Input("validatorMaxLength")
  private inputParams: number | string[];
  public readonly validationKey: string = ValidatorNames.maxLength;

  constructor() { }

  /**
   * @description Validates the control value based on max length.
   * @example <textarea [ngModel]="someModel" validatorMaxLength="5"></textarea>
   * @example <textarea formControlName="someFormGroupControl" validatorMaxLength="5"></textarea>
   * 
   * To ignore if empty:
   * @example <textarea formControlName="someFormGroupControl" [validatorMaxLength]="[5, true]"></textarea>
   * 
   * To Access errors:
   * @example <textarea [ngModel]="someModel" validatorMaxLength="5" #someModel="ngModel"></textarea><span *ngIf="someModel.errors">{{someModel.errors | json}}</span>
   * If you use FormGroup, you can check for errors using formgroupObj.hasError('errorKey');
   * 
   * @param {AbstractControl} abstractControl
   * @returns {ValidationErrors}
   * @memberof ValidatorMaxLengthDirective
   */
  validate(abstractControl: AbstractControl): ValidationErrors {
    let isIgnoreIfEmpty: boolean = false;
    let maxLength: number = void 0;
    if (Array.isArray(this.inputParams)) {
      let params: string[] = Object.assign({}, this.inputParams);
      maxLength = +params[0];
      isIgnoreIfEmpty = ("" + params[1]).trim().toLowerCase() === "true";
    } else {
      maxLength = +this.inputParams;
    }

    if ("" + isIgnoreIfEmpty === "true" && UtilsService.isNullOrUndefinedOrWhitespace(abstractControl.value))
      return this.createReturnValue(true);

    if ((+maxLength).toString() === "NaN")
      throw new Error("ValidatorMaxLengthDirective: maxLength is not a number!");

    return Validators.maxLength(maxLength)(abstractControl);
  }

  public createReturnValue(isValid: boolean): ValidationErrors | never {
    let retVal: ValidationErrors = null;
    if (isValid) return null;

    retVal = {};
    retVal[this.validationKey] = true;
    return retVal;
  }

}
