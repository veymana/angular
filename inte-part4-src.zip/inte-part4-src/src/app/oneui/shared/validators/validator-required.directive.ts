import { Directive, forwardRef, Input } from '@angular/core';
import { NG_VALIDATORS, AbstractControl, ValidationErrors, Validators } from '@angular/forms';
import { ValidatorNames } from './validator-names';
import { IValidator } from './ivalidator';
import { UtilsService } from 'core/utils.service';

@Directive({
  selector: '[validatorRequired][formControlName],[validatorRequired][formControl],[validatorRequired][ngModel]',
  providers: [
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => ValidatorRequiredDirective),
      multi: true
    }
  ]
})
export class ValidatorRequiredDirective implements IValidator {
  constructor() { }

  public readonly validationKey: string = ValidatorNames.alphaOnly;

  /**
   * @description Validates the control if required.
   * @example <textarea [ngModel]="someModel" validatorRequired></textarea>
   * 
   * To Access errors:
   * @example <textarea [ngModel]="someModel" validatorRequired #modelRef="ngModel"></textarea><span *ngIf="someModel.errors">{{someModel.errors | json}}</span>
   * If you use FormGroup, you can check for errors using formgroupObj.hasError('errorKey');
   * 
   * @param {AbstractControl} abstractControl 
   * @returns {ValidationErrors} 
   * @memberof ValidatorRequiredDirective
   */
  validate(abstractControl: AbstractControl): ValidationErrors | never {
    return Validators.required(abstractControl);
  }

  public createReturnValue(isValid: boolean): ValidationErrors | never {
    throw new Error("not implemented");
  }

}
