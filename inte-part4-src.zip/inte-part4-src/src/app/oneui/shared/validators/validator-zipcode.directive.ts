import { Directive, forwardRef, Input } from '@angular/core';
import { NG_VALIDATORS, AbstractControl, ValidationErrors, Validators } from '@angular/forms';
import { ValidatorNames } from './validator-names';
import { IValidator } from './ivalidator';
import { UtilsService } from 'core/utils.service';

@Directive({
  selector: '[validatorZipCode][formControlName],[validatorZipCode][formControl],[validatorZipCode][ngModel]',
  providers: [
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => ValidatorZipCodeDirective),
      multi: true
    }
  ]
})
export class ValidatorZipCodeDirective implements IValidator {
  @Input("validatorZipCode")
  private inputParams: boolean | string = void 0;

  public readonly validationKey: string = ValidatorNames.zipCode;
  constructor() { }

  /**
   * @description Validates zipCode
   * @example <textarea [ngModel]="someModel" validatorZipCode></textarea>
   * 
   * To ignore if emptu:
   * @example <textarea [ngModel]="someModel" validatorZipCode="true"></textarea>
   * 
   * To Access errors:
   * @example <textarea [ngModel]="someModel" validatorZipCode #modelRef="ngModel"></textarea><span *ngIf="someModel.errors">{{someModel.errors | json}}</span>
   * If you use FormGroup, you can check for errors using formgroupObj.hasError('errorKey');
   * 
   * @param {AbstractControl} abstractControl 
   * @returns {ValidationErrors} 
   * @memberof ValidatorZipCodeDirective
   */
  validate(abstractControl: AbstractControl): ValidationErrors | never {
    let isIgnoreIfEmpty: boolean = ("" + this.inputParams).trim().toLowerCase() === "true";
    let currentValue: string = abstractControl.value || "";
    if (isIgnoreIfEmpty && UtilsService.isNullOrUndefinedOrWhitespace(currentValue))
      return this.createReturnValue(true);

    return this.createReturnValue(new RegExp(/^[0-9]{5}$/).test(currentValue));
  }

  public createReturnValue(isValid: boolean): ValidationErrors | never {
    let retVal: ValidationErrors = null;
    if (isValid) return null;

    retVal = {};
    retVal[this.validationKey] = true;
    return retVal;
  }

}
