import { Directive, forwardRef, Input } from '@angular/core';
import { NG_VALIDATORS, AbstractControl, ValidationErrors, Validators } from '@angular/forms';
import { ValidatorNames } from './validator-names';
import { IValidator } from './ivalidator';
import { UtilsService } from 'core/utils.service';

@Directive({
  selector: '[validatorNumericOnly][formControlName],[validatorNumericOnly][formControl],[validatorNumericOnly][ngModel]',
  providers: [
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => ValidatorNumericOnlyDirective),
      multi: true
    }
  ]
})
export class ValidatorNumericOnlyDirective implements IValidator {
  public readonly validationKey: string = ValidatorNames.alphaOnly;
  @Input("validatorNumericOnly")
  private inputParams: boolean = false;

  constructor() { }

  /**
   * @description Validates the control value to test if value is numeric only
   * @example <textarea [ngModel]="someModel" validatorNumericOnly></textarea>
   * 
   * To ignore validation when empty:
   * @example <textarea [ngModel]="someModel" validatorNumericOnly="true"></textarea>
   * 
   * To Access errors:
   * @example <textarea [ngModel]="someModel" validatorNumericOnly #modelRef="ngModel"></textarea><span *ngIf="someModel.errors">{{someModel.errors | json}}</span>
   * If you use FormGroup, you can check for errors using formgroupObj.hasError('errorKey');
   * 
   * @param {AbstractControl} abstractControl 
   * @returns {ValidationErrors} 
   * @memberof ValidatorNumericOnlyDirective
   */
  validate(abstractControl: AbstractControl): ValidationErrors | never {
    let isIgnoreIfEmpty: boolean = ("" + this.inputParams).trim().toLowerCase() === "true";
    if (isIgnoreIfEmpty && UtilsService.isNullOrUndefinedOrWhitespace(abstractControl.value))
      return this.createReturnValue(true);

    return this.createReturnValue(new RegExp("^[0-9]+$").test(abstractControl && abstractControl.value));
  }

  public createReturnValue(isValid: boolean): ValidationErrors {
    let retVal: ValidationErrors = null;
    if (isValid) return null;

    retVal = {};
    retVal[this.validationKey] = true;
    return retVal;
  }

}
