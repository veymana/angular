/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { ScrollToShowDirective } from './scroll-to-show.directive';

describe('ScrollToShowDirective', () => {
  it('should create an instance', () => {
    const directive = new ScrollToShowDirective(null, null);
    expect(directive).toBeTruthy();
  });
});
