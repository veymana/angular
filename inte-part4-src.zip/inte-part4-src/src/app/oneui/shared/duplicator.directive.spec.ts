/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { DuplicatorDirective } from './duplicator.directive';

describe('DuplicatorDirective', () => {
  it('should create an instance', () => {
    const directive = new DuplicatorDirective();
    expect(directive).toBeTruthy();
  });
});
