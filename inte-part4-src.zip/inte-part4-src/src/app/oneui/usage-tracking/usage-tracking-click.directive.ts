import { Directive, ElementRef, Renderer, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UsageTrackingService } from './usage-tracking.service';

@Directive({
  selector: '[usageTrackingClick]'
})
export class UsageTrackingClickDirective {
  @Input('usageTrackingClick') trackingId: string;
  @Input() usageTrackingData: string;


  constructor(private el: ElementRef, private renderer: Renderer, private service: UsageTrackingService, private activatedRoute: ActivatedRoute) {
    this.renderer.listen(this.el.nativeElement, 'click', (event) => {
      // Instead of not passing a screenId to the tracking service, we can pass the url of the activated route.
      this.activatedRoute.url.subscribe(url => {
        let urlString: string = url.join('');
        service.logInteraction(urlString, this.trackingId, this.usageTrackingData);
      });
    });

  }
}
