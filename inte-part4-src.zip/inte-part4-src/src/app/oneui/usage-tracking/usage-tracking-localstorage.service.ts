import { Injectable } from '@angular/core';
import { UsageTrackingData } from './usage-tracking-data.model';

@Injectable()
export class UsageTrackingLocalStorageService {
  localStorageKey: string = 'usageTrackingSystemLog';

  constructor() { }

  getData() {
    return localStorage.getItem(this.localStorageKey);
  }

  getDataSize() {
    let data = this.getData(); 
    return (data != null ? data.length : 0);
  }

  storeData(data: UsageTrackingData) {
    let currentDataString = this.getData();
    let currentData;
    if (currentDataString) {
      currentData = JSON.parse(currentDataString);
    } else {
      currentData = new Array();
    }
    currentData.push(data);
    currentDataString = JSON.stringify(currentData);
    localStorage.setItem(this.localStorageKey, currentDataString);
  }

  clearData() {
    localStorage.removeItem(this.localStorageKey);
  }

}
