/* tslint:disable:no-unused-variable */

import { addProviders, async, inject } from '@angular/core/testing';
import {UsageTrackingData} from './usage-tracking-data';

describe('UsageTrackingData', () => {
  it('should create an instance', () => {
    expect(new UsageTrackingData()).toBeTruthy();
  });
});
