import { Directive, Input, OnInit } from '@angular/core';
import { UsageTrackingService } from './usage-tracking.service';

@Directive({
  selector: '[usageTrackingDisplay]'
})
export class UsageTrackingDisplayDirective implements OnInit {
  @Input('usageTrackingDisplay') trackingId: string;
  @Input() usageTrackingData: string;

  constructor(private service: UsageTrackingService) { }
  
  ngOnInit() {
    this.service.logInteraction(this.trackingId, null, this.usageTrackingData);
  }


}
