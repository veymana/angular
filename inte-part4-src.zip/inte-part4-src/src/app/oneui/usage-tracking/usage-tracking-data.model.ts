import { UtilsService } from 'core/utils.service';

export class UsageTrackingData {

  static readonly SystemEvents = [
    'APPLICATION_START',
    'APPLICATION_CLOSE',
    'SESSIONEXPIREWARNING',
    'SESSIONEXPIRED',
    'SESSIONDUPLICATE',
    'ASSISTANCECONFIRMCANCEL',
    'COMMERROR',
    'COMMRESTORED',
    'ASSISTANCEINPROGRESS',
    'SYSTEMERROR',
    'ACCESSDENIED',
    'AUTHORIZATIONFAILED'
  ];

  static readonly UsageDataElements = {
    'SCREEN_ID': '100',
    'EVENT_ID': '200',
    'ADDITIONAL_INFO': '300',
    'SPECIAL_EVENT': '400'
  };

  static readonly Screens = {
    'dashboard': '10001',
    'admin': '10002',
    'sessiondetails.currenttransaction': '10003',
    'sessiondetails.customerdetails': '10004',
    'sessiondetails.accountdetails': '10005',
    'sessiondetails.additionalId': '10006',
    'sessiondetails.approvalreason': '10007',
    'sessiondetails.transactionhistory': '10018',
    'SESSIONEXPIREWARNING': '10008',
    'SESSIONEXPIRED': '10009',
    'SESSIONDUPLICATE': '10010',
    'ASSISTANCECONFIRMCANCEL': '10011',
    'COMMERROR': '10012',
    'COMMRESTORED': '10013',
    'ASSISTANCEINPROGRESS': '10014',
    'SYSTEMERROR': '10015',
    'ACCESSDENIED': '10016',
    'AUTHORIZATIONFAILED': '10017'
  };

  static readonly Events = {
    'BUTTON_CLOSE_APPLICATION': 20001,
    'BUTTON_DASHBOARD_SCREEN': 20002,
    'BUTTON_ADMIN_SCREEN': 20003,
    'BUTTON_SESSION_DETAILS': 20004,
    'BUTTON_OPEN_ALL_STAFFED_MODE': 21001,
    'BUTTON_CLOSE_ALL_STAFFED_MODE': 21002,
    'BUTTON_OPEN_STAFFED_MODE': 21003,
    'BUTTON_CLOSE_STAFFED_MODE': 21004,
    'BUTTON_MINI_DASHBOARD': 22001,
    'BUTTON_COPY': 22002,
    'BUTTON_TRANSACTION_CURRENT_TAB': 22003,
    'BUTTON_TRANSACTION_CANCEL': 22004,
    'BUTTON_TRANSACTION_CONTINUE': 22005,
    'BUTTON_ASSISTANCE_CLAIM': 22006,
    'BUTTON_ASSISTANCE_COMPLETE': 22007,
    'BUTTON_ASSISTANCE_RELEASE': 22008,
    'BUTTON_ACCOUNT_DETAILS_TAB': 22009,
    'BUTTON_ACCOUNT_COPY': 22010,
    'BUTTON_ACCOUNT_EXPAND': 22011,
    'BUTTON_CUSTOMER_DETAILS_TAB': 22012,
    'BUTTON_ADDITIONAL_ID_CLOSE': 22013,
    'BUTTON_ADDITIONAL_ID_SUBMIT': 22014,
    'BUTTON_APPROVAL_BACK': 22015,
    'BUTTON_APPROVAL_SUBMIT': 22016,
    'BUTTON_TRANSACTION_HISTORY_TAB': 22017,
    'BUTTON_NOTIFICATION_OK': 23001,
    'BUTTON_NOTIFICATION_CANCEL': 23002,
    'BUTTON_NOTIFICATION_CLOSE': 23003,
    'BUTTON_NOTIFICATION': 23004,
    'BUTTON_DEPOSIT_ITEM_SELECT': 24001,
    'BUTTON_DEPOSIT_ITEM_PREV': 24002,
    'BUTTON_DEPOSIT_ITEM_NEXT': 24003,
    'BUTTON_DEPOSIT_ITEM_ZOOM': 24004,
    'BUTTON_DEPOSIT_ITEM_FLIP': 24005,
    'BUTTON_DEPOSIT_ITEM_CLOSE': 24006
  };

  static readonly AdditionalInfo = {
    'ATM_ID': 1,
    'ATM_IDS': 2,
    'ATM_STATUS': 3,
    'CARD_NUMBER': 4,
    'ACCOUNT_NUMBER': 5,
    'BUTTON_ID': 6,
    'CHECK_INDEX': 7,
    'CHECK_AMOUNT': 8,
    'CHECK_STATUS': 9,
    'VIEW_TYPE': 10,
    'IMAGE_AVAILABLE': 11
  };

  static readonly ApplicationEvents = {
    'APPLICATION_START': 40001,
    'APPLICATION_CLOSE': 40002
  };

  static createInstance(applicationState: string, eventId: string, customData: Object) {
    let data = new UsageTrackingData();
    data['t'] = UtilsService.moment().format('YYYYMMDDHHmmss');
    data[this.UsageDataElements.SCREEN_ID] = this.Screens[applicationState];
    if (this.ApplicationEvents[eventId]) {
      // eventID is a special application eventID. Note that there cannot be any eventIds that match application eventIds.
      data[this.UsageDataElements.SPECIAL_EVENT] = this.ApplicationEvents[eventId];
    } else {
      data[this.UsageDataElements.EVENT_ID] = this.Events[eventId];
    }
    if (customData) {
      data[this.UsageDataElements.ADDITIONAL_INFO] = this.createMappingForKeys(customData);
    }
    return data;
  }

  static createMappingForKeys(customData: Object) {
    let retVal = new UsageTrackingData();
    for (let key in customData) {
      if (customData.hasOwnProperty(key)) {
        let v = customData[key];
        if ((typeof v === 'undefined') || (v === ""))
          continue;

        try {
          if (this.AdditionalInfo[key] === this.AdditionalInfo.CARD_NUMBER) {
            v = v.replace(/(\d{5})\d{7}(\d{4})/g, "$1xxxxxxx$2"); //masked card number regex
          }

          if (this.AdditionalInfo[key] === this.AdditionalInfo.ACCOUNT_NUMBER) {
            v = v.replace(/(\d{1,3})\d*(\d{4})/g, "$1xxxx$2"); //masked account number regex
          }
        } catch (ex) {
          customData[key] = "xxxx";
        }

        retVal[this.AdditionalInfo[key]] = v;
      }
    }
    return retVal;
  }

  isPriorityData() {
    return (this[UsageTrackingData.UsageDataElements.SPECIAL_EVENT] === UsageTrackingData.ApplicationEvents.APPLICATION_CLOSE) ||
      (this[UsageTrackingData.UsageDataElements.SCREEN_ID] === UsageTrackingData.Screens.SESSIONEXPIREWARNING) ||
      (this[UsageTrackingData.UsageDataElements.SCREEN_ID] === UsageTrackingData.Screens.COMMRESTORED);
  }

  isSystemEvent() {
    return (this[UsageTrackingData.UsageDataElements.SPECIAL_EVENT] === UsageTrackingData.ApplicationEvents.APPLICATION_START) ||
      (this[UsageTrackingData.UsageDataElements.SPECIAL_EVENT] === UsageTrackingData.ApplicationEvents.APPLICATION_CLOSE) ||
      (this[UsageTrackingData.UsageDataElements.SCREEN_ID] === UsageTrackingData.Screens.SESSIONEXPIRED) ||
      (this[UsageTrackingData.UsageDataElements.SCREEN_ID] === UsageTrackingData.Screens.SESSIONDUPLICATE) ||
      (this[UsageTrackingData.UsageDataElements.SCREEN_ID] === UsageTrackingData.Screens.SESSIONEXPIREWARNING) ||
      (this[UsageTrackingData.UsageDataElements.SCREEN_ID] === UsageTrackingData.Screens.COMMERROR) ||
      (this[UsageTrackingData.UsageDataElements.SCREEN_ID] === UsageTrackingData.Screens.COMMRESTORED);
  }



}
