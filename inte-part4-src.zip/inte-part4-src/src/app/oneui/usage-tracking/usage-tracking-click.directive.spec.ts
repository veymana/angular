/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { UsageTrackingClickDirective } from './usage-tracking-click.directive';

describe('Directive: TrackClick', () => {
  it('should create an instance', () => {
    //let directive = new UsageTrackingClickDirective();
    //expect(directive).toBeTruthy();
  });
});
