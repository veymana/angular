import { Injectable } from '@angular/core';

@Injectable()
export class UsageTrackingConfigService {
  public readonly MAX_DATA_SIZE = 1000;
  public readonly AUTO_SUBMIT_FREQUENCY = 600; // 10 minutes in seconds
  public readonly URL = '/usage-tracking';

  constructor() { }



}
