import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers, Response, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { ApplicationState } from '#shared/application-state.model';
import { ApplicationStateService } from 'core/application-state.service';
import { UsageTrackingData } from './usage-tracking-data.model';
import { UsageTrackingConfigService } from './usage-tracking-config.service';
import { UsageTrackingLocalStorageService } from './usage-tracking-localstorage.service';


@Injectable()
export class UsageTrackingService {
  timer: Observable<number>;
  subscription;
  cache = [];
  currentCacheLength: number = 0;
  isOutstandingSubmit: boolean = false;

  constructor(private config: UsageTrackingConfigService,
    private localStorageService: UsageTrackingLocalStorageService,
    private applicationStateService: ApplicationStateService,
    private http: Http) {
    this.init();
  }

  init() {
    this.startIntervalTimer();
  }

  startIntervalTimer() {
    this.timer = Observable.timer(this.config.AUTO_SUBMIT_FREQUENCY * 1000, this.config.AUTO_SUBMIT_FREQUENCY * 1000); // milliseconds
    this.subscription = this.timer.subscribe(t => {
      this.submitData(null);
    });
  }

  stopIntervalTimer() {
    this.subscription.unsubscribe();
  }

  restartIntervalTimer() {
    this.stopIntervalTimer();
    this.startIntervalTimer();
  }

  destroy() {
    this.submitData(null);
    this.stopIntervalTimer();
  }

  logInteraction(screenId: string, trackingId: string, trackingData: string) {
    if ((!screenId) || (screenId === '')) {
      let currentState: ApplicationState = this.applicationStateService.getCurrentState();
      if (currentState) {
        screenId = currentState.name;
      }
    }
    if (trackingData) {
      try {
        trackingData = JSON.parse(trackingData);
      } catch (e) {
        console.log('Unable to parse trackingData from attribute. Ensure that proper JSON string is passed.');
      }
    }
    let data = UsageTrackingData.createInstance(screenId, trackingId, trackingData);
    this.processData(data);
  }

  processData(data: UsageTrackingData) {
    // calculate size of all data
    let size: number = JSON.stringify(data).length;
    let systemLogSize: number = this.localStorageService.getDataSize();
    if (systemLogSize > this.config.MAX_DATA_SIZE) {
      // clear system log
      this.localStorageService.clearData();
    }

    // check to see if the cached data should be sent to server immediately
    if (data.isPriorityData()) {
      this.submitData(data);
      return;
    }

    if ((size + systemLogSize + this.currentCacheLength) > this.config.MAX_DATA_SIZE) {
      this.submitData(data);
    } else {
      this.saveData(data);
    }
  }

  saveData(data: UsageTrackingData) {
    if ((data) && (data.isSystemEvent())) {
      this.localStorageService.storeData(data);
    } else {
      this.cache.push(data);
      this.currentCacheLength += JSON.stringify(data).length;
      console.log("cache: " + JSON.stringify(this.cache));
      console.log("size:  " + this.currentCacheLength);
    }
  }

  submitData(data: UsageTrackingData) {
    let allData: string = this.getAllUsageData();
    let postObject = {
      usageDataUuid: this.createUUID(),
      usageData: allData
    }
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });

    this.isOutstandingSubmit = true;
    this.clearUsageData(); // empty the cache BEFORE submitting so that subsequent user actions do not trigger another submit
    this.saveData(data); // save the current data. No need to check cache size.
    this.http.post(this.config.URL, JSON.stringify(postObject), options)
      .map(this.handleResponse)
      .catch(this.handleError)
      .subscribe(
      r => {
        console.log(r);
      },
      error => {
        console.log(error);
      }
      );
  }

  handleResponse(response: Response) {
    this.isOutstandingSubmit = false;
    return response.json;
  }

  handleError(error: any) {
    this.isOutstandingSubmit = false;

    let errorMessage: string;
    if (error instanceof Response) {
      const body = error.json() || '';
      const err = body.error || JSON.stringify(body);
      errorMessage = `${error.status} - ${error.statusText || ''} ${err}`;
    } else {
      errorMessage = error.message ? error.message : error.toString();
    }
    return Observable.throw(error.json().error)
  }

  clearUsageData() {
    this.cache = [];
    this.currentCacheLength = 0;
    this.localStorageService.clearData();
  }

  getAllUsageData() {
    let systemLogString = this.localStorageService.getData();
    let systemLog = [];
    if ((systemLogString) && (systemLogString.length > 0)) {
      systemLog = JSON.parse(systemLogString);
    }
    let combinedLog = systemLog.concat(this.cache);
    if (combinedLog.length == 0) {
      return null;
    } else {
      return JSON.stringify(combinedLog);
    }
  }

  createUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }

}
