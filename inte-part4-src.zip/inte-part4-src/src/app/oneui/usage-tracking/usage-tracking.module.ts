import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UsageTrackingClickDirective } from './usage-tracking-click.directive';
import { UsageTrackingDisplayDirective } from './usage-tracking-display.directive';
import { UsageTrackingService } from './usage-tracking.service';
import { UsageTrackingConfigService } from './usage-tracking-config.service';
import { UsageTrackingLocalStorageService } from './usage-tracking-localstorage.service';


@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    UsageTrackingClickDirective,
    UsageTrackingDisplayDirective
  ],
  exports: [
    UsageTrackingClickDirective,
    UsageTrackingDisplayDirective
  ],
  providers: [
    //{ provide: UsageTrackingService, useClass: UsageTrackingMockService }
    UsageTrackingService,
    UsageTrackingConfigService,
    UsageTrackingLocalStorageService
  ],
})
export class UsageTrackingModule { }
