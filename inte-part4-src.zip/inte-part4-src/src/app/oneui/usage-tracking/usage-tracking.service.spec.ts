/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { UsageTrackingService } from './usage-tracking.service';

describe('Service: UsageTracking', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [UsageTrackingService]
    });
  });

  it('should ...', inject([UsageTrackingService], (service: UsageTrackingService) => {
    expect(service).toBeTruthy();
  }));
});
