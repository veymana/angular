/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { UsageTrackingConfigService } from './usage-tracking-config.service';

describe('Service: UsageTrackingConfig', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [UsageTrackingConfigService]
    });
  });

  it('should ...', inject([UsageTrackingConfigService], (service: UsageTrackingConfigService) => {
    expect(service).toBeTruthy();
  }));
});
