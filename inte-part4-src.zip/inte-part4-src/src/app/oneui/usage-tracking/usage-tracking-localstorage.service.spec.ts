/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { UsageTrackingLocalStorageService } from './usage-tracking-localstorage.service';

describe('Service: UsageTrackingLocalstorage', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [UsageTrackingLocalStorageService]
    });
  });

  it('should ...', inject([UsageTrackingLocalStorageService], (service: UsageTrackingLocalStorageService) => {
    expect(service).toBeTruthy();
  }));
});
