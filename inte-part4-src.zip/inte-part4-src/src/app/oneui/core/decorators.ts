export function SetEnumerable(value: boolean): any {
    return function (target: any, propertyKey: string): any{
        let descriptor: PropertyDescriptor = Object.getOwnPropertyDescriptor(target, propertyKey) || {};
        if (descriptor.enumerable !== value) {
            descriptor.enumerable = value;
            Object.defineProperty(target, propertyKey, descriptor);
        }
    };
}