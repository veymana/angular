import { Injectable } from '@angular/core';
import { IHeaderTool, IHeaderTools, IHeaderToolList } from './models';
import { Router, ActivatedRoute } from '@angular/router';

/**
 * Service for header items
 * 
 * @export
 * @class HeaderService
 */
@Injectable()
export class HeaderService {

  /**
   * Collection of all registered header tools
   * 
   * @private
   * @type {IHeaderToolList}
   * @memberOf HeaderService
   */
  public headerTools: IHeaderToolList = {};

  /**
   * Query Params from activated Route
   * 
   * @private
   * @type {{ [key: string]: any }}
   * @memberof HeaderService
   */
  private queryParams: { [key: string]: any };

  /**
   * Creates an instance of HeaderService.
   * @param {Router} router 
   * 
   * @memberOf HeaderService
   */
  constructor(private router: Router, private activatedRoute: ActivatedRoute) {
    this.subscribeToQueryParamsChange();
  }

  /**
   * Registers a header tool to the list
   * 
   * @param {IHeaderTool} headertool 
   * 
   * @memberOf HeaderService
   */
  public register(headertool: IHeaderTool): void {
    this.headerTools[headertool.id] = headertool;
  }
  /**
   * Checks if an outletname is activated.
   * returns active outlet Id 
   * 
   * @param {string} outletName 
   * @returns {string} 
   * 
   * @memberOf HeaderService
   */

  public getActiveOutletId(outletName: string): string {
    for (let key in this.headerTools)
      if (this.headerTools[key].isActive)
        return this.headerTools[key].id;
  }
  /**
   * Checks if an outletname is activated.
   * 
   * @param {string} outletName 
   * @returns {boolean} 
   * 
   * @memberOf HeaderService
   */
  public isOutletActive(outletName: string): boolean {
    for (let key in this.headerTools)
      if (this.headerTools[key].isActive)
        return true;
    return false;
  }

  /**
   * Subscribes to queryParams changes of the activatedRoute to preserve them
   * when toggling header tools due to router.navigate() calls.
   * 
   * @private
   * 
   * @memberof HeaderService
   */
  private subscribeToQueryParamsChange(): void {
    this.activatedRoute.queryParams.subscribe(
      (qp: any) => { this.queryParams = qp; }
    );
  }

  /**
   * Toggles a header tool  
   * 
   * @param {string} id 
   * 
   * @memberOf HeaderService
   */
  public toggle(id: string): void {

    if (!!(this.headerTools[id] && this.headerTools[id].routePath && this.headerTools[id].outlet) === false) {
      console.warn(`${HeaderService.name}.toggle: Unable to toggle`);
      return;
    }

    let outletName: string = this.headerTools[id].outlet;
    let routePath: string = this.headerTools[id].routePath;

    let navigateParam: any = {};
    navigateParam[outletName] = [routePath];
    if (this.headerTools[id] && this.headerTools[id].isActive)
      navigateParam[outletName] = null;
    this.headerTools[id].isActive = !this.headerTools[id].isActive;
    if (this.headerTools[id].isActive) {
      // Deactivate any other headerTools using the same outlet.
      Object.keys(this.headerTools).forEach((otherId: string) => {
        let headerTool: IHeaderTool = this.headerTools[otherId];
        if ((otherId !== id) && (headerTool.outlet === outletName) && (headerTool.isActive)) {
          headerTool.isActive = false;
        }
      });
    }
    this.router.navigate([{ outlets: navigateParam }], { queryParams: this.queryParams });
  }

}

