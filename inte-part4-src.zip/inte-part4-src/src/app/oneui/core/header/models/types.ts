import { IHeaderTool } from '.';

export type IHeaderTools = IHeaderTool[];