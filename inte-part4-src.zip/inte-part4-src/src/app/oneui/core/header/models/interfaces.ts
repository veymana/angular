/**
 * Header Tool interface
 * 
 * @export
 * @interface IHeaderTool
 */
export interface IHeaderTool {
  toolType: string;
  id: string;
  outlet: string;
  routePath: string;
  isActive: boolean;
}

/**
 * Header Tool List interface
 * 
 * @interface IHeaderToolList
 */
export interface IHeaderToolList {
  [id: string]: IHeaderTool;
}
