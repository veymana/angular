import { Injectable, Inject, Optional } from '@angular/core';
import { AppSettings } from '#environments/environment';
import { UtilsService } from 'core/utils.service';
import { Observable, BehaviorSubject } from 'rxjs';
import { Router } from '@angular/router';
import { GlobalInjector } from 'core/global-injector';

export interface ILaunchDetails {
  readonly url: string;
  readonly hash?: string;
  readonly queryParams?: Map<string, any>;
  readonly search?: string;
}

@Injectable()
export class StartupService {

  /**
   * Information regarding how this app was launched.
   * 
   * @type {ILaunchDetails}
   * @memberof StartupService
   */
  public launchDetails: ILaunchDetails = void 0;

  public static isBootstrapped: boolean = false;

  /**
   * Constructor
   * 
   * @memberOf StartupService
   */
  constructor() {
    this._startupTime = new Date();
    let parsedQp: Map<string, any> = UtilsService.queryParamsToMap<string>(location.search);
    this.launchDetails = {
      hash: location.hash,
      url: location.href,
      search: location.search,
      queryParams: parsedQp
    };
    console.info(`##### Application is starting. Launched with: ${this.launchDetails.url}`);
  }

  /**
   * Startuptime object
   * 
   * @private
   * @type {Date}
   * @memberOf StartupService
   */
  private _startupTime: Date;

  /**
   * init before bootstrap, which means angular is not fully loaded yet.
   * This must be called prior to bootstrap().
   * Must be injected on an AppModule constructor so it runs first
   * 
   * NOTE: the instance created in this is a different instance from the providers list (which is a singleton injected by angular).
   * @memberOf StartupService
   */
  public initBeforeBootstrap(): Observable<boolean> {
    let s: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(true);
    console.info(AppSettings.STARTUPINFO);
    s.next(true);
    return s.asObservable().share();
  }

  /**
   * init after bootstrap. AppComponent is initialized and being bootstrapped.
   * This must be called AFTER bootstrap().
   * Must be injected on an AppComponent onInit constructor so it runs first right after bootstrap.
   * 
   * NOTE: the instance created in this is a different instance from the initBeforeBootstrap's instance (created in AppModule ctor).
   * When using this instance, use the provider created by bootstrap(), which is the actual angular service.
   * @memberOf StartupService
   */
  public initAfterBootstrap(): void {
    StartupService.isBootstrapped = true;

    // Check required QueryParams
    let missingParams: string[] = [];
    let requiredQueryParams: string[] = UtilsService.getNestedProperty(AppSettings.StartupConfig, "requiredQueryParams");
    if (Array.isArray(requiredQueryParams) && requiredQueryParams.length > 0) {
      for (let i: number = 0; i < requiredQueryParams.length; i++) {
        if (this.launchDetails.queryParams.has(requiredQueryParams[i]) === false) {
          missingParams.push(requiredQueryParams[i]);
        }
      }
    }
    if (missingParams.length > 0) {
      let router: Router = GlobalInjector.INJECTOR && GlobalInjector.INJECTOR.get<Router>(Router);
      if (!!router && router instanceof Router)
        router.navigate(["deadend", { errorId: "SYSTEMERROR", error: `Missing required Params: ${missingParams.join(', ')}` }]);
    }

    console.info("##### Application bootstrapped..");
  }

  /**
   * Returns DateTime when app was started
   * 
   * @readonly
   * @type {Date}
   * @memberOf StartupService
   */
  public get startuptime(): Date {
    return this._startupTime;
  }

  /**
   * Returns current uptime in milliseconds
   * 
   * @readonly
   * @type {Number}
   * @memberOf StartupService
   */
  public get uptimeInMilliseconds(): number {
    return (+(new Date()) - +(this._startupTime));
  }

}
