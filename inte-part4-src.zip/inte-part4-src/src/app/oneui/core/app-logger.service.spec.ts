/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { AppLoggerService } from './app-logger.service';

describe('AppLoggerService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AppLoggerService]
    });
  });

  it('should ...', inject([AppLoggerService], (service: AppLoggerService) => {
    expect(service).toBeTruthy();
  }));
});
