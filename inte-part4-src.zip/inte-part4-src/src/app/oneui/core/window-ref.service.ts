import { Injectable } from '@angular/core';

/**
 * Window Reference Service
 * Exposes window object
 * 
 * @export
 * @class WindowRefService
 */
@Injectable()
export class WindowRefService {
  /**
   * window object
   * 
   * @readonly
   * @static
   * @type {*}
   * @memberOf WindowRefService
   */
  public static get nativeWindow(): any {
    return window;
  }
}

