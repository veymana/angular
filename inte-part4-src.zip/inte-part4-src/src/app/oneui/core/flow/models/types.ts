import { IFlow, Flow } from '.';

export type IFlows = Array<IFlow>;
export type Flows = Array<Flow>;