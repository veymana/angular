import { Flows, Flow, IFlows } from '.';

export interface IChannel {
    defaultChannel: string;
    [channel: string]: string | Flows | IFlows;
}

export interface IContextualMessage {
    type: "SUCCESS" | "FAIL";
    message: string;
}

export interface IFlowMeta {
    index: number;
    flow: Flow;
}
export interface IRouteMeta {
    path: string;
    outlet?: string;
}

export interface IFlow {
    /**
     * Id
     * 
     * @type {string}
     * @memberOf FlowSteps
    */
    id: string;

    /**
     * Router Id
     * @type {string}
     * @memberOf FlowSteps
     */
    route: IRouteMeta;

    /**
     * Data
     * 
     * @type {string}
     * @memberOf FlowSteps
     */
    data?: any;

    /**
     * Data
     * 
     * @type {string}
     * @memberOf FlowSteps
     */
    constants?: {
        [key: string]: any;
        /**
         * Header Text
         * 
         * @type {string}
         * @memberOf FlowSteps
         */
        headerText?: string;
    };

    /**
     * Is Completed
     * 
     * @type {Boolean}
     * @memberOf FlowSteps
     */
    isComplete: boolean;

    /**
     * A flow may be abstract only, i.e., data container
     * 
     * @type {boolean}
     * @memberOf IFlow
     */
    isAbstract?: boolean;
}

/**
 * State of the flow.
 * unknown: default
 * pristine: flow has not yet been started
 * dirty: flow had started
 * 
 * @export
 * @enum {number}
 */
export enum FlowStateEnum {
    unknown = -1,
    pristine = 0,
    dirty = 1
}

/**
 * Components that serve as the main entry point of the app must
 * implement dirtyCheck(). dirtyCheck should check data and set flowService.dirty() or flowService.pristine()
 * 
 * @export
 * @abstract
 * @class FirstFlow
 */
export abstract class FirstFlow {
    abstract dirtyCheck(): void;
}

export interface IChannelStartedEvent {

    /**
     * True if a channel was started
     * 
     * @type {boolean}
     * @memberof IChannelStartedEvent
     */
    wasStarted?: boolean;


    /**
     * True if start() was called with isReset=true
     * 
     * @type {boolean}
     * @memberof IChannelStartedEvent
     */
    wasReset?: boolean;
}