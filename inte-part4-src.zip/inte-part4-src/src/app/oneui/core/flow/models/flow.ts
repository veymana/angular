import { IFlow, IFlows, Flows, IRouteMeta } from '.';

/**
 * flow steps Model
 * 
 * @export
 * @class Flowsteps
 */

export class Flow implements IFlow {

  /**
   * Id
   * 
   * @type {string}
   * @memberOf FlowSteps
  */
  public id: string = "";

  /**
   * Router Id
   * 
   * @type {string}
   * @memberOf FlowSteps
   */
  public route: IRouteMeta = void 0;

  /**
   * Data
   * 
   * @type {string}
   * @memberOf FlowSteps
   */
  public data: any = null;

  /**
   * Data
   * 
   * @type {string}
   * @memberOf FlowSteps
   */
  public constants: {
    [key: string]: any;
    /**
     * Header Text
     * 
     * @type {string}
     * @memberOf FlowSteps
     */
    headerText: string;
  };


  /**
   * Is Completed
   * 
   * @type {Boolean}
   * @memberOf FlowSteps
   */
  public isComplete: boolean = false;

  /**
   * A flow may be abstract only, i.e., data container
   * 
   * @type {boolean}
   * @memberOf IFlow
   */
  public isAbstract?: boolean = false;


  /**
   * Creates an instance of steps for the flow.
   * 
   * @param none
   * 
   * @memberOf Flow Steps
   */
  public constructor(id: string, route: IRouteMeta, data: Object, isComplete: boolean, constants: any, isAbstract: boolean = false) {
    this.id = id;
    this.route = route;
    this.data = data;
    this.isComplete = isComplete;
    this.isAbstract = isAbstract;
    this.constants = constants;
  }

  /**
   * Converts IFlow to Flow
   * 
   * @static
   * @param {IFlow} iflow 
   * @returns 
   * 
   * @memberOf Flow
   */
  public static convert(iflowOriFlows: IFlow | IFlows): Flow | Flows {
    if (!Array.isArray(iflowOriFlows)) {
      let f: IFlow = iflowOriFlows as IFlow;
      return new Flow(
        f.id,
        f.route,
        f.data,
        f.isComplete,
        f.constants,
        f.isAbstract || false
      ) as Flow;
    } else {
      let ifs: IFlows = iflowOriFlows as IFlows;
      let fs: Flows = new Array<Flow>();

      for (let f of ifs) {
        fs.push(<Flow>Flow.convert(<Flow>f));
      }
      return fs as Flows;
    }
  }


}
