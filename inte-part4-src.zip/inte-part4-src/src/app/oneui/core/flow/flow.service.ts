import { Injectable, Inject, Injector, Optional, HostListener, SkipSelf } from '@angular/core';
import { Location, PopStateEvent } from '@angular/common';
import { Subject, BehaviorSubject, Subscription, Observable } from 'rxjs';
import { Router, Params, CanActivate, NavigationEnd, NavigationStart } from '@angular/router';
import { Flow, Flows, IChannel, IContextualMessage, IFlowMeta, FlowStateEnum, IChannelStartedEvent } from './models';
import { UtilsService } from 'core/utils.service';
import { ComponentLifeCyclePhase } from 'core/base/base.component';
import { AppSettings } from '#environments/environment';
import { WindowRefService } from 'core/window-ref.service';
import { ISettingsFlowServiceConfig } from "#environments/interfaces";

export const FLOW_SERVICE_PRIMARY_TOKEN: string = "___primaryFlowService";

/**
 * FlowService manages data flow between features/products.
 * flows.json must exist inside a folder alias named #compiled-data.
 * 
 * 
 * ### The structrue of the json file is:
 * ```
 * {
 *  "defaultChannel" : "channelId"
 *  "channelId" : [
 *   {
 *           "id": "thisFlowId",
 *           "routerId": "Router path to naviate to",
 *           "data": null,
 *           "isComplete": false
 *    }
 *  ]
 * }
 * ```
 * 
 * ### Description of structure
 * The flows.json contains channel definitions. And each channel contains an array of flowSteps.
 * 
 * @export
 * @class FlowService
 */
@Injectable()
export class FlowService implements CanActivate {

  /**
   * Name of this service
   * 
   * @type {"FlowService"}
   * @memberOf FlowService
   */
  public readonly name: string = "FlowService";

  public static instance: FlowService;

  public static flowSubject: Subject<IFlowMeta> = new Subject<IFlowMeta>();

  private static _configuration: ISettingsFlowServiceConfig = void 0;
  public static get configuration(): ISettingsFlowServiceConfig {
    return FlowService._configuration;
  };

  public get configuration(): ISettingsFlowServiceConfig {
    return FlowService.configuration;
  }

  public static get flowObservable(): Observable<IFlowMeta> {
    return FlowService.flowSubject.asObservable();
  }

  public get flowObservable(): Observable<IFlowMeta> {
    return FlowService.flowSubject.asObservable();
  }

  /**
   * Confirmation Messaging
   * 
   * @type {IConfirmationMessage}
   * @memberOf jskFlowService
   */
  public get contextualMessage(): IContextualMessage {
    return FlowService.contextualMessage;
  }
  public set contextualMessage(m: IContextualMessage) {
    FlowService.contextualMessage = m;
  }
  public static contextualMessage: IContextualMessage;

  private static _flowState: FlowStateEnum = FlowStateEnum.unknown;

  public static injector: Injector = void 0;

  public static channelStartedSubject: Subject<IChannelStartedEvent> = new Subject<IChannelStartedEvent>();

  /**
   * Emits an event is a channel was started.
   * 
   * @readonly
   * @type {Observable<IChannelStartedEvent>}
   * @memberof FlowService
   */
  public get channelStartedEvent(): Observable<IChannelStartedEvent> {
    return FlowService.channelStartedSubject.asObservable().share();
  }

  /**
   * Returns the state of the flow.
   * Dirty if it was started. Pristine if not.
   * Can also be overridden by explicitly setting.
   * @see {flowState} setter
   * 
   * @type {FlowStateEnum}
   * @memberof FlowService
   */
  public get flowState(): FlowStateEnum {
    if (FlowService._flowState !== FlowStateEnum.unknown)
      return FlowService._flowState;

    // Check for any data that was set:
    let fWithData = this.find(f => f && f.id !== "metadata" && typeof (f.data) !== "undefined" && f.data !== null);
    if (!!fWithData === true)
      return FlowStateEnum.dirty;
    else
      return FlowStateEnum.pristine;
  }

  public set flowState(s: FlowStateEnum) {
    FlowService._flowState = s;
  }

  /**
   * Injector
   * 
   * @readonly
   * @type {Injector}
   * @memberof FlowService
   */
  public get injector(): Injector {
    return FlowService.injector;
  }

  /**
   * Creates an instance of FlowService.
   * @param {Router} router 
   * 
   * @memberOf FlowService
   */
  constructor(protected router: Router,
    injector: Injector,
    private location: Location,
    @Inject(FLOW_SERVICE_PRIMARY_TOKEN) token: string) {
    FlowService._configuration = AppSettings.FlowServiceSetting;
    FlowService.instance = this;
    FlowService.injector = injector;
    FlowService.channelStartedSubject.asObservable().subscribe(event => this.isChannelStarted = event.wasStarted);

    if (this instanceof FlowService && token === FLOW_SERVICE_PRIMARY_TOKEN)
      location.subscribe((e: PopStateEvent) => { this.onBrowserNavigation(e) });
  }

  /**
   * __RAW__ Main flow definition
   * 
   * 
   * @memberOf FlowService
   */
  private static get _channels$(): any {
    return FlowService.configuration && FlowService.configuration.flows;
  };

  public static get channels(): IChannel {
    return <IChannel>FlowService._channels$;
  }

  public get channels(): IChannel {
    return <IChannel>FlowService.channels;
  }

  /**
   * ID of the channel that is currently in use.
   * 
   * @type {string}
   * @memberOf FlowService
   */
  public static currentChannelId: string = void 0;

  /**
   * ID of the channel that is currently in use.
   * 
   * @type {string}
   * @memberOf FlowService
   */
  public get currentChannelId(): string {
    return FlowService.currentChannelId;
  }

  /**
   * Channel that is currently in use.
   * 
   * @readonly
   * @type {FlowSteps}
   * @memberOf FlowService
   */
  public get currentChannel(): Flows {
    let currentChannelId = FlowService.currentChannelId;
    if (!!currentChannelId === false)
      FlowService.currentChannelId = FlowService.channels.defaultChannel;

    return <Flows>this.channels[FlowService.currentChannelId];
  }

  /**
   * Current Flow that contains both index and flow data.
   * 
   * @private
   * @type {IFlowMeta}
   * @memberOf FlowService
   */
  private static _current: IFlowMeta = void 0;

  private get current(): IFlowMeta {
    if (!!FlowService._current === false) {
      this.setCurrentFlow(0);
    }

    return FlowService._current;
  }

  private set current(value) {
    FlowService._current = value;
    if (UtilsService.getNestedProperty(value, "flow.id") !== "metadata") {
      FlowService.flowSubject.next(value);
    }
  }

  /**
   * Current flow
   * 
   * @type {FlowStep}
   * @memberOf FlowService
   */
  public get currentFlow(): Flow {
    let currentChannel: Flows = this.currentChannel || this.getDefaultChannel();
    let currentIndex: number = 0;

    if (!!this.current === true)
      currentIndex = this.current.index;

    return currentChannel[currentIndex];
  }

  /**
   * Retrieves the default flow
   * 
   * @returns 
   * 
   * @memberOf FlowService
   */
  public getDefaultChannel(): Flows {
    if (!!this.channels === false ||
      !!this.channels.defaultChannel === false) {
      let errMsg = `${this.name} getDefaultChannel error: no defaultChannel was defined.`;
      console.error(errMsg, this.channels);
      throw new Error(errMsg);
    }

    if (!!this.channels[this.channels.defaultChannel] === false
      || Array.isArray(this.channels[this.channels.defaultChannel]) === false) {
      let errMsg = `${this.name} getDefaultChannel error: The default Channel is invalid.`;
      console.error(errMsg, this.channels[this.channels.defaultChannel] || {});
    }

    return <Flows>this.channels[this.channels.defaultChannel];
  }

  /**
   * Returns all Flows based on flow Id
   * 
   * @param {string} flowId 
   * @returns {FlowSteps} 
   * 
   * @memberOf FlowService
   */
  public getFlows(channelId: string): Flows {
    if (!!channelId === false)
      return this.getDefaultChannel();

    console.log("List of channels..");
    console.log(this.channels);
    console.log("List of channels....END");
    if (!!this.channels === false ||
      !!this.channels[channelId] === false) {
      let errMsg = `${this.name} getDefaultFlow error: Flow for ${channelId} not found.`;
      console.error(errMsg, this.channels);
      throw new Error(errMsg);
    }

    return <Flows>this.channels[channelId];
  }

  /**
   * Sets the current flow.
   * 
   * @param {(number | IFlowMeta | Flow)} indexOrFlowOrMeta 
   * @param {boolean} [isNavigateToRoute=false] 
   * 
   * @memberOf FlowService
   */
  public setCurrentFlow(indexOrFlowOrMeta: number | IFlowMeta | Flow, isNavigateToRoute: boolean = false): void {
    // Param is Flow
    if (indexOrFlowOrMeta instanceof Flow || !!indexOrFlowOrMeta['id']) {
      let flow: Flow = <Flow>indexOrFlowOrMeta;
      let index: number = this.currentChannel.findIndex(f => f.id == flow.id);
      this.current = {
        index: index,
        flow: flow
      };
    }
    // Param is an index
    else if (typeof (indexOrFlowOrMeta) === "number") {
      let index: number = indexOrFlowOrMeta;
      this.current = {
        index: index,
        flow: this.currentChannel[index]
      };
    }
    // Param is IFlowMeta
    else if (typeof (indexOrFlowOrMeta['index']) === "number" && indexOrFlowOrMeta['flow'] instanceof Flow) {
      this.current = indexOrFlowOrMeta;
    }
    // Unknown
    else {
      console.error(`${this.name}.setCurrentFlow. Invalid argument`);
    }

    // The next flow may be abstract.
    if (!!this.current.flow.isAbstract) {
      this.setCurrentFlow(this.current.index + 1, isNavigateToRoute);
      return;
    }

    if (isNavigateToRoute && !!this.current.flow.route.path === true) {
      if (!!this.current.flow.route.outlet) {
        let outlet: any = {};
        outlet[this.current.flow.route.outlet] = [this.current.flow.route.path];
        this.router.navigate([{ outlets: outlet }]);
      } else
        this.router.navigate([this.current.flow.route.path]);
    }

  }

  /**
   * Returns the next step from the flows of the current channel.
   * A predicate function can be passed to serve as the filter.
   * Otherwise, the default predicate will be used, i.e., search for the next step with isComplete==false.
   * 
   * @param {Function} [predicate] 
   * @returns {Flow} Flow if found. Null if not.
   * 
   * @memberOf FlowService
   */
  public find(predicate?: (value: Flow, index: number, obj: Array<Flow>) => boolean): Flow {
    let currentFlows = this.getFlows(FlowService.currentChannelId);

    if (!!predicate === true) {
      return currentFlows.find(predicate);
    }

    let index: number = currentFlows && currentFlows.findIndex(flow => !!flow.isComplete === false && flow.id !== "metadata");
    if (index > -1)
      return currentFlows[index];

    return null;
  }

  /**
   * Goes to the next step.
   * If a predicate is used, it will go to that step based on the predicate.
   * 
   * @param {(value: Flow, index: number, obj: Array<Flow>) => boolean} predicate 
   * @param {boolean} [isComplete=true] isFlow complete?
   * 
   * @memberOf FlowService
   */
  public next(stepData?: any, isComplete: boolean = true, predicate?: (value: Flow, index: number, obj: Array<Flow>) => boolean): void {
    this.setData(stepData, null, false, isComplete);

    let nextFlow: Flow = this.find(predicate);

    if (nextFlow !== null) {
      this.setCurrentFlow(nextFlow, true);
      this.dirty();
    }
    else
      this.complete();
  }

  public complete() {
    console.log("COMPLETE!");
  }

  /**
   * Sets the data for the current Flow
   * 
   * @param {*} [stepData] Data to set
   * @param {string} [flowId] flow to set
   * @param {boolean} [isComplete=true] sets flow(from flowId) as complete also
   * 
   * @memberOf FlowService
   */
  public setData(stepData?: any, flowId?: string, isAppend: boolean = false, isComplete: boolean = true) {
    let flow: Flow = this.currentFlow;

    if (typeof (stepData) === "undefined")
      stepData = "Dummy";

    if (!!flowId === true)
      flow = this.find(flow => flow.id === flowId)

    if (!!flow) {
      if (isAppend) {
        flow.data = Object.assign({}, flow.data, UtilsService.clone(stepData));
      }
      else {
        flow.data = UtilsService.clone(stepData);
      }

      flow.isComplete = isComplete;
    }
  }

  /**
   * Sets a flow as completed
   * 
   * @param {string} [flowId] 
   * 
   * @memberOf FlowService
   */
  public setComplete(flowId?: string) {
    let flow: Flow = this.currentFlow;
    if (!!flowId === true)
      flow = this.currentChannel[flowId];
    flow.isComplete = true;
  }

  /**
   * Activates to the previous flow.
   * 
   * 
   * @memberOf FlowService
   */
  public previous(): void {
    let previousIndex: number = 0;
    if (this.current.index > 1) {
      previousIndex = this.current.index - 1;
      while (!!this.currentChannel[previousIndex].isAbstract) {
        previousIndex--;
      }
    }
    let previousFlow = this.currentChannel[previousIndex];
    previousFlow.isComplete = false;

    this.setCurrentFlow(this.currentChannel[previousIndex], true);
  }

  /**
   * Resets current Flow as isComplete = false
   * 
   * @param {boolean} [isResetData=false] If true, data is also reset
   * @param {boolean} [isReload=false] If true, the route is reloaded.
   * @memberOf FlowService
   */
  public resetCurrentFlow(isResetData: boolean = false, isReload: boolean = false, isIgnoreDirtyCheck: boolean = false): Observable<boolean> {
    let resetterSubj: Subject<boolean> = new Subject<boolean>();
    this.current && (this.current.flow.isComplete = false);
    if (!!isResetData && this.flowState === FlowStateEnum.dirty && isIgnoreDirtyCheck !== true) {

      let dataLossCallBack: () => (Observable<boolean> | Promise<boolean>) = AppSettings.FlowServiceSetting.possibleDataLossCallback;
      if (!!dataLossCallBack === true) {
        let callBackResult: (Observable<boolean> | Promise<boolean>) = dataLossCallBack();
        let callBackObs: Observable<boolean>;
        if (callBackResult instanceof Promise) {
          callBackObs = Observable.fromPromise(callBackResult)
        } else if (callBackResult instanceof Observable) {
          callBackObs = callBackResult;
        }
        callBackObs.subscribe(isUserClickedContinue => {
          if (isUserClickedContinue) {
            let f = this.currentChannel.find(f => f.id === this.current.flow.id);
            delete this.current.flow.data;
            delete f.data;
            isReload && (this.router.navigate([this.current.flow.route.path]));
          }
          resetterSubj.next(isUserClickedContinue);

        })
      } else {
        let f = this.currentChannel.find(f => f.id === this.current.flow.id);
        delete this.current.flow.data;
        delete f.data;
        resetterSubj.next(false);
        isReload && (this.router.navigate([this.current.flow.route.path]));
      }
    }
    return resetterSubj.asObservable();
  }

  /**
   * Retrieves a flowId:value pair for all the data in the current channel
   * 
   * @returns 
   * 
   * @memberOf FlowService
   */
  public getChannelData(): { [key: string]: any } {
    let retVal: { [key: string]: any } = {}

    // First inject constants:
    for (let flow of this.currentChannel) {
      retVal[flow.id] = UtilsService.clone(flow.data || {});
    }

    return retVal;
  }

  /**
   * Retrieves a flowId:value pair for all the constants in the current channel
   * 
   * @returns 
   * 
   * @memberOf FlowService
   */
  public getChannelConstants(): { [key: string]: any } {
    let retVal: { [key: string]: any } = {}

    // First inject constants:
    for (let flow of this.currentChannel) {
      retVal[flow.id] = UtilsService.clone(flow.constants || {});
    }

    return retVal;
  }

  /**
   * Retrieves the data from a specific flow Id
   * 
   * @param {string} flowId 
   * @returns 
   * 
   * @memberOf FlowService
   */
  public getFlowData(flowId: string): any {
    let flow: Flow = this.findFlowById(flowId);

    if (!!flow === true)
      return flow.data;

    return null;
  }


  /**
   * Retrieves the constants from a specific flow Id
   * 
   * @param {string} flowId 
   * @returns 
   * 
   * @memberOf FlowService
   */
  public getFlowConstants(flowId: string): any {
    let flow: Flow = this.findFlowById(flowId);

    if (!!flow === true)
      return flow.constants;

    return null;
  }

  /**
   * Returns all data and constants for the entier channel
   * 
   * @returns {{ constants: { [key: string]: any }, data: { [key: string]: any } }} 
   * 
   * @memberOf FlowService
   */
  public getChannelDataAndConstants(): { constants: { [key: string]: any }, data: { [key: string]: any } } {
    return {
      constants: this.getChannelConstants() || {},
      data: this.getChannelData() || {}
    };
  }

  /**
   * Retrieves a flow from the current channel based on flow id.
   * 
   * @private
   * @param {string} flowId 
   * @returns {Flow} 
   * 
   * @memberOf FlowService
   */
  public findFlowById(flowId: string): Flow {
    let flow: Flow = this.find(f => f && f.id === flowId);
    return flow;
  }

  /**
   * Clears current channel/flows
   * 
   * 
   * @memberOf FlowService
   */
  public clear(): void {
    this.resetAllData();
    this.current = null;
    console.log(`${this.name}.clear()`);
  }

  /**
   * Resets all *.data buckets
   * 
   * @param {boolean} [isComplete=false] 
   * @param {boolean} [isFromCallback=false] 
   * @returns {Observable<any>} 
   * 
   * @memberof FlowService
   */
  public resetAllData(isComplete: boolean = false, isFromCallback: boolean = false, isIgnoreDataLoss: boolean = false): Observable<boolean> {
    // Default to true (resolved) so flow can continue for unknown conditions.
    let retVal: Observable<boolean> = Observable.of(true);

    // Check if coming from callback to avoid loops.
    // And check if we are on the last step.
    // The last step might reset the data and dirty will be true at that time.
    if (isIgnoreDataLoss === false && !!isFromCallback === false && this.current && this.current.index !== (this.currentChannel.length - 1)) {
      // Before resetting data, check if we need to make another call based on the setting.
      if (this.flowState === FlowStateEnum.dirty) {
        let dataLossCallBack: () => (Observable<boolean> | Promise<boolean>) = AppSettings.FlowServiceSetting.possibleDataLossCallback;

        if (!!dataLossCallBack === false) {
          console.warn(`${this.name}.resetAllData to be called but flow is dirty and callBack is set on AppSettings.`);
          retVal = this.resetAllData(isComplete, false);
        } else {
          let callBackResult: (Observable<boolean> | Promise<boolean>) = dataLossCallBack();
          if (callBackResult instanceof Promise) {
            retVal = Observable.fromPromise(callBackResult);
          } else if (callBackResult instanceof Observable) {
            retVal = callBackResult;
          }
        }
      }
      //reset all flow data when Continue is clicked on dataloss pop-up
      retVal.take(1).subscribe(
        (userAction: boolean) => {
          if (userAction === true) {
            this.resetAllData(isComplete, false, true);
          }
        }
      );

      return retVal;
    }

    for (let channelId of Object.keys(this.configuration.flows)) {
      let channel: any = this.configuration.flows[channelId];
      if (!!channel === false || !Array.isArray(channel))
        continue;

      for (let c of channel) {
        if (!!c["id"] === false)
          continue;

        if (!!c === false)
          continue;
        delete c.data;
        c.isComplete = !!isComplete;
      }
    }
    this.flowState = FlowStateEnum.pristine;
    console.log(`${this.name}.resetAllData()`);

    return retVal;
  }


  /**
   * Sets the current Channel
   * 
   * @private
   * @param {string} [channelId] 
   * 
   * @memberOf FlowService
   */
  public setCurrentChannel(channelId?: string): void {
    let channel: string = channelId || this.channels.defaultChannel;
    FlowService.currentChannelId = channel;
  }

  /**
   * Starts a channel
   * Start will always reset all data.
   * 
   * @param {string} [channelId] Channel Id to start. Otherise, the defaultChannel is used.
   * @param {Params} [routeParam] Optional routeParams for router
   * @param {boolean} [isReset=true] If true, will reset all data.
   * @returns {Observable<boolean>} An observable that will emit true if start is successful.
   * @memberOf FlowService
   */
  public start(channelId?: string,
    initialData?: { [key: string]: { data: any, constants?: any, isComplete?: boolean } },
    routeParam?: Params,
    isReset: boolean = true,
    isIgnoreDataLoss: boolean = false): Observable<IChannelStartedEvent> {

    let startObservable: Observable<any> = Observable.of(true);

    if (!!isReset === true) {
      startObservable = this.resetAllData(false, false, isIgnoreDataLoss);
    }

    startObservable.subscribe((isSuccess: boolean) => {
      console.log("FLOW SERVICE INIT **********");

      if (isSuccess) {
        this.setCurrentChannel(channelId);
        let initialFlow: Flow = this.find();
        if (!!initialFlow === true) {
          this.setCurrentFlow(0);
          console.info(`${this.name}.start(): About to start: ${FlowService.currentChannelId}->${this.current.flow.id}`);

          if (!!initialData) {
            this.setInitialData(initialData);
          }

          if (!!routeParam) {
            // routeParam is used.
            this.router.navigate([initialFlow.route.path], routeParam);
          }
          else {
            // Else no routeParams
            this.router.navigate([initialFlow.route.path]);
          }

        } else {
          console.error(`${this.name}.start(): Unable to start: ${FlowService.currentChannelId}`);
        }
      }

      FlowService.channelStartedSubject.next({
        wasStarted: isSuccess,
        wasReset: isReset
      });
    });

    return this.channelStartedEvent;
  }

  /**
   * Sets initial data to all data container based key/FlowID.
   * Assumes channel has started.
   * 
   * @param {{ [flowId: string]: any }} data 
   * @returns 
   * 
   * @memberOf FlowService
   */
  public setInitialData(_data: { [flowId: string]: { data: any, constants?: any, isComplete?: boolean } }) {
    let data = UtilsService.clone(_data) || null;

    if (!!data === false) {
      console.warn(`${this.name}.setInitialData: Unable to set.`);
      return;
    }
    console.info(`${this.name}.setInitialData(): About to set initial data:`, data);
    for (let flowId in data) {
      let flow: Flow = this.find(f => f.id === flowId);
      if (!!flow === false)
        continue;
      flow.data = data[flowId].data || null;
      if (typeof (data[flowId].isComplete) !== "undefined")
        flow.isComplete = data[flowId].isComplete;
      if (typeof (data[flowId].constants) !== "undefined")
        flow.constants = Object.assign({}, flow.constants || {}, data[flowId].isComplete);
    }

  }



  public canActivate() {
    let channel = this.find(f => f && f.id !== "metadata");
    if (!!channel === false || !!channel.data === false)
      this.router.navigate(["/"]);
    else {
      return true;
    }
    return false;
  }

  /**
   * Sets current flow as dirty
   * 
   * 
   * @memberof FlowService
   */
  public dirty(): void {
    this.flowState = FlowStateEnum.dirty;
  }

  /**
   * * Sets current flow as pristine
   * 
   * 
   * @memberof FlowService
   */
  public pristine(): void {
    this.flowState = FlowStateEnum.pristine;
  }

  /**
   * This must be implemented by children.
   * This method will be invoked if AppSettings in environment.ts defines it.
   * 
   * @abstract
   * @returns {Observable<any>} 
   * 
   * @memberof FlowService
   */
  onPossibleDataLoss(): Observable<any> {
    return Observable.throw("FlowService.onPossibleDataLoss Must be implemented by the child class!");
  }

  /**
   * True if channel was started.
   * 
   * @private
   * @type {boolean}
   * @memberof FlowService
   */
  private isChannelStarted: boolean = false;

  private getRouteRoot(url: string, match?: string) {
    match = match || ".*";
    let regex: RegExp = new RegExp(`(?:\\/)?(${match})(?:\\/|\\()?`, "i");
    let regexMatches: RegExpExecArray = regex.exec(url);
    let found: string = !!regexMatches && regexMatches.length > 1 && regexMatches[1];
    return found;
  }

  /**
   * Checks index against router navigation.
   * This ensures that current flow is set when user tries to navigate using
   * the browser navigation buttons (or other means aside from our own.)
   * 
   * @protected
   * @param {NavigationEnd} event 
   * @returns 
   * 
   * @memberof FlowService
   */
  protected onBrowserNavigation(e: PopStateEvent) {
    let fnToCall: (() => void) = () => {
      let browserPath: string = this.getRouteRoot(this.location.normalize(e.url))
      let currentPath: string = this.currentFlow.route.path;
      if (!!browserPath === false)
        this.start();
      else if (currentPath !== browserPath) {
        let correctFlow: Flow = this.find(f => {
          let path = UtilsService.getNestedProperty(f, "route.path");
          return (!!path && path) === browserPath;
        });

        //Flow was not found. Try with channel:
        if (!!correctFlow === false) {
          let channel = FlowService.channels[browserPath];
          if (!!channel)
            this.start(browserPath);
          else
            this.start();

          return;
        }
        this.setCurrentFlow(correctFlow);
      };
    };

    fnToCall.bind(this);
    setTimeout(_ => fnToCall());
  }


  /**
   * Returns the FIRST channel the url (route.path) belongs to.
   * 
   * @param {string} url 
   * @returns {string} 
   * 
   * @memberof FlowService
   */
  public findParentByUrl(url: string): string {
    url = this.getRouteRoot(url) || "";
    let allChannels: Array<string> = Object.keys(this.channels);
    for (let channelName of allChannels) {
      let flows: any = this.channels[channelName];

      if (typeof (flows) === "string")
        continue;

      let isFound: boolean = flows.findIndex((f: Flow) => f && f.route && f.route.path === url) !== -1;
      if (isFound)
        return channelName;
    }

    return allChannels[0];
  }
}















/**
   * Property Decorator for FlowService.
   * Binds data to flowId: { data: } buckets
   * 
   * ### Usage:
   * ```
   * To bind to the data property to the FlowService flow id "visitor":
   * "visitor" is a flow id that belongs to a channel as defined by the flows.json
   * that was used in the FlowService or any of the derived children classes:
   * @FlowService.dataProperty("visitor")
   * let theVisitor: IVisitor = {
   *    "name" : "Lucky"
   * }
   * ```
   * 
   * ### Description:
   * ```
   * Data properties can be set an initial value using the regular way such as
   * @FlowService.dataProperty("visitor")
   * let theVisitor: IVisitor = {
   *    "name" : "Lucky"
   * }
   * ```
   * 
   * ### Important:
   * ```
   * Note: Initial value will overwrite whatever is in the data buckets.
   * In that case, setting an initial value such as 
   * @FlowService.dataProperty("visitor")
   * let theVisitor: IVisitor = {
   *    "name" : "Lucky"
   * }
   * 
   * will cause this initial value to be saved to the data buckets of FlowService for that
   * particular flow Id.
   * ```
   * 
   * 
   * @static
   * @template T 
   * @param {string} flowId 
    * @param {string} [nestedPropertyKeys=""] Nested property keys.
   * @returns 
   * 
   * @memberOf FlowService
   */
export function FlowServiceDataProperty(flowId: string, nestedPropertyKeys: string = "") {
  return (target: Object, propertyKey: string | symbol) => {
    if (!!target && !!!target["onInits"])
      target["onInits"] = [];

    let _fsdNestedKeys: string;
    if (!!nestedPropertyKeys) {
      _fsdNestedKeys = "___fs_" + propertyKey.toString() + "_nestedProperties";
      target[_fsdNestedKeys] = nestedPropertyKeys;
    }

    target["onInits"].push((context, passedInstance) => {
      let fsInstance: FlowService = passedInstance || FlowService.instance;
      let value: any = fsInstance && fsInstance.getFlowData && fsInstance.getFlowData(flowId);
      if (typeof (value) !== "undefined" && value !== null) {
        if (!!target[_fsdNestedKeys])
          context[propertyKey] = value[target[_fsdNestedKeys]];
        else
          context[propertyKey] = value;
      }
    });

  }
}

