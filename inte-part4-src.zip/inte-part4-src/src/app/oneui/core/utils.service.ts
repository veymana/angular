import { Injectable } from '@angular/core';
import { AppSettings } from '#environments/environment';
import { IRestDetail } from '#environments/interfaces';
import { RequestOptions } from '@angular/http';

import * as __lodash from 'lodash';
import { WindowRefService } from 'core/window-ref.service';
import { Headers } from '@angular/http';

export interface IFlattenedObject {
  flattenedKey: string;
}

/**
 * Utility class
 * 
 * @export
 * @class UtilsService
 */
@Injectable()
export class UtilsService {

  constructor() { }

  /**
   * Object Deep copy of source to an optional destination.
   * If destination is provided in the parameters, destination is changed (through reference object).
   * 
   * @param {*} source
   * @param {boolean} isCircular (true) resolve circular references
   * @param {*} [destination]
   * @returns {*} Deep copy/clone of source. Source is untouched.
   * 
   * @memberOf UtilsService
   */
  public static clone(source: any, isCircular: boolean = true, destination?: any): any {
    if (typeof (source) === "undefined" || source === null) {
      return destination;
    }

    let propertyIndex: number,
      descriptor: PropertyDescriptor,
      keys: string[],
      current: any,
      nextSource: any,
      indexOf: number,
      copies: Array<any> = [{
        source: source,
        target: Array.isArray(source) ? [] : Object.create(Object.getPrototypeOf(source))
      }],
      cloneObject: any = copies[0].target,
      sourceReferences: Array<any> = [source],
      targetReferences: Array<any> = [cloneObject];

    // First in, first out
    while (current = copies.shift())	// jshint ignore:line
    {
      keys = Object.getOwnPropertyNames(current.source);
      for (propertyIndex = 0; propertyIndex < keys.length; propertyIndex++) {
        descriptor = Object.getOwnPropertyDescriptor(current.source, keys[propertyIndex]);

        if (!descriptor.value || typeof descriptor.value !== 'object') {
          Object.defineProperty(current.target, keys[propertyIndex], descriptor);
          continue;
        }

        nextSource = descriptor.value;
        descriptor.value = Array.isArray(nextSource) ? [] : Object.create(Object.getPrototypeOf(nextSource));

        /**
         * Circular references might cause an infinite loop, which will throw a stack overflow exception.
         * Need to resolve them now!
         */
        if (isCircular) {
          indexOf = sourceReferences.indexOf(nextSource);

          if (indexOf !== -1) {
            descriptor.value = targetReferences[indexOf];
            Object.defineProperty(current.target, keys[propertyIndex], descriptor);
            continue;
          }
          sourceReferences.push(nextSource);
          targetReferences.push(descriptor.value);
        }

        // Create props:
        Object.defineProperty(current.target, keys[propertyIndex], descriptor);

        // Then add the copy:
        copies.push({ source: nextSource, target: descriptor.value });
      }
    }

    if (typeof (destination) !== "undefined")
      destination = cloneObject;

    return cloneObject;
  }


  /**
   * Converts source of any class into a class of T
   * 
   * @template T
   * @param {T} source
   * @returns {T}
   * 
   * @memberOf UtilsService
   */
  public static copyElements<T>(source: any, destination: T): T {
    // First, clone all objects so we don't override their elements.
    let sourceCopy: Object = UtilsService.clone(source);
    let destinationCopy: Object = UtilsService.clone(destination);

    if (typeof (sourceCopy) === "string") {
      try {
        sourceCopy = JSON.parse(sourceCopy);
      } catch (e) {
        console.error("copyElements: passed string as source and could not parse to an object. Returning original object");
        return destination;
      }
    }

    if (Object.keys(sourceCopy).length <= 0
    ) {
      console.warn("copyElements: source must be a complex object. Returning original object");
      return destination;
    }

    for (let objKey of Object.keys(destination)) {
      if (sourceCopy.hasOwnProperty(objKey)) {
        destinationCopy[objKey] = UtilsService.clone(sourceCopy[objKey]);
      }
    }
    return destinationCopy as T;
  }


  /**
   * Sets the value from source to destination if property exists.
   * 
   * @static
   * @param {string} propName
   * @param {*} source
   * @param {*} destination
   * @returns {void}
   * 
   * @memberOf UtilsService
   */
  public static setIfExists(propName: string, source: any, destination: any): void {
    if (!!source === false || !!destination === false || !!propName === false) {
      return;
    }

    if (source.hasOwnProperty(propName)) {
      destination[propName] = source[propName];
    }
  }

  /**
   * Removes trailing slashes
   * 
   * @static
   * @param {string} str String to trim
   * @returns {string}  timmed string
   * 
   * @memberOf UtilsService
   */
  public static trimTrailingSlashes(str: string): string {
    if (!!str === false)
      return str;

    return str.replace(/(\/|\\)*?$/, "");
  }

  /**
   * Retrieves the <base> url from html's <head>
   * 
   * @static
   * @param {boolean} isRemoveSiteInfo if true, will not include site1/site2
   * @returns {string} 
   * 
   * @memberOf UtilsService
   */
  public static getBaseUrl(isRemoveSiteInfo: boolean): string {
    let bases: NodeListOf<HTMLBaseElement> = document.getElementsByTagName('base');
    let baseHref: any = null;
    if (bases.length > 0) {
      if (bases[0].attributes.length > 0)
        baseHref = bases[0].attributes[0].value;
    }

    if (isRemoveSiteInfo)
      baseHref = baseHref.replace(/\/site\d\/?/i, "");

    return UtilsService.trimTrailingSlashes(baseHref);
  }

  /**
   * Creates unique id
   * 
   * @static
   * @returns {string} 
   * 
   * @memberOf UtilsService
   */
  public static createGuid(): string {
    function s4(): string {
      return Math.floor((1 + Math.random()) * 0x10000)
        .toString(16)
        .substring(1);
    }

    return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
  }

  /**
   * Parses query string (window.location.search) if any, and retrieves the value of the key.
   * 
   * @static
   * @param {string} name 
   * @returns {string} 
   * 
   * @memberOf UtilsService
   */
  public static getParameterByName(name: string): string {
    let queryString: any = WindowRefService.nativeWindow.location.search || WindowRefService.nativeWindow.location.hash;
    name = name.replace(/[\[\]]/g, "\\$&");
    let regex: RegExp = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
      results: RegExpExecArray = regex.exec(queryString);

    if (!results) return null;

    if (!results[2]) return '';

    return decodeURIComponent(results[2].replace(/\+/g, " "));
  }

  /**
   * Converts querystring (string) to Map
   * 
   * @static
   * @param {string} queryString 
   * @returns {Map<string, any>} 
   * 
   * @memberof UtilsService
   */
  public static queryParamsToMap<T>(queryString: string): Map<string, T> {
    let queryStringMap: Map<string, any> = new Map<string, any>();
    queryString = queryString || (WindowRefService.nativeWindow.location.search || WindowRefService.nativeWindow.location.hash);
    let parsed: any = void 0;
    try {
      parsed = JSON.parse('{"' + decodeURI(queryString.substring(1)).replace(/"/g, '\\"').replace(/&/g, '","').replace(/=/g, '":"') + '"}');
    }
    catch (e) {
      console.warn("UtilsService.queryParamsToMap: unable to parse");
      return queryStringMap;
    }

    return this.objectToMap<T>(parsed);
  }

  /**
   * Converts any object to a Map<string, any>
   * 
   * @static
   * @template T 
   * @param {*} o Object to convert.
   * @returns {Map<string, T>} 
   * 
   * @memberof UtilsService
   */
  public static objectToMap<T>(o: any): Map<string, T> {
    let retVal: Map<string, T> = new Map<string, T>();

    if (typeof (o) !== "object" || o === null)
      return retVal;

    for (let key of Object.keys(o)) {
      retVal.set(key, <any>o[key]);
    }
    return retVal;
  }

  /**
   * Stringifies object while also removing circular references.
   * Always use this if unsure there are circular references within an object.
   * 
   * A circular reference is structured as:
   * 
   * Object parent = new Object();
   * parent.child = parent;
   * 
   * @static
   * @param {*} objectToStringify 
   * @param {number} [spaces] 
   * @returns 
   * 
   * @memberOf UtilsService
   */
  public static stringifySafe(objectToStringify: any, spaces?: number): string {
    let cache: Array<any> = [];
    if (!!objectToStringify === false)
      return "";

    let replacer: any = (key: string, value: any) => {
      if (typeof value === 'object' && value !== null) {
        if (cache.indexOf(value) !== -1) {
          return undefined;
        }
        cache.push(value);
      }
      return value;
    };
    let resultString: string = JSON.stringify(objectToStringify, replacer, (spaces || undefined));
    cache = null;

    return resultString;
  }

  /**
   * Checks if string is null, empty, whitespace, or undefined.
   * Examples: 
   * @example
   *  " " = true
   *  ""  = true
   *  undefine = true;
   *  null = true;
   * @static
   * @param {string} str 
   * @returns {boolean} 
   * 
   * @memberOf UtilsService
   */
  public static isNullOrUndefinedOrWhitespace(str: any): boolean {
    let stringified: string = "";
    try {
      stringified = str.toString();
    }
    catch (e) {
      stringified = "";
    }
    return stringified.trim().length <= 0;
  }


  /**
   * Checks if object is null or undefined
   * 
   * @static
   * @param {*} obj 
   * @returns {boolean} 
   * 
   * @memberOf UtilsService
   */
  public static isNullOrUndefined(obj: any): boolean {
    return typeof (obj) === "undefined" || obj === null;
  }

  /**
   * Checks if string is in JSON format.
   * Returns undefined on failure.
   * Returns Object on success.
   * 
   * @static
   * @param {string} str 
   * @returns {(any | boolean)} 
   * 
   * @memberOf UtilsService
   */
  public static tryParseJson(str: string): any {
    let retVal: any = undefined;
    try {
      retVal = JSON.parse(str);
    } catch (e) {
      return retVal;
    }
    return retVal;
  }

  /**
   * Extracts endpoint and resource from a url string.
   * 
   * @static
   * @param {string} url 
   * @returns {{ endPoint: string, resource: string, url: string }} 
   * 
   * @memberOf UtilsService
   */
  public static getRestResource(url: string): { endPoint: string, resource: string, url: string } {
    let parts: string[] = (url || "").split("/"),
      ep: string = "",
      rs: string = "",
      u: string = "";

    if (parts.length === 1) {
      ep = "/";
      rs = "/";
    } else if (parts.length >= 2) {
      rs = parts.pop();
      ep = parts.join("/") || "/";
    }

    return {
      endPoint: ep,
      resource: rs,
      url: ep + "/" + rs
    };
  }

  /**
   * Retrieves the Resource Detail from AppSettings
   * 
   * @static
   * @param {string} name 
   * @param {RequestOptions} [requestOptions] 
   * @returns {IRestDetail} 
   * 
   * @memberof UtilsService
   */
  public static getResourceDetail(name: string, requestOptions?: RequestOptions): IRestDetail {
    const preRetVal: IRestDetail = AppSettings.REST.resource[name];
    let retVal: IRestDetail = Object.assign({}, preRetVal);
    if (!!requestOptions === true)
      retVal.requestOptions = Object.assign({}, requestOptions);

    return retVal;
  }

  /**
   * Sorts an array based on property key.
   * 
   * @static
   * @template T 
   * @param {Array<T>} array The array to sort
   * @param {string} propertyKey Property key of the value to be sorted
   * @param {boolean} [isClone=false] If true, the array is cloned so that the object references are removed.
   * @returns {Array<T>} 
   * 
   * @memberOf UtilsService
   */
  public static sortArray<T>(array: Array<T>, propertyKey: string, isClone: boolean = false): Array<T> {
    let arr: Array<T> = null;

    if (isClone)
      arr = UtilsService.clone(array);
    else
      arr = array;

    return arr.sort((current: T, next: T) => {
      if (current[propertyKey] < next[propertyKey])
        return -1;
      else if (current[propertyKey] > next[propertyKey])
        return 1;
      else
        return 0;
    });
  }

  /**
   * Creates a nested object.
   * ### Examples:
   * ```
   * UtilsService.nestedObjCreator({}, ["one", "two", "three"], 28);
   * will produce an object :
   * { one: { two: { three: 28 }}}
   * 
   * 
   * @static
   * 
   * @memberOf FlowService
   */
  public static nestedObjCreator = (o: any, propKeys: Array<string>, value: any) => {
    if (!Array.isArray(propKeys))
      propKeys = [propKeys];

    let currentKey: string = propKeys.shift();
    if (!!currentKey) {
      o[currentKey] = UtilsService.nestedObjCreator(o[currentKey] || {}, propKeys, value);
    }
    else { o = value; }
    return o;
  }

  /**
   * Flattens an object into an array.
   * ### Example:
   * ```
   * let flattenThis: ISomeInterface = {
   *  "lucky" : {
   *    "name": "Lucky"
   *    "what" : "chams"
   *  },
  *   "hey" : {
   *    "name": "hey"
   *    "what" : "Jude"
   *  }
   * };
   * 
   * let flattened = flatten<ISomeInterface>(flattenthis);
   * 
   * will produce:
   * 
   * [
   *  {
   *    "flattenedKey" : "lucky",
   *    "name" : "Lucky",
   *    "what" : "chams"
   *  },
   *  {
   *    "flattenedKey" : "hey",
   *    "hey" : "hey",
   *    "what" : "Jude"
   *  }
   * ]
   * 
   * 
   * 
   * @static
   * @template T 
   * @param {*} input 
   * @param {string} [ignoreKey=void 0] Ignores this key
   * @returns {Array<T>} 
   * 
   * @memberOf UtilsService
   */
  public static flatten<T>(input: any, ignoreKey: string = void 0): Array<T & IFlattenedObject> {
    let inputCopy: any = this.clone(input) || {};
    let retVal: Array<T & IFlattenedObject> = new Array<T & IFlattenedObject>();
    for (let i in inputCopy) {
      if (i === ignoreKey)
        continue;
      inputCopy[i].flattenedKey = i;
      retVal.push(inputCopy[i]);
    }
    return retVal;
  }

  /**
   * validates the date with the given format
   * 
   * @static
   * @param {(string | Date | number)} inputStringOrDate  Either a date in string format or as Date object. (Number as in Date.getTime())
   * @param {string} dateFormat 
   * @returns {Boolean} 
   * 
   * @memberOf UtilsService
   */
  public static isValidDateFormat(inputStringOrDateOrNumber: string | Date | number, dateFormat: string): boolean {
    // if (__moment(inputStringOrDateOrNumber, dateFormat).format(dateFormat) === inputStringOrDateOrNumber)
    //  return true;
    return false;
  }

  /**
     * returns the date with the given format
     * 
     * @static
     * @param {(string | Date | number)} inputStringOrDate  Either a date in string format or as Date object. (Number as in Date.getTime())
     * @param {string} dateFormat 
     * @returns {date} 
     * 
     * @memberOf UtilsService
     */
  public static formatDate(inputStringOrDateOrNumber: string | Date | number, dateFormat: string): string {
    //return (__moment(inputStringOrDateOrNumber, dateFormat).format(dateFormat));

    return "";
  }
  /**
   * Retrieves the value of the nested property of an object.
   * Example:
   * ```
   * let object = { level1: { level2: 3} };
   * let retVal = getNestedProperty(object, "level1.level2");
   * retVal is now 3
   * 
   * For arrays, use dot notation even for the index.
   * For example, to get parent.child[2].value, use getNestedProperty(parent, "child.2.value");
   * 
   * @static
   * @param {*} object 
   * @param {string} property 
   * @returns {*} 
   * 
   * @memberof UtilsService
   */
  public static getNestedProperty(object: any, property: string): any {
    if (typeof (object) === "undefined" || !!property === false)
      return object;

    return property.split(".")
      .reduce((o: any, x: any) => {
        return (typeof o === "undefined" || o === null) ? o : o[x];
      }, object);
  }

  // tslint:disable-next-line:typedef
  public static get moment() {
    return null;
  }

  /**
   * LoDash library
   * 
   * @readonly
   * @static
   * 
   * @memberof UtilsService
   */
  public static get lodash() {
    return __lodash;
  }

  /**
   * Converts a string to an XMLDocument
   * 
   * @static
   * @param {string} rawString 
   * @returns {XMLDocument} 
   * 
   * @memberof UtilsService
   */
  public static stringToXmlDoc(rawString: string): XMLDocument {
    let domParser: DOMParser = new DOMParser();
    let xmlDocument: XMLDocument = void 0;
    try {
      xmlDocument = domParser.parseFromString(rawString, "text/xml");
    } catch (e) {
      xmlDocument = new XMLDocument();
    }

    return xmlDocument;
  }


  /**
   * Converts an XML string to a JSON/Object
   * example:
   * <hello><lucky>charms</lucky></hello>
   * becomes
   * {
   *  hello: {
   *    lucky: "charms"
   *  }
   * }
   * 
   * @static
   * @param {(string | Element)} rawXmlString 
   * @returns {Object} 
   * 
   * @memberof UtilsService
   */
  public static xmlStringToJson(rawXmlString: string | Element | XMLDocument): Object {
    let xml: XMLDocument;
    if (typeof (rawXmlString) === "string")
      xml = UtilsService.stringToXmlDoc(rawXmlString);
    else xml = <XMLDocument>rawXmlString;

    const TEXTNODETYPE: { id: number, type: string } = { id: 4, type: "#text" };

    try {
      let retVal: any = {};

      if (xml.nodeType === TEXTNODETYPE.id) {
        retVal = xml.nodeValue;
      }

      if (xml.hasChildNodes()) {
        for (let i: number = 0; i < xml.childNodes.length; i++) {
          let item: any = xml.childNodes.item(i);
          let nodeName: string = item.nodeName;
          let content: any = void 0;

          if (nodeName === TEXTNODETYPE.type) {
            if ((null === xml.nextSibling) || (xml.localName !== xml.nextSibling.localName)) {
              content = xml.textContent;
            } else if (xml.localName === xml.nextSibling.localName) {
              content = (xml.parentElement.childNodes[0] === xml) ? [xml.textContent] : xml.textContent;
            }
            return content;
          } else {
            if ('undefined' === typeof (retVal[nodeName])) {
              retVal[nodeName] = UtilsService.xmlStringToJson(item);
            } else {
              if ('undefined' === typeof (retVal[nodeName].length)) {
                let previousValue: any = retVal[nodeName];
                retVal[nodeName] = new Array();
                retVal[nodeName].push(previousValue);
              }

              retVal[nodeName].push(UtilsService.xmlStringToJson(item));
            }
          }
        }
      }
      return retVal;
    } catch (e) {
      console.log(e.message);
    }
  }

  /**
   * Returns the value of the object[property].
   * propertyName can be insensitive.
   * ```Example:
   * let o = { "AbC" : 1 }
   * getValueCaseInsensitiveKey(o, "aBc") ==> 1
   * 
   * @static
   * @param {*} objectToParse 
   * @param {(string | number)} caseInsensitiveKey 
   * @returns {*} 
   * 
   * @memberof UtilsService
   */
  public static getValueCaseInsensitiveKey(objectToParse: any, caseInsensitiveKey: string | number): any {
    let foundKey: string = __lodash.findKey(objectToParse, (value: any, key: string) => {
      return key.toLowerCase() === (caseInsensitiveKey + "").toLowerCase();
    });

    return objectToParse[foundKey];
  }

  /**
   * Attempts to close browser
   * 
   * @static
   * 
   * @memberof UtilsService
   */
  public static attemptKillBrowser(): void {
    try {
      WindowRefService.nativeWindow.opener = null;
      WindowRefService.nativeWindow.open('', '_self', '');
      WindowRefService.nativeWindow.close();
    } catch (e) {
      /* IGNORE ERRORS! The last thing we want is to crash while closing */
    }
  }

  public static vanillaXhr: IVanillaXhr = {
    post: (url: string, data: any, headers?: Headers) => {
      let xmlHttp: XMLHttpRequest = new XMLHttpRequest();
      xmlHttp.open("post", url);
      if (!!headers) {
        if (!headers.has('Content-Type'))
          xmlHttp.setRequestHeader('Content-Type', 'application/json');
        headers.keys().forEach((key: string) => {
          let value: any = headers.get(key);
          if (typeof (value) !== "undefined")
            xmlHttp.setRequestHeader(key, value);
        });
      } else {
        xmlHttp.setRequestHeader('Content-Type', 'application/json');
      }
      if (typeof (data) !== "string") {
        try {
          data = JSON.stringify(data);
        }
        catch (e) {

        }
      }
      xmlHttp.send(data);
    },
    get: (url: string, ...a: any[]) => { return {}; }
  };

}


export interface IVanillaXhr {
  post: (url: string, ...args: any[]) => any;
  get: (url: string, ...args: any[]) => {};
}
