/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { ErrorSinkService } from './error-sink.service';

describe('ErrorSinkService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ErrorSinkService]
    });
  });

  it('should ...', inject([ErrorSinkService], (service: ErrorSinkService) => {
    expect(service).toBeTruthy();
  }));
});
