import { Injectable } from '@angular/core';
import {
  Router,
  NavigationStart,
  NavigationEnd,
  NavigationCancel,
  NavigationError
} from '@angular/router';

/**
 * Global handler for Router events
 * 
 * @export
 * @class RouterEventsService
 */
@Injectable()
export class RouterEventsService {
  public static NAME: string = 'RouterEventsService';

  /**
   * Creates an instance of RouterEventsService.
   * @param {Router} router 
   * 
   * @memberOf RouterEventsService
   */
  constructor(private router: Router) {

    router.events.subscribe((val: NavigationStart | NavigationEnd | NavigationCancel | NavigationError) =>
      !!val
      && (
        ((val instanceof NavigationStart) && this.onNavigationStart(val))      // onStart
        || ((val instanceof NavigationEnd) && this.onNavigationEnd(val))       // onEnd
        || ((val instanceof NavigationCancel) && this.onNavigationCancel(val)) // onCancel
        || ((val instanceof NavigationError) && this.onNavigationError(val))   // onError
      )
    )
  }

  /**
   * Global Navigation Started router event handler
   * 
   * @private
   * @param {NavigationStart} event 
   * 
   * @memberOf RouterEventsService
   */
  private onNavigationStart(event: NavigationStart) {
    console.log("******************************Router************************");

    console.log(`${RouterEventsService.NAME}.onNavigationStart: ${event.toString()}`);
  }

  /**
   * Global Navigation Ended router event handler
   * 
   * @private
   * @param {NavigationEnd} event 
   * 
   * @memberOf RouterEventsService
   */
  private onNavigationEnd(event: NavigationEnd) {
    console.log(`${RouterEventsService.NAME}.onNavigationEnd: ${event.toString()}`);
  }

  /**
   * Global Navigation Canceled router event handler
   * 
   * @private
   * @param {NavigationCancel} event 
   * 
   * @memberOf RouterEventsService
   */
  private onNavigationCancel(event: NavigationCancel) {
    console.log("Request being cancelled");
    //  console.log(`${RouterEventsService.NAME}.onNavigationCancel: ${event.toString()}`);
  }

  /**
   * Global Navigation Errored router event handler
   * 
   * @private
   * @param {NavigationError} event 
   * 
   * @memberOf RouterEventsService
   */
  private onNavigationError(event: NavigationError) {
    console.error(`${RouterEventsService.NAME}.onNavigationError: ${event.toString()}`);
  }



}
