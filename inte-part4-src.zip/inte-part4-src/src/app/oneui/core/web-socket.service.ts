import { Injectable, Inject } from '@angular/core';
import { Subject, BehaviorSubject, Observer, Observable } from 'rxjs/Rx';
import { WindowRefService } from 'core/window-ref.service';
import { UtilsService } from 'core/utils.service';
import { AppSettings } from '#environments/environment';
import { Location, PlatformLocation } from '@angular/common';

/**
 * Custom extension to WebSocket interface to inject our own Custom
 * functionality.
 * 
 * @export
 * @interface ICustomWebSocket
 * @extends {WebSocket}
 */
export interface ICustomWebSocket extends WebSocket {
  /**
   * Event handler when a message is sent FROM client TO server.
   * 
   * @param {WebSocketEvent} data 
   * 
   * @memberOf ICustomWebSocket
   */
  onsend(data: WebSocketEvent): void;
}

/**
 * Interface to WebSocketDefinition
 * 
 * @export
 * @interface IWebSocketDefinition
 */
export interface IWebSocketDefinition {
  /**
   * The base for the WS URL. This is joined with path.
   * For example:
   * base = "ws://luckycharms.com/hello"
   * path = "/websocket/chat"
   * The entire URL for the WS will be ws://luckycharms.com/hello/websocket/chat
   * 
   * ### "[[relative]]"
   * Use "[[relative]]" to make the base the same as in <base href>
   * Example:
   * Current <base href> in <head>:
   * <base href="https://luckycharmsxyz.com/hello"
   * base = "[[relative]]"
   * path = "/websocket/chat"
   * The websocket URL will now be https://luckycharmsxyz.com/hello/websocket/chat
   * The scheme (ws/wss) will be dependent on the http scheme. So if <base> is on https, websocket scheme will be wss.
   * 
   * You can also override scheme by setting the scheme property.
   * If scheme is [[relative]], it will be based on http(s) of the <base>
   * 
   * if relativeTo is defined, relativity is based on this value.
   * Example:
   * Current <base href> in <head>:
   * <base href="https://luckycharmsxyz.com/hello"
   * base = "[[relative]]"
   * path = "/websocket/chat"
   * relativeTo = "http://somethingelse.com"
   * WS URL will be "ws://somethingelse.com/websocket/chat"
   * The same ws/wss applies
   * 
   * relativeTo possible values:
   * relativeTo: "[[base]]" <-- this will use <base href> value
   * relativeTo: AppSettings.REST.endpoint.something <-- this will be relative to the rest endpoint defined in environtment.ts
   * 
   * For example:
   * environment.ts:
   * ... REST {
   *     ...
   *     endPoints: {
   *         default: "https://na.ist.atmhost.wellsfargo.com:11458/stagedirector",
   *         something: "http://charms.lucky.com/abc/"
   *     }
   * }
   * ...
   * base = "[[relative]]"
   * path = "/websocket/chat"
   * relativeTo = AppSettings.REST.endpoint.something
   * WS URL will be ws://charms.lucky.com/abc/websocket/chat
   * 
   * @type {string}
   * @memberof IWebSocketDefinition
   */
  base?: string | "[[relative]]";
  relativeTo?: string | "[[base]]";
  path?: string;
  isCacheToNative?: boolean;
  isRetryOnConnectionFailure?: boolean;
  retryDurationInMs?: number;
  numRetry?: number;
  scheme?: "ws" | "wss" | "[[relative]]";
}

/**
 * Container for all data to keep the same object reference
 * 
 * @interface IWsContainer
 */
interface IWsContainer {
  ws: ICustomWebSocket;
  def: WebSocketDefinition;
  innerObs: Observer<MessageEvent | Event | WebSocketEvent>;
  wasOpened: boolean;
}

/**
 * WebSocketDefinition class
 * Defines websocket
 * 
 * @export
 * @class WebsocketDefinition
 */
export class WebSocketDefinition implements IWebSocketDefinition {
  /**
   * Websocket path
   * 
   * @type {string}
   * @memberOf WebSocketDefinition
   */
  public url: string = null;

  /**
   * Cache data to native
   * 
   * @type {boolean}
   * @memberOf WebSocketDefinition
   */
  public isCacheToNative: boolean = false;


  /**
   * If true, will attempt to reconnect on failure
   * 
   * @type {boolean}
   * @memberOf WebSocketDefinition
   */
  public isRetryOnConnectionFailure: boolean = false;

  public numRetry: number = 0;

  /**
   * Checks if retry should be performed.
   * 
   * @readonly
   * @type {boolean}
   * @memberOf WebSocketDefinition
   */
  public get isRetry(): boolean {
    return this.isRetryOnConnectionFailure && this.retryDurationInMs >= 0;
  }


  /**
   * If isRetryOnConnectionFailure is true, this is the duration in which 
   * reconnection attemps are called.
   * 
   * @type {number}
   * @memberOf WebSocketDefinition
   */
  public retryDurationInMs: number = 2000;

  /**
   * Creates an instance of WebSocketDefinition.
   * If IWebSocketDefinition is passed, its values are used instead.
   * @param {(string | IWebSocketDefinition)} [url] 
   * @param {boolean} [isCacheToNative=false] 
   * @param {boolean} [isRetryOnConnectionFailure=false] 
   * @param {number} [retryDurationInMs=AppSettings.WEBSOCKETS.retryDurationInMs] 
   * 
   * @memberOf WebSocketDefinition
   */
  constructor(url?: string | IWebSocketDefinition,
    isCacheToNative: boolean = false,
    isRetryOnConnectionFailure: boolean = false,
    retryDurationInMs: number = AppSettings.WEBSOCKETS.retryDurationInMs) {

    if (typeof (url) === "string") {
      this.url = url || null;
      this.isCacheToNative = isCacheToNative || false;
      this.isRetryOnConnectionFailure = isRetryOnConnectionFailure || false;
      this.retryDurationInMs = retryDurationInMs;
    }

    else if (!!url["path"] === true) {
      // url is IWebSocketDefinition
      let iwebsocketDef: IWebSocketDefinition = url as IWebSocketDefinition;
      this.url = WebSocketService.getWebSocketUrl(iwebsocketDef);
      this.isCacheToNative = iwebsocketDef.isCacheToNative || false;
      this.isRetryOnConnectionFailure = iwebsocketDef.isRetryOnConnectionFailure || false;
      this.retryDurationInMs = iwebsocketDef.retryDurationInMs || AppSettings.WEBSOCKETS.retryDurationInMs;
    }


  }

  /**
   * Disables reconnection attempt
   * 
   * 
   * @memberOf WebSocketDefinition
   */
  public disableReconnect(): void {
    this.isRetryOnConnectionFailure = false;
  }

  /**
   * Enables reconnection attempt
   * 
   * 
   * @memberOf WebSocketDefinition
   */
  public enableReconnect(): void {
    this.isRetryOnConnectionFailure = true;
  }
}

/**
 * WebSocketDataDirection
 * 
 * @export
 * @enum {number}
 */
export enum WebSocketEventType {
  unknown = 0,
  opened = 1,
  closed = 2,
  sent = 3,
  received = 4,
  message = 5,
  error = 6
}

/**
 * WebSocketData
 * 
 * @export
 * @class WebSocketData
 */
export class WebSocketEvent {
  /**
   * Actual Data
   * 
   * @type {*}
   * @memberOf WebSocketEvent
   */
  public data: any = void 0;

  /**
   * Raw data as received (usually of type MessageEvent)
   * 
   * @type {*}
   * @memberOf WebSocketEvent
   */
  public raw: any = void 0;

  /**
   * Type of event
   * 
   * @type {WebSocketEventType}
   * @memberOf WebSocketEvent
   */
  public type: WebSocketEventType = void 0;

  /**
   * Time Stamp
   * 
   * @type {Date}
   * @memberOf WebSocketEvent
   */
  public timeStamp: Date = new Date();

  /**
   * Returns event type as string.
   * 
   * @readonly
   * @type {string}
   * @memberOf WebSocketEvent
   */
  public get typeAsString(): string {
    return WebSocketService.getEventTypeAsString(this.type);
  }

  /**
   * Creates an instance of WebSocketEvent.
   * @param {*} [data] 
   * @param {WebSocketEventType} [type=WebSocketEventType.sent] 
   * @param {*} [raw] 
   * 
   * @memberOf WebSocketEvent
   */
  constructor(data?: any, type: WebSocketEventType = WebSocketEventType.sent, raw?: any) {
    this.data = data;
    this.type = type;
    this.raw = raw;
  }
}


/**
 * WebSocket Service
 * 
 * @export
 * @class WebSocketService
 */
@Injectable()
export class WebSocketService {

  /**
   * Service name
   * 
   * @type {string}
   * @memberOf WebSocketService
   */
  public static NAME: string = "WebSocketService";

  /**
   * Checks if browser supports WebSocket
   * 
   * @static
   * 
   * @memberOf WebSocketService
   */
  public static isSupported = !!WindowRefService.nativeWindow && !!WindowRefService.nativeWindow.WebSocket && typeof (WindowRefService.nativeWindow.WebSocket) === "function";

  /**
   * Injected platformLocation service
   * 
   * @static
   * @type {PlatformLocation}
   * @memberof WebSocketService
   */
  public static platformLocation: PlatformLocation = void 0;

  /**
   * Injected Location service
   * 
   * @static
   * @type {PlatformLocation}
   * @memberof WebSocketService
   */
  public static location: Location = void 0;

  /**
   * Creates an instance of WebSocketService.
   * 
   * @memberOf WebSocketService
   */
  constructor(platformLocation: PlatformLocation,
    location: Location) {
    if (WebSocketService.isSupported === false)
      throw new Error(`${WebSocketService.NAME}: WebSocket is not supported by the browser!`);

    WebSocketService.platformLocation = platformLocation;
    WebSocketService.location = location;
  }

  /**
   * WebSocketEventType to String
   * 
   * @static
   * @param {WebSocketEventType} type 
   * @returns {string} 
   * 
   * @memberOf WebSocketService
   */
  public static getEventTypeAsString(type: WebSocketEventType): string {
    type = type || WebSocketEventType.unknown;
    switch (type) {
      case WebSocketEventType.closed:
        return "Closed";

      case WebSocketEventType.opened:
        return "Opened";

      case WebSocketEventType.received:
        return "Received";

      case WebSocketEventType.sent:
        return "Sent";

      case WebSocketEventType.message:
        return "Message";

      case WebSocketEventType.error:
        return "Error";

      default:
        return "Unknown";
    }
  }

  /**
   * Creates the websocket
   * 
   * @private
   * @param {IWsContainer} wsContainer 
   * 
   * @memberOf WebSocketService
   */
  private createWs(wsContainer: IWsContainer): void {

    if (!!wsContainer.ws) {
      wsContainer.ws.close();
      wsContainer.ws = null;
    }

    wsContainer.def.numRetry++;

    // Create websocket.
    wsContainer.ws = new WebSocket(wsContainer.def.url) as ICustomWebSocket;

    // Bind to observable methods.
    // Most events should be handled on the onNext so that external
    // subscribers can hook and subscribe to these events.
    wsContainer.ws.onopen = (e) => {
      wsContainer.wasOpened = true;
      wsContainer.def.numRetry = 0;
      wsContainer.innerObs.next(e);
    }

    wsContainer.ws.onmessage = (e) => wsContainer.innerObs.next(e);

    wsContainer.ws.onerror = (e) => {
      // If WS was never opened before, just ignore error since
      // connection status logic happens in the setTimeout later.
      if (wsContainer.wasOpened === false)
        return;

      wsContainer.innerObs.next(e);
    }

    wsContainer.ws.onclose = (e) => {
      if (wsContainer.def.isRetry) {
        if (wsContainer.wasOpened) {
          wsContainer.innerObs.next(new WebSocketEvent(`Connection closed. Will retry (try #${wsContainer.def.numRetry}.`, WebSocketEventType.closed));
          setTimeout(() => {
            if (wsContainer.ws.readyState !== WebSocket.OPEN)
              this.createWs(wsContainer);
          }, wsContainer.def.retryDurationInMs);
        }
      }
      else
        wsContainer.innerObs.complete();
    }

    // Custom methods:
    wsContainer.ws.onsend = wsContainer.innerObs.next.bind(wsContainer.innerObs);

    // Since WebSockets do NOT have an onConnect/Open callback on failure, we need
    // to check status after a period of time.
    // This is AppSettings.WEBSOCKETS.checkReadyStateInMs if configured.
    // Otherwise, defaults to 2 seconds (2000 ms)
    setTimeout(() => {
      if (wsContainer.wasOpened)
        return;

      if (wsContainer.def.isRetry && wsContainer.ws.readyState !== WebSocket.OPEN) {
        console.warn(`${WebSocketService.name} Connection failed. Retrying (try #${wsContainer.def.numRetry}) after ${wsContainer.def.retryDurationInMs} ms.`);
        wsContainer.innerObs.next(new WebSocketEvent(wsContainer.ws.url, WebSocketEventType.error, `Connection failed. Will retry (try #${wsContainer.def.numRetry})`));
        setTimeout(() => {
          this.createWs(wsContainer);
        }, wsContainer.def.retryDurationInMs);
      }
    }, AppSettings.WEBSOCKETS.checkReadyStateInMs || 2000);
  }


  /**
   * Creates a subject of the websocket with an internal observable and custom onsend methods.
   * 
   * @param {WebSocketDefinition} wsDef 
   * @returns {(Subject<any | WebSocketEvent>) | (BehaviorSubject<any | WebSocketEvent>)} 
   * 
   * @memberOf WebSocketService
   */
  public create(wsDef: WebSocketDefinition): BehaviorSubject<any | WebSocketEvent> {
    if (!!wsDef === false || UtilsService.isNullOrUndefinedOrWhitespace(wsDef.url))
      throw new Error(`${WebSocketService.NAME}.create(): invalid url.`);

    let wsContainer: IWsContainer = {
      ws: null,
      def: wsDef,
      innerObs: null,
      wasOpened: false
    };

    // Use the ws to create the observable, using the API (onmessage, onerror, onclose):
    let websocketObservable: Observable<WebSocketEvent> =
      Observable.create((innerObs: Observer<MessageEvent | Event | WebSocketEvent>) => {
        wsContainer.innerObs = innerObs;
        this.createWs(wsContainer);
        return wsContainer.ws.close.bind(wsContainer.ws);
      })

        // Map data and convert it to WebSocketEvent, so that
        // they are easily maintainable and preserves data class structure
        .map((data: WebSocketEvent | MessageEvent | Event) => {
          // WebSocket Event, return as is.
          // We send data as WebSocketEvent
          if (data instanceof WebSocketEvent)
            return data;

          // Retrieve type
          let type: WebSocketEventType = WebSocketService.getEventTypeAsWebSocketEventType(data && (<any>data).type || "unknown");

          // Opened or Closed
          if (type === WebSocketEventType.opened || type === WebSocketEventType.closed) {
            return new WebSocketEvent(wsContainer.ws.url, type, data);
          }

          // Error
          if (type === WebSocketEventType.error) {
            return new WebSocketEvent(new Error("WebSocketEvent error"), type, data);
          }

          if (type === WebSocketEventType.message) {
            // We receive data as MessageEvent
            if (data instanceof Event || data instanceof MessageEvent) {
              return new WebSocketEvent((<MessageEvent>data).data || data, WebSocketEventType.received, data)
            }
          }

          return new WebSocketEvent((<MessageEvent>data).data || data, type, data);
        });

    let wsObserver: any = {
      next: (data: WebSocketEvent) => {
        let dataToSend = (data && data.data) || data;
        if (wsContainer.ws.readyState === WebSocket.OPEN) {
          wsContainer.ws.send(typeof (dataToSend) === "string" ? dataToSend : JSON.stringify(dataToSend));

          // Custom method.
          // onsend should be BOUND to the onNext of the Observer
          // so that observables and subjects can share the same next() on both onmessage and onsend handlers.
          wsContainer.ws.onsend(data);
        }
      }
    };

    let subjectRetVal: BehaviorSubject<WebSocketEvent | any> = BehaviorSubject.create(wsObserver, websocketObservable);
    return subjectRetVal;
  }

  /**
   * Maps string to WebSocketEventType
   * 
   * @private
   * @param {string} type 
   * @returns {WebSocketEventType} 
   * 
   * @memberOf WebSocketService
   */
  public static getEventTypeAsWebSocketEventType(type: string): WebSocketEventType {
    let retVal: WebSocketEventType = WebSocketEventType.unknown;
    switch (type) {
      case "open":
        return WebSocketEventType.opened;
      case "close":
        return WebSocketEventType.closed;
      case "message":
        return WebSocketEventType.message;
      case "received":
        return WebSocketEventType.received;
      case "error":
        return WebSocketEventType.error;
      case "sent":
        return WebSocketEventType.sent;
      default:
      case "unknown":
        return WebSocketEventType.unknown;
    }
  }

  /**
   * onOpen Handler
   * 
   * @private
   * @param {*} event 
   * 
   * @memberOf WebSocketService
   */
  private _onOpen(event: any): void {
    let bound = (<any>this) as WebSocket;
    console.log(`${WebSocketService.NAME}._onOpen(): WebSocket opened for ${bound.url}`);
  }

  /**
   * Returns websocket url
   * 
   * @param {IWebSocketDefinition} iWebSocketDefinition 
   * @returns {string} 
   * 
   * @memberof WebSocketService
   */
  public static getWebSocketUrl(iWebSocketDefinition: IWebSocketDefinition): string {
    let retVal: string = void 0;

    if (!!iWebSocketDefinition === false) return null;

    // path check
    if (!!iWebSocketDefinition.path === false) {
      let err: string = `${this.NAME}.${this.name}: invalid path`;
      console.error(err, iWebSocketDefinition);
      throw new Error(err);
    }

    // base check
    if (!!iWebSocketDefinition.base === false) {
      let err: string = `${this.NAME}.${this.name}: invalid base`;
      console.error(err, iWebSocketDefinition);
      throw new Error(err);
    }

    // Relative [[relative]] is used
    if (iWebSocketDefinition.base === "[[relative]]") {
      let base: string = void 0;

      // get relative
      let relativeTo: string = iWebSocketDefinition.relativeTo || "";
      if (!!relativeTo === true) {
        // relativeTo is set
        if (relativeTo === "[[relative]]") {
          base = WebSocketService.platformLocation.getBaseHrefFromDOM();
          base = Location.joinWithSlash(location.origin, base);
        }
        else {
          base = relativeTo;
        }
      }
      retVal = Location.joinWithSlash(base, iWebSocketDefinition.path);
    } else {
      // non [[relative]] is used
      retVal = Location.joinWithSlash(iWebSocketDefinition.base, iWebSocketDefinition.path);
    }
    // Construct scheme by simply replacing http so that http becomes ws and https becomes wss
    retVal = retVal.replace(/^http/ig, "ws");
    return retVal;
  }
}