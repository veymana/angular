import { OneInterfaceService } from '@one-interface/one-interface.service';
import { Restclient, RestclientBaseService } from 'core/restclient/restclient-base.service';
import { Http, XHRBackend, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs';
import { UtilsService } from 'core/utils.service';
import { IDmsDeviceError } from '../models/interfaces';
import { AppSettings } from '#environments/environment';

/**
 * Base Class for all DMS Devices
 * 
 * @export
 * @class DeviceManagementService
 */
export class DmsDevice {
  public readonly id: string = null;
  protected restClient: Restclient = void 0;
  protected resourceAppSettingsKey: string = "dms";

  constructor(private oneInterface: OneInterfaceService,
    private backend: XHRBackend
  ) {
    this.restClient = RestclientBaseService.create(oneInterface, backend, this.resourceAppSettingsKey);
  }

  /**
   * Creates the resource to construc the URL.
   * 
   * @private
   * @param {string} method 
   * @returns {string} 
   * 
   * @memberof DmsDevice
   */
  private createResourcePath(method: string): string {
    return Location.joinWithSlash(this.id, method);
  }

  /**
   * Calls the Dms method (param)
   * 
   * @template T 
   * @param {string} method 
   * @returns {Observable<T>} 
   * 
   * @memberof DmsDevice
   */
  public get<T>(method: string): Observable<T & IDmsDeviceError> {
    this.restClient.restResource.resource = this.createResourcePath(method);
    return this.restClient
      .get() //call GET
      .timeout(this.getRestCallTimeout(method))
      .map((res: Response) => this.extractReply(res)) // Convert
      .catch((err: any, caught: Observable<T>) => {
        return Observable.of(<T & IDmsDeviceError>{ error: err });
      });
  }

  /**
   * Calls Dms device /cancel
   * 
   * @returns {Observable<boolean>} 
   * 
   * @memberof DmsDevice
   */
  public cancel(): Observable<boolean | IDmsDeviceError> {
    const method: string = "cancel";
    return this.get<Object>(method)
      .map((payload: any) => {
        return payload && payload["method"] === method;
      })
      .catch((err: any, caught: Observable<any>) => {
        return Observable.of(<IDmsDeviceError>{ error: err });
      });
  }

  /**
   * Extracts reply from the XML-based response.
   * Response -> text -> reply as Object.
   * 
   * @private
   * @template T 
   * @param {Response} response 
   * @returns {T} 
   * 
   * @memberof DmsDevice
   */
  private extractReply<T>(response: Response): T {
    const responseTxt: string = response.text();
    const responseObj: Object = UtilsService.xmlStringToJson(responseTxt);
    const reply: T = <T>((responseObj && responseObj["reply"]) || null);
    return reply;
  }

  /**
   * Calls the Device's info/state
   * defaults to getInfo. Override by passing param.
   * 
   * @template T 
   * @param {string} [infoMethod='getInfo'] 
   * @returns {Observable<T>} 
   * 
   * @memberof DmsDevice
   */
  public getStatus<T>(infoMethod: string = 'getInfo'): Observable<T & IDmsDeviceError> {
    return this.get<T>(infoMethod)
      .catch((err: any, caught: Observable<any>) => {
        return Observable.of(<T & IDmsDeviceError>{ error: err });
      });
  }

  /**
   * Extracts timeout from AppSettings
   * 
   * @private
   * @param {string} method 
   * @returns {number} 
   * 
   * @memberof DmsDevice
   */
  private getRestCallTimeout(method: string): number {
    let timeoutSetting: any = UtilsService.getValueCaseInsensitiveKey(AppSettings.DeviceManagentServiceConfig.timeouts, this.id);
    return timeoutSetting && UtilsService.getValueCaseInsensitiveKey(timeoutSetting, method) || 0;
  }
}
