import { DmsDevice } from './dms-device';
import { OneInterfaceService } from '@one-interface/one-interface.service';
import { Http, XHRBackend, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import { DmsCardReaderData } from '../models/dms-card-reader-data';
import { UtilsService } from 'core/utils.service';
import { ICardReaderInfo, ICardReaderData } from '../models/interfaces';
import { Resolve } from '@angular/router';
import { IDmsDeviceError } from '../models/interfaces';
import { Injectable } from '@angular/core';

/**
 * DMS Card Reader Integration
 * 
 * @export
 * @class DeviceManagementService
 */
@Injectable()
export class CardReader extends DmsDevice implements Resolve<ICardReaderInfo & IDmsDeviceError> {
  public readonly id: string = 'cardrdr';

  constructor(oneInterface: OneInterfaceService,
    backend: XHRBackend) {
    super(oneInterface, backend);
  }

  /**
   * Calls DMS cardreader /read service
   * 
   * @param {boolean} [isCheckStateFirst=true] If true, before doing a get /read, it will try to check state first by calling GET /getinfo
   * @returns {Observable<DmsCardReaderData>} 
   * 
   * @memberof CardReader
   */
  public read(isCheckStateFirst: boolean = true): Observable<DmsCardReaderData & IDmsDeviceError> {
    let actualRead: () => (Observable<DmsCardReaderData & IDmsDeviceError>) = () => {
      return this.cancel() // Cancel ensures previous is cleared out.
        .flatMap(_ => Observable.timer(1000)) // let cancel finish
        .flatMap(_ => {
          return this
            // Call /read
            .get<ICardReaderData>("read")
            // Then map to the object.
            .map((data: ICardReaderData) => new DmsCardReaderData(data));
        });
    }

    if (isCheckStateFirst !== true) {
      return actualRead();
    }

    return this
      // get Status first
      .getStatus<ICardReaderInfo>()
      // then map to ICardReaderInfo to cehck state.
      .flatMap((payload: ICardReaderInfo) => {
        // if NOT enabled, return null;
        if (payload.curState !== "Enabled") {
          return Observable.of(null);
        }
        // Otherwise, do another GET call with read
        return actualRead();
      });
  }

  resolve(): Observable<ICardReaderInfo & IDmsDeviceError> {
    return this.getStatus<ICardReaderInfo>();
  }
}
