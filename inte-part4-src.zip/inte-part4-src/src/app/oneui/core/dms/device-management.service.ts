import { Injectable } from '@angular/core';
import { CardReader } from './devices/card-reader';
import { OneInterfaceService } from '@one-interface/one-interface.service';
import { XHRBackend } from '@angular/http';


/**
 * Main interface to DMS
 * 
 * @export
 * @class DeviceManagementService
 */
@Injectable()
export class DeviceManagementService {

  public readonly cardReader: CardReader = void 0;

  constructor(oneInterface: OneInterfaceService,
    backend: XHRBackend) {
    this.cardReader = new CardReader(oneInterface, backend);
  }
}
