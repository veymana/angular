import { ICardReaderData } from './interfaces';

export class DmsCardReaderData implements ICardReaderData {
    public service: "cardrdr";
    public method: "read";
    public track1: string;
    public track2: string;
    public name: string;
    public pan: string;
    public raw: ICardReaderData;

    /**
     * Card Number (same as PAN)
     * 
     * @readonly
     * @type {string}
     * @memberof DmsCardReaderData
     */
    public get cardNumber(): number {
        return +this.pan;
    }

    constructor(data?: ICardReaderData) {
        if (!!data === false)
            return;

        this.track1 = data.track1;
        this.track2 = data.track2;
        this.name = data.name;
        this.pan = data.pan;
        this.raw = data;
    }
}