export interface IDMSDeviceStatus {
    service?: string;
    method?: string;
    deviceStatis?: string;
}

export interface ICardReaderInfo {
    service: "cardrdr";
    method: "getinfo";
    curState: "Enabled" | "Shutdown" | "UnInitialized";
}

export interface ICardReaderData {
    service: "cardrdr";
    method: "read";
    track1: string;
    track2: string;
    name: string;
    pan: string;
}

export interface IDmsDeviceError {
    error?: any;
}

