import { IOneInterfaceService } from '@one-interface/ione-interface-service';
import { OneInterfaceService } from '@one-interface/one-interface.service';
import { Observable, Subject } from 'rxjs';
import { WindowRefService } from 'core/window-ref.service';
import { Injectable } from "@angular/core";
import { StartupService } from "core/startup.service";
import { IBranchConfigHostResponseAddress } from "core/global-navigation/models";
import { UtilsService } from 'core/utils.service';

/*
 * THIS IS A CONTRACT WITH NATIVE WRAPPER >> DO NOT CHANGE.
 * SessionSwitchReason:
 * Unknon = 0,
 * ConsoleConnect = 1,      		// A session has been connected from the console.
 * ConsoleDisconnect = 2,   		// A session has been disconnected from the console.
 * RemoteConnect = 3,       		// A session has been connected from a remote connection.
 * RemoteDisconnect = 4,    		// A session has been disconnected from a remote connection.
 * SessionLogon = 5,        		// A user has logged on to a session.
 * SessionLogoff = 6,       		// A user has logged off from a session.
 * SessionLock = 7,         		// A session has been locked.
 * SessionUnlock = 8,       		// A session has been unlocked.
 * SessionRemoteControl = 9 		// A session has changed its status to or from remote controlled mode.
 * SessionLockWithScreenSaver = 10 	// A session has been locked due to screen saver.
 * SessionScreenSaverOn = 11,      	// Custom enum: Screen Saver turned on
 * SessionScreenSaverOff = 12      	// Custom enum: Screen Saver turned off
 */
export enum SystemDeviceInformationEventEnum {
    Unknown = 0,
    ConsoleConnect = 1,
    ConsoleDisconnect = 2,
    RemoteConnect = 3,
    RemoteDisconnect = 4,
    SessionLogon = 5,
    SessionLogoff = 6,
    SessionLock = 7,
    SessionUnlock = 8,
    SessionRemoteControl = 9,
    SessionLockWithScreenSaver = 10,
    SessionScreenSaverOn = 11,
    SessionScreenSaverOff = 12
}

export interface ISystemDeviceInformationEvent {
    eventId: SystemDeviceInformationEventEnum;
    data?: any;
}
@Injectable()
export class SystemDeviceInformation implements IOneInterfaceService {
    /**
    * Namespace that matches nativer wrapper
    * 
    * @type {string}
    * @memberOf ActivityMonitor
    */
    public NATIVENAMESPACE: string = "SystemDeviceInformation";

    /**
     * Store AU this device is configured to.
     * 
     * @type {string}
     * @memberof SystemDeviceInformation
     */
    public storeAU: string = "UNSET";

    /**
     * ID of the device
     * 
     * @type {string}
     * @memberof SystemDeviceInformation
     */
    public deviceId: string = "UNSET";

    /**
     * Store AU Address/Location based on /branchconfig
     * 
     * @type {IBranchConfigHostResponseAddress}
     * @memberof SystemDeviceInformation
     */
    public storeAuLocation: IBranchConfigHostResponseAddress = void 0;

    /**
     * Creates an instance of ActivityMonitor.
     * The parameter (OneInterfaceService type) ensures this is instantiated inside OIS
     * 
     * @param {OneInterfaceService} _ois
     * 
     * @memberOf ActivityMonitor
     */
    public constructor(private _ois: OneInterfaceService, private startupService: StartupService) {
        this.onSystemDeviceInformationChangedSubject.subscribe(
            (event: ISystemDeviceInformationEvent) => this.systemDeviceInformationEventHandler(event)
        );
    }

    /**
     * ISystemDeviceInformationEvent Subject
     * 
     * @private
     * @type {Subject<ISystemDeviceInformationEvent>}@memberof SystemDeviceInformation
     */
    private onSystemDeviceInformationChangedSubject: Subject<ISystemDeviceInformationEvent> = new Subject<ISystemDeviceInformationEvent>();

    /**
     * Maintains values of session statuses.
     * 
     * @private
     * @static
     * @type {{ [key: string]: any; }}@memberof SystemDeviceInformation
     */
    private static sessionStatuses: { [key: string]: any; } = {};

    /**
     * Observable that emits a value on onSystemDevinceInformationChanged raised by native wrapper.
     * 
     * @type {Observable<any>}
     * @memberof SystemDeviceInformation
     */
    public get onSystemDevinceInformationChanged(): Observable<ISystemDeviceInformationEvent> {
        return this.onSystemDeviceInformationChangedSubject.asObservable().share();
    }

    /**
     * Event Name
     * 
     * @readonly
     * @private
     * @type {string}
     * @memberof SystemDeviceInformation
     */
    private get eventName(): string {
        return this.getOISValue("eventName") || "systemDeviceInformationChanged";
    }

    /**
     * Invokes OIS 
     * 
     * @param {string} methodName
     * @param {...any[]} params
     * @returns {*}
     * 
     * @memberOf ActivityMonitor
     */
    public invokeOIS(methodName: string, ...params: any[]): any {
        if (!!methodName === false)
            return undefined;

        methodName = this.NATIVENAMESPACE + "." + (methodName || "");
        return this._ois.invokeOIS(methodName, ...params);
    }

    /**
     * Retrieves value from OIS
     * 
     * @param {string} propertyName 
     * @returns {*} 
     * 
     * @memberOf OneInterfaceService
     */
    public getOISValue(propertyName: string): any {
        propertyName = this.NATIVENAMESPACE + "." + (propertyName || "");
        return this._ois.getOISValue(propertyName);
    }

    /**
     * Init
     * 
     * @private
     * 
     * @memberof SystemDeviceInformation
     */
    public init(): void {
        if (this._ois.isWrapped) {
            let eventName: string = this.eventName;
            Observable
                .fromEvent<CustomEvent>(WindowRefService.nativeWindow, this.eventName)
                .map((event: CustomEvent) => {
                    let retVal: ISystemDeviceInformationEvent = void 0;
                    try {
                        retVal = JSON.parse(event.detail);
                        return retVal;
                    }
                    catch (e) {
                        console.warn(`${this.NATIVENAMESPACE}: onSystemDevinceInformationChanged. Unable to parse event!`);
                        return { eventId: 0 };
                    }
                })
                .subscribe((event: ISystemDeviceInformationEvent) => { this.onSystemDeviceInformationChangedSubject.next(event); });

            console.info(`${this.NATIVENAMESPACE}: onSystemDevinceInformationChanged Observable created (for event: ${eventName})`);
        }

        // Default to query param if it exists.
        this.deviceId = (this._ois && this._ois.isWrapped && this._ois.systemDeviceInformation.getOISValue("machineName"))
            || this.startupService.launchDetails.queryParams.get("computername")
            || "UNSET";

        this.storeAU = UtilsService.lodash.padStart(this.startupService.launchDetails.queryParams.get("storeau"), 7, "0") || "UNSET";
    }

    /**
     * Special handling for session events
     * 
     * @private
     * @param {ISystemDeviceInformationEvent} event 
     * @memberof SystemDeviceInformation
     */
    private systemDeviceInformationEventHandler(event: ISystemDeviceInformationEvent): void {
        if (!!event)
            return;

        switch (event.eventId) {
            case SystemDeviceInformationEventEnum.Unknown:
                break;

            case SystemDeviceInformationEventEnum.ConsoleConnect:
                SystemDeviceInformation.sessionStatuses[event.eventId] = true;
                break;
            case SystemDeviceInformationEventEnum.ConsoleDisconnect:
                SystemDeviceInformation.sessionStatuses[event.eventId] = false;
                break;

            case SystemDeviceInformationEventEnum.RemoteConnect:
                SystemDeviceInformation.sessionStatuses[event.eventId] = true;
                break;
            case SystemDeviceInformationEventEnum.RemoteDisconnect:
                SystemDeviceInformation.sessionStatuses[event.eventId] = false;
                break;

            case SystemDeviceInformationEventEnum.SessionLock:
                SystemDeviceInformation.sessionStatuses[event.eventId] = true;
                if (SystemDeviceInformation.sessionStatuses[SystemDeviceInformationEventEnum.SessionScreenSaverOn] === true) {
                      let newEvent: ISystemDeviceInformationEvent = {
                        eventId: SystemDeviceInformationEventEnum.SessionLockWithScreenSaver
                    };
                    this.onSystemDeviceInformationChangedSubject.next(newEvent);
                }
                break;
            case SystemDeviceInformationEventEnum.SessionUnlock:
                SystemDeviceInformation.sessionStatuses[event.eventId] = false;
                SystemDeviceInformation.sessionStatuses[SystemDeviceInformationEventEnum.SessionLockWithScreenSaver] = false;
                break;

            case SystemDeviceInformationEventEnum.SessionLogon:
                SystemDeviceInformation.sessionStatuses[event.eventId] = true;
                break;

            case SystemDeviceInformationEventEnum.SessionLogoff:
                SystemDeviceInformation.sessionStatuses[event.eventId] = false;
                break;

            case SystemDeviceInformationEventEnum.SessionRemoteControl:
                break;

            case SystemDeviceInformationEventEnum.SessionLockWithScreenSaver:
                SystemDeviceInformation.sessionStatuses[event.eventId] = true;
                break;

            case SystemDeviceInformationEventEnum.SessionScreenSaverOn:
                SystemDeviceInformation.sessionStatuses[event.eventId] = true;
                if (SystemDeviceInformation.sessionStatuses[SystemDeviceInformationEventEnum.SessionLock] === true) {
                    let newEvent: ISystemDeviceInformationEvent = {
                        eventId: SystemDeviceInformationEventEnum.SessionLockWithScreenSaver
                    };
                    this.onSystemDeviceInformationChangedSubject.next(newEvent);
                }
                break;
            case SystemDeviceInformationEventEnum.SessionScreenSaverOff:
                SystemDeviceInformation.sessionStatuses[event.eventId] = false;
                SystemDeviceInformation.sessionStatuses[SystemDeviceInformationEventEnum.SessionLockWithScreenSaver] = false;

                break;
            default:
                break;
        }
    }
}