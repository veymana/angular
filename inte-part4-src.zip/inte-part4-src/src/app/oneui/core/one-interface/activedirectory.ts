import { IOneInterfaceService } from '@one-interface/ione-interface-service';
import { OneInterfaceService } from '@one-interface/one-interface.service';
import { Osuser } from '@one-interface/models/osuser';

export class Activedirectory implements IOneInterfaceService {
    /**
     * Namespace that matches nativer wrapper
     * 
     * @type {string}
     * @memberOf ActivityMonitor
     */
    public NATIVENAMESPACE: string = "ActiveDirectoryHelper";

    /**
     * Creates an instance of ActivityMonitor.
     * The parameter (OneInterfaceService type) ensures this is instantiated inside OIS
     * 
     * @param {OneInterfaceService} _ois
     * 
     * @memberOf ActivityMonitor
     */
    public constructor(private _ois: OneInterfaceService) {
        this._user = (_ois.isWrapped && new Osuser(this.getUserFromOs())) || null;
    }

    /**
    * Invokes OIS 
    * 
    * @param {string} methodName
    * @param {...any[]} params
    * @returns {*}
    * 
    * @memberOf ActivityMonitor
    */
    public invokeOIS(methodName: string, ...params: any[]): any {
        if (!!methodName === false)
            return undefined;

        methodName = this.NATIVENAMESPACE + "." + (methodName || "");
        return this._ois.invokeOIS(methodName, ...params);
    }

    /**
     * Retrieves value from OIS
     * 
     * @param {string} propertyName 
     * @returns {*} 
     * 
     * @memberOf OneInterfaceService
     */
    public getOISValue(propertyName: string): any {
        propertyName = this.NATIVENAMESPACE + "." + (propertyName || "");
        return this._ois.getOISValue(propertyName);
    }

 
    /**
     * User object retreived from OS.
     * 
     * @private
     * @type {Osuser}
     * @memberOf Activedirectory
     */
    private readonly _user: Osuser = null;

    /**
     * Retrieves user information from operating system through the native wrapper
     * 
     * @private
     * @param {...any[]} params
     * @returns {string}
     * 
     * @memberOf Activedirectory
     */
    private getUserFromOs(): string {
        return this.invokeOIS("getOsUser");
    }


    /**
     * 
     * 
     * @param {...any[]} params
     * @returns {string}
     * 
     * @memberOf Activedirectory
     */
    public get user(): Osuser {
        return this._user;
    }
}
