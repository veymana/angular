import { SkipSelf, Optional, Injectable, isDevMode } from '@angular/core';
import { Observer, Observable, Subscription, Subject } from 'rxjs/Rx';
import { User } from '#shared/user.model';
import { WindowRefService } from 'core/window-ref.service';
import { AppSettings } from '#environments/environment';
import { IOneInterfaceService } from '@one-interface/ione-interface-service';

//Native Wrapper implementations:
import { ActivityMonitor } from '@one-interface/activity-monitor';
import { Activedirectory } from '@one-interface/activedirectory';
import { ContextManager } from '@one-interface/context-manager';
import { BrowserManager } from '@one-interface/browser-manager';
import { DataContext } from '@one-interface/models/data-context';
import { SystemDeviceInformation } from '@one-interface/system-device-information';

//Helpers:
import { UtilsService } from 'core/utils.service';
import { StartupService } from 'core/startup.service';

/**
 * One Interface Service.
 * This is a singleton Wrapper class to interface with the native wrapper.
 * 
 * @export
 * @class OneInterfaceService
 */
@Injectable()
export class OneInterfaceService implements IOneInterfaceService {

  public NATIVENAMESPACE: string = "OIS";

  private subjectMap: Object = {};

  /**
   * ID: Application identifier
   * 
   * @private
   * @type {string}
   * @memberOf OneInterfaceService
   */
  private instanceId: string = null;


  /**
   * One Interface
   * 
   * @private
   * @type {*}
   * @memberOf OneInterfaceService
   */
  private static _ois: any = null;

  /**
   * One Interface
   * 
   * @readonly
   * @static
   * @type {*}
   * @memberOf OneInterfaceService
   */
  public static get OIS(): any {
    return OneInterfaceService._ois;
  }

  /**
   * Returns true if this application is wrapped fom the native wrapper.
   * 
   * @type {boolean}
   * @memberOf OneInterfaceService
   */
  public get isWrapped(): boolean {
    return this._isWrapped();
  }


  /**
   * Returns true if app is in standlone mode (not through dashboard)
   * 
   * @readonly
   * @type {boolean}
   * @memberof OneInterfaceService
   */
  public get isStandalone(): boolean {
    if (this.isWrapped === false)
      return true;

    let retVal: boolean = this.getOISValue("isStandalone");
    if (typeof (retVal) === "undefined" || retVal == null)
      return true;
    return retVal;
  }

  public get constants(): { EventNames: any } {

    return this.getOISValue("constants");
  }

  public readonly activityMonitor: ActivityMonitor = null;
  public readonly activeDirectory: Activedirectory = null;
  public readonly contextManager: ContextManager = null;
  public readonly browserManager: BrowserManager = null;
  public readonly systemDeviceInformation: SystemDeviceInformation = null;


  /**
   * 
   * 
   * @type {User}
   * @memberOf OneInterfaceService
   */
  user: User;

  /**
   * Creates an instance of OneInterfaceService.
   * 
   * @memberOf OneInterfaceService
   */
  constructor(private startupService: StartupService) {

    //Initialize children (ALWAYS!)
    this.activityMonitor = new ActivityMonitor(this);
    this.activeDirectory = new Activedirectory(this);
    this.contextManager = new ContextManager(this);
    this.browserManager = new BrowserManager(this);
    this.systemDeviceInformation = new SystemDeviceInformation(this, startupService);

    this.activityMonitor.init();
    this.systemDeviceInformation.init();

    // We are wrapped!
    OneInterfaceService._ois = WindowRefService.nativeWindow.external;
    this.instanceId = OneInterfaceService.OIS.instanceId;

    if (!this.isWrapped) {
      console.warn("OneInterface Wrapper Service NOT found.");
      return;
    }

    this.invokeOIS("setAppName", this.instanceId, AppSettings.APP_NAME);
    console.info("OneInterface Wrapper Service found. My ID: " + this.instanceId + ". My AppName: " + AppSettings.APP_NAME);
  }

  /**
   * Checks if method exists in OIS
   * 
   * @private
   * @param {string} methodName Method to check. 
   * Example: 
   * @example "ActivityMonitor.subscribe"
   * @returns {boolean} true if it exists.
   * 
   * @memberOf OneInterfaceService
   */
  public static isExistsInOIS(methodName: string): boolean {
    let retVal: boolean = false;

    // no methodname passed.
    if (!!methodName === false)
      return false;

    // Split to parts: this.OIS.namespace1.namespace2.method
    let methodParts: string[] = methodName.split(".");

    // Single method name (not nested)
    if (methodParts && methodParts.length === 1)
      return methodName in OneInterfaceService.OIS;

    let lastNest: string = methodParts.pop();
    try {
      let evalTest: string = "'" + lastNest + "' in OneInterfaceService.OIS['" + methodParts.join("']['") + "']";

      // tslint:disable-next-line:no-eval
      retVal = eval(evalTest) === true;
    } catch (exception) {
      retVal = false;
    }

    return retVal;
  }

  /**
   * Invokes OneInterfaceService wrapper method.
   * Use this instead of directly calling OIS.method*
   * 
   * @private
   * @param {string} methodName
   * @param {*} params
   * @returns {*}
   * 
   * @memberOf OneInterfaceService
   */
  public invokeOIS(methodName: string, ...params: any[]): any {

    // Ensures no one passed something().. because this will always use "something" itself.
    methodName = (methodName || "").replace(/[\(\)]/g, "").trim();

    //Check of existence first!
    if (OneInterfaceService.isExistsInOIS(methodName) === false) {
      if (this._isWrapped())
        console.error(methodName + " does not exist in OIS");
      return null;
    }

    // Since window.external may not be a JS code, we need to explicitly
    // construct the call. Otherwise, just passing params might throw an invalid argument exception.
    let argsArr: string[] = new Array();
    let args: string = "";
    let call: string = "";
    let retVal: any;

    // Construct param[0], param[1] ...
    for (let p in params) { argsArr.push("params[" + p + "]"); }
    args = argsArr.join(", ");

    // Call Signature
    call = "OneInterfaceService." + this.NATIVENAMESPACE + "." + methodName;

    if (isDevMode()) {
      console.log("To be invoked with " + (params.length || "no") + " " + (params.length > 1 ? "params" : "param") + ": " + call);
    }

    // Call Signature with params
    call += "(" + (params.length ? args : "") + ")";
    // tslint:disable-next-line:no-eval
    retVal = eval(call);

    return retVal;
  }


  /**
   * Retrieves value from OIS
   * 
   * @param {string} propertyName 
   * @returns {*} 
   * 
   * @memberOf OneInterfaceService
   */
  public getOISValue(propertyName: string): any {
    //Check of existence first!
    if (OneInterfaceService.isExistsInOIS(propertyName) === false) {
      let err: string = propertyName + " does not exist in OIS";
      console.error(err);
      return null;
    }

    // Split to parts: this.OIS.namespace1.namespace2.method
    let propertyNameParts: string[] = propertyName.split(".");
    let retVal: any = null;

    try {
      let evalTest: string = "OneInterfaceService.OIS['" + propertyNameParts.join("']['") + "']";
      // tslint:disable-next-line:no-eval
      retVal = eval(evalTest);
    } catch (exception) {
      retVal = null;
    }

    return retVal;
  }

  /**
   * Returns true if wrapped
   * 
   * @private
   * @returns {boolean}
   * 
   * @memberOf OneInterfaceService
   */
  private _isWrapped(): boolean {
    return (WindowRefService.nativeWindow && WindowRefService.nativeWindow.external && WindowRefService.nativeWindow.external.IsOisAvailable) || false;
  }

  /**
   * 
   * 
   * @param {string} id
   * @returns {User}
   * 
   * @memberOf OneInterfaceService
   */
  getUser(): User {
    let osUser: any = (this._isWrapped && this.activeDirectory.user) || null;
    let user: User = new User(osUser);
    return user;
  }

  /**
   * Publishes data to native wrapper.
   * Uses key-value pair structure
   * 
   * @param {string} key Key of data
   * @param {*} data Data to publish
   * 
   * @memberOf OneInterfaceService
   */
  publish(key: string, data: any): void {
    if (!this.isWrapped) return;
    let dataContext: DataContext = new DataContext(key, data);
    return this.contextManager.publish(dataContext);
  }

  /**
   * Publishes event data to native wrapper.
   * Events are the same as data but are no persisted and cannot
   * be retrieved with get().
   * Only current subscribers will receive events. A new
   * subscriber will not receive any past events.
   * Uses key-value pair structure
   * 
   * @param {string} key Key of event
   * @param {*} data Event data to publish
   * 
   * @memberOf OneInterfaceService
   */
  publishEvent(key: string, data: any): void {
    if (!this.isWrapped) return;
    let dataContext: DataContext = new DataContext(key, data);
    return this.contextManager.publishEvent(dataContext);
  }

  /**
   * Retrieves data from Native wrapper
   * 
   * @param {string} key Key of data to retrieve
   * @returns {*}
   * 
   * @memberOf OneInterfaceService
   */
  get(key: string): any {
    if (!this.isWrapped) return;
    return this.contextManager.get(key);
  }

  /**
   * Set data in the native wrapper
   * 
   * @param {string} key Key of data
   * @param {*} data Data to publish
   * 
   * @memberOf OneInterfaceService
   */
  set(key: string, data: any): void {
    if (!this.isWrapped) return;
    let dataContext: DataContext = new DataContext(key, data);
    return this.contextManager.set(dataContext);
  }

  /**
   * @param {string} key 
   * @returns {Subscription} 
   * 
   * @memberOf OneInterfaceService
   */
  subscribe(key: string, observer: any): Subscription {
    if (!this.isWrapped)
      return Observable.empty().subscribe(observer);

    // First check to see if we are already subscribing to events on this key in the native wrapper.
    let subject: Subject<any> = this.subjectMap[key];
    if (!subject) {
      // This is the first subscriber to this data.
      // Create a subject to use to broadcast the information to all subscribers.
      subject = new Subject<any>();
      this.subjectMap[key] = subject;
      // Subscribe to the data from the native wrapper.
      this.contextManager.subscribe(key, (data: any) => {
        // Provide the data to all subscribers
        subject.next(data);
      });
    }
    let subscription: Subscription = subject.subscribe(observer);

    // Check to see if there is a last value persisted. If so, provide to the new observer.
    let currentData: any = this.contextManager.get(key);
    if (currentData && !currentData.isError) {
      Observable.create((theObserver: any) => {
        theObserver.next(currentData);
        theObserver.complete();
      }).subscribe(observer);
    }
    return subscription;
  }
}

