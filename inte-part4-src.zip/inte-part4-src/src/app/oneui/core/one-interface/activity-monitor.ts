import { Injectable } from '@angular/core';
import { IOneInterfaceService } from '@one-interface/ione-interface-service';
import { OneInterfaceService } from '@one-interface/one-interface.service';
import { IMonitor } from '@one-interface/imonitor';
import { Observable, Subscription, Subject, Observer } from 'rxjs/Rx';
import { WindowRefService } from './../window-ref.service';
import { IActivityMonitorEvent } from './models/interfaces';

/**
 * ActivityMonitor
 * 
 * @export
 * @class ActivityMonitor
 */
@Injectable()
export class ActivityMonitor implements IOneInterfaceService, IMonitor {

    /**
     * Namespace that matches nativer wrapper
     * 
     * @type {string}
     * @memberOf ActivityMonitor
     */
    public NATIVENAMESPACE: string = "ActivityMonitor";

    /**
     * Creates an instance of ActivityMonitor.
     * The parameter (OneInterfaceService type) ensures this is instantiated inside OIS
     * 
     * @param {OneInterfaceService} _ois
     * 
     * @memberOf ActivityMonitor
     */
    public constructor(private _ois: OneInterfaceService) {
    }

    /**
     * Activity subject. Main interface between the link ActivityMonitor and native interface.
     * To subscribe to activity monitor events, other classes should subscribe to Activities.subscribe().
     * 
     * @type {Subject<any>}
     * @memberOf ActivityMonitor
     */
    private _activityChangedSubject: Subject<IActivityMonitorEvent> = new Subject<IActivityMonitorEvent>();

    public get activityChangedEvent(): Observable<IActivityMonitorEvent> {
        return this._activityChangedSubject.asObservable().share();
    }

    /**
     * Invokes OIS 
     * 
     * @param {string} methodName
     * @param {...any[]} params
     * @returns {*}
     * 
     * @memberOf ActivityMonitor
     */
    public invokeOIS(methodName: string, ...params: any[]): any {
        if (!!methodName === false)
            return undefined;

        methodName = this.NATIVENAMESPACE + "." + (methodName || "");
        return this._ois.invokeOIS(methodName, params);
    }

    /**
     * Retrieves value from OIS
     * 
     * @param {string} propertyName 
     * @returns {*} 
     * 
     * @memberOf OneInterfaceService
     */
    public getOISValue(propertyName: string): any {
        propertyName = this.NATIVENAMESPACE + "." + (propertyName || "");
        return this._ois.getOISValue(propertyName);
    }

    /**
     * 
     * Subscribes to ActivityMonitor changes
     * 
     * @memberOf ActivityMonitor
     */
    public init(): void {
        if (this._ois.isWrapped) {

            Observable.fromEvent(WindowRefService.nativeWindow, "activityChanged")
                .map((event: any) => { return (event && event.detail) || event || {} })
                .map((event: any) => {
                    try {
                        return <IActivityMonitorEvent> JSON.parse(event);
                    } catch (e) {
                        return null;
                    }
                })
                .subscribe(event => { this._onActivityChanged(event); });;
        }

    }

    /**
    * ActivityChanged event handler.
    * 
    * @private
    * @param {*} event
    * 
    * @memberOf OneInterfaceService
    */
    private _onActivityChanged(event: IActivityMonitorEvent): any {
        /**
         * Note: 
         * If using addEventListener method, payload will be in event.detail.
         * If using a callback method, payload is the event itself.
         */
        console.log("Received Activity: " + JSON.stringify(event));
        this._activityChangedSubject.next(event);
    }


    /**
     * Subscribes to the observable. 
     * 
     * @param {*} observer 
     * @returns {Subscription} 
     * 
     * @memberOf ActivityMonitor
     */
    public subscribe(observer: Observer<any>): Subscription {
        if (this.activityChangedEvent == null)
            this.init();

        return this.activityChangedEvent.subscribe(observer);
    }
}
