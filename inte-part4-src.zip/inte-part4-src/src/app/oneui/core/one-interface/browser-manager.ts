import { IOneInterfaceService } from '@one-interface/ione-interface-service';
import { OneInterfaceService } from '@one-interface/one-interface.service';
import { Observable } from 'rxjs/Observable';
import { WindowRefService } from './../window-ref.service';
import { UtilsService } from 'core/utils.service';
import { Injectable } from "@angular/core";

/**
 * BrowserManager interfaces with the browser instance of this application
 * inside the nativer wrapper.
 * 
 * @export
 * @class BrowserManager
 * @implements {IOneInterfaceService}
 */
@Injectable()
export class BrowserManager implements IOneInterfaceService {
    /**
     * Namespace that matches nativer wrapper
     * 
     * @type {string}
     * @memberOf BrowserManager
     */
    public NATIVENAMESPACE: string = "BrowserManager";

    /**
     * Invokes OIS 
     * 
     * @param {string} methodName
     * @param {...any[]} params
     * @returns {*}
     * 
     * @memberOf BrowserManager
     */
    public invokeOIS(methodName: string, ...params: any[]): any {
        if (!!methodName === false)
            return undefined;

        methodName = this.NATIVENAMESPACE + "." + (methodName || "");
        return this._ois.invokeOIS(methodName, ...params);
    }

    /**
     * Retrieves value from OIS
     * 
     * @param {string} propertyName 
     * @returns {*} 
     * 
     * @memberOf OneInterfaceService
     */
    public getOISValue(propertyName: string): any {
        propertyName = this.NATIVENAMESPACE + "." + (propertyName || "");
        return this._ois.getOISValue(propertyName);
    }

    /**
     * Creates an instance of BrowserManager.
     * The parameter (OneInterfaceService type) ensures this is instantiated inside OIS
     * 
     * @param {OneInterfaceService} _ois
     * 
     * @memberOf BrowserManager
     */
    public constructor(private _ois: OneInterfaceService) {
    }

    /**
     *  Closes browser
     * 
     * @param {boolean} [isIgnoreForce=false] if true, another method of killing browser will not be performed.
     * 
     * @memberof BrowserManager
     */
    public closeBrowser(isIgnoreForce: boolean = false): void {
        this.invokeOIS("CloseBrowser");
        if (isIgnoreForce === false)
            UtilsService.attemptKillBrowser();
    }
}
