export interface IOneInterfaceService {
    invokeOIS(methodName: string, ...params: any[]): any;
    getOISValue(propertyName: string): any;
    NATIVENAMESPACE: string;
}
