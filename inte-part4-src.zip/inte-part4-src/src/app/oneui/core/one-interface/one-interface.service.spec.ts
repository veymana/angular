/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { OneInterfaceService } from './one-interface.service';

describe('Service: OneInterface', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [OneInterfaceService]
    });
  });

  it('should ...', inject([OneInterfaceService], (service: OneInterfaceService) => {
    expect(service).toBeTruthy();
  }));
});
