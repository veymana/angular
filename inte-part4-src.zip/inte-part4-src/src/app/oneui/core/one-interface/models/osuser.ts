import { UtilsService } from 'core/utils.service';

/**
 * User information based on Operating System
 * 
 * @export
 * @class Osuser
 */
export class Osuser {

    /**
     * Is user anonymous
     * 
     * @type {boolean}
     * @memberOf Osuser
     */
    public readonly isAnonymous: boolean;

    /**
     * Is user authenticated by OS
     * 
     * @type {boolean}
     * @memberOf Osuser
     */
    public readonly isAuthenticated: boolean;

    /**
     * Is user an OS Guest
     * 
     * @type {boolean}
     * @memberOf Osuser
     */
    public readonly isGuest: boolean;

    /**
     * Is system user
     * 
     * @type {boolean}
     * @memberOf Osuser
     */
    public readonly isSystem: boolean;

    /**
     * User label
     * 
     * @type {string}
     * @memberOf Osuser
     */
    public readonly label: string;

    /**
     * User name
     * 
     * @type {string}
     * @memberOf Osuser
     */
    public readonly networkIdString: string;

    /**
     * Profile Photo
     * 
     * @memberOf Osuser
     */
    public readonly profilePhoto = {
        large: "",
        small: ""
    };


    /**
     * Creates an instance of Osuser.
     * 
     * @param {string} [data]
     * 
     * @memberOf Osuser
     */
    public constructor(data?: string) {
        if (!!data === false)
            return;

        let dataAsObj: Object = null;
        try {
            dataAsObj = JSON.parse(data);
        }
        catch (e) {
            console.warn("Osuser.ctor: Unable to parse data.");
            return;
        }

        if (dataAsObj == null)
            return;

        for (let key of Object.keys(dataAsObj)) {
            UtilsService.setIfExists(key, dataAsObj, this);
        }
    }
}
