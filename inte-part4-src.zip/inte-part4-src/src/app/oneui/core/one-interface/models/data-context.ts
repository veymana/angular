export class DataContext {
    public data: string | Object;
    public key: string;
    public lastModified?: string;
    public owner?: any;
    public isPrivate?: boolean = false;
    public error?: any;

    public constructor(pKey?: string, pData?: string | Object, isPriv?: boolean, lastModified?: string, owner?: string, error?: any) {
        if (typeof (pKey) !== "undefined" && typeof (pKey) !== "string")
            throw new Error("Key must be a string");

        // This already throws exception if any.
        // Do not catch exception.
        // Let calling code catch it.
        try {

            if (typeof (pData) === "string")
                this.data = JSON.parse(pData);
            else
                this.data = pData;

        } catch (e) {
            this.data = pData;
        }

        this.key = pKey;
        this.isPrivate = isPriv || false;
        this.lastModified = lastModified || undefined;
        this.owner = owner || undefined;
        this.error = error || undefined;
    }

    public static convert(inputObject: string | CustomEvent): DataContext {

        if (typeof (inputObject) === "string") {
            try {
                let parsedDc: any = JSON.parse(inputObject);
                if (typeof (parsedDc) === "string")
                    parsedDc = JSON.parse(parsedDc);

                if (!!parsedDc.key && typeof (parsedDc.data) !== "undefined")
                    return new DataContext(
                        parsedDc.key,
                        parsedDc.data,
                        parsedDc.isPrivate || undefined,
                        parsedDc.lastModified || undefined,
                        parsedDc.owner || undefined,
                        parsedDc.error || undefined
                    );

            } catch (e) {
                let errorMsg: string = "Unable to parse to DataContext";
                console.warn(errorMsg);
                throw new Error(errorMsg);
            }
        }

        else if (typeof (inputObject) === "object" && (inputObject instanceof CustomEvent)) {
            let inputObj: any = JSON.stringify((inputObject && inputObject.detail) || "");
            return DataContext.convert(inputObj);
        }

        else if ((typeof (inputObject)).toString() === "unknown") {
            let inputObj: any = JSON.stringify((inputObject) || "");
            return DataContext.convert(inputObj);
        }

        else if (inputObject === null || typeof(inputObject) === "undefined") {
            return null;
        }

        else {
            let errorMsg: string = `DataContext.convert - invalid input type (${typeof (inputObject)})`;
            console.warn(errorMsg);
            throw new Error(errorMsg);
        }
    }
}
