export interface IActivityMonitorEvent {
    activity: string;
    appName: string;
    id: string;
    isBroadcast: boolean;
    timestamp: string;
}

export interface IConfirmNavigateEvent {
    type?: "navigate" | "close";
    url: string;
    isExternal: boolean;
    isSticky: boolean;
}