import { IOneInterfaceService } from '@one-interface/ione-interface-service';
import { OneInterfaceService } from '@one-interface/one-interface.service';
import { DataContext } from '@one-interface/models/data-context';
import { Observable } from 'rxjs/Observable';
import { WindowRefService } from './../window-ref.service';
import { UtilsService } from 'core/utils.service';
import { Injectable } from "@angular/core";

@Injectable()
export class ContextManager implements IOneInterfaceService {
    /**
     * Namespace that matches nativer wrapper
     * 
     * @type {string}
     * @memberOf ContextManager
     */
    public NATIVENAMESPACE: string = "ContextManager";

    /**
     * Invokes OIS 
     * 
     * @param {string} methodName
     * @param {...any[]} params
     * @returns {*}
     * 
     * @memberOf ContextManager
     */
    public invokeOIS(methodName: string, ...params: any[]): any {
        if (!!methodName === false)
            return undefined;

        methodName = this.NATIVENAMESPACE + "." + (methodName || "");
        return this._ois.invokeOIS(methodName, ...params);
    }

    /**
     * Retrieves value from OIS
     * 
     * @param {string} propertyName 
     * @returns {*} 
     * 
     * @memberOf OneInterfaceService
     */
    public getOISValue(propertyName: string): any {
        propertyName = this.NATIVENAMESPACE + "." + (propertyName || "");
        return this._ois.getOISValue(propertyName);
    }

    /**
     * Creates an instance of ContextManager.
     * The parameter (OneInterfaceService type) ensures this is instantiated inside OIS
     * 
     * @param {OneInterfaceService} _ois
     * 
     * @memberOf ContextManager
     */
    public constructor(private _ois: OneInterfaceService) {
    }

    /**
     * Publishes data by key.
     * Data is made available to anyone (all apps)
     * 
     * @param {DataContext} dataContext data to store
     * @returns {*} true if successful. Otherwise object is returned : { isError, message }
     * 
     * @memberOf ContextManager
     */
    public publish(dataContext: DataContext): any {
        return this.save(dataContext, true);
    }


    /**
     * Sets data. Data is private to this app only
     * 
     * @param {string} key
     * @param {*} data
     * @returns {*} true if successful. Otherwise object is returned : { isError, message }
     * 
     * @memberOf ContextManager
     */
    public set(dataContext: DataContext): any {
        return this.save(dataContext, false);
    }


    /**
     * Retrieves data from native wrapper. If app owns the data, it can retrieve it. Otherwise, it depends
     * on whether or not isPrivate=true/false is set to the data by the owner.
     * 
     * @param {string} key
     * @param {boolean} [isGetFromAll=false] if true, data is retreived from the central bucket. Otherwise, only local data is retrieved.
     * @returns {*}
     * 
     * @memberOf ContextManager
     */
    public get(key: string, isGetFromAll: boolean = false): any {
        var payloadFromOis: string | any = this.invokeOIS("get", key, isGetFromAll);
        let retVal: DataContext;

        retVal = DataContext.convert(payloadFromOis);
        return retVal;
    }


    /**
     * Causes dataContext to be published immediately to all subscribers.
     * Data is NOT stored in native wrapper.
     * 
     * @param {DataContext} dataContext 
     * @returns {*} 
     * 
     * @memberOf ContextManager
     */
    public publishEvent(dataContext: DataContext): any {
        return this._publishEvent(dataContext);
    }

    /**
     * Retrieves data from native wrapper. If app owns the data, it can retrieve it. Otherwise, it depends
     * on whether or not isPrivate=true/false is set to the data by the owner.
     * 
     * @param {string} key
     * @returns {*}
     * 
     * @memberOf ContextManager
     */
    public getAll(key: string): any {
        return this.invokeOIS("get", key, true);
    }

    /**
     * Saves data to native wrapper.
     * 
     * @private
     * @param {string} key
     * @param {*} data
     * @param {boolean} isPublish
     * @returns {*}
     * 
     * @memberOf ContextManager
     */
    private save(dataContext: DataContext, isPublish: boolean): any {
        let dataC: any = UtilsService.clone(dataContext, false);
        dataC.isPrivate = isPublish === false;
        let verb: string = isPublish ? "publish" : "set";

        // Native wrapper expects a stringified data
        dataC.data = JSON.stringify(dataC.data);

        let retVal: any = this.invokeOIS(verb, JSON.stringify(dataC));
        return retVal;
    }


    /**
     * Causes dataContext to be published immediately to all subscribers.
     * Data is NOT stored in native wrapper.
     * 
     * @private
     * @param {DataContext} dataContext 
     * @returns 
     * 
     * @memberOf ContextManager
     */
    private _publishEvent(dataContext: DataContext) {
        dataContext.isPrivate = false;
        // Native wrapper expects a stringified data
        dataContext.data = JSON.stringify(dataContext.data);
        var retVal: any = this.invokeOIS("publishEvent", JSON.stringify(dataContext));
        return retVal;
    }

    private _dataChangedObservables: any = {};

    /**
     * Subscribes to data changes if data on that key has changed.
     * If an observable is not created, it will create one.
     * If an observable is already created, it will return the previously created one.
     * 
     * @param {string} key Key of data to monitor.
     * @param {*} onChangedCallback This will be invoked when data has changed.
     * @returns {*}
     * 
     * @memberOf ContextManager
     */
    public subscribe(key: string, observer: any): any {

        let observable: Observable<DataContext> = Observable.empty();
        
        if (this._ois.isWrapped) {
            observable = this._dataChangedObservables[key];
        }

        // first check if an observable was previously created based on this key.
        // Otherwise, create a new observable.
        if (!!observable === true) {
            console.info(`Observable retrieved for ${key}`);
        }
        else {
            console.info(`Observable created for ${key}`);
            observable = Observable
                .fromEvent(WindowRefService.nativeWindow, key)
                .map((data: string | CustomEvent) => { return DataContext.convert(data); });

            // Add to list of observables so we dont have to create new ones all the time.
            // This preserves the observables so that emissions are not duplicated.
            this._dataChangedObservables[key] = observable;

            // TODO: This may need clean up on certain app states.
        }

        return observable.subscribe(observer);
    }

    /**
     * Returns all keys in the (public) All bucket of the native wrapper.
     * Only those marked as Private=false will be returned.
     * 
     * @returns {string[]} Array of previously published keys
     * 
     * @memberOf ContextManager
     */
    public getAllKeys(): string[] {
        let allKeys = this.invokeOIS("getAllKeys");
        if (typeof (allKeys) !== "string")
            return [];

        try {
            return JSON.parse(allKeys);
        } catch (e) {
            return [];
        }
    }

}
