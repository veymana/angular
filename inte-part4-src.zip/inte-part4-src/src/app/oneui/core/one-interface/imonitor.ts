import { Subscription, Observer } from 'rxjs/Rx';

/**
 * Monitor Interface
 * 
 * @export
 * @interface IMonitor
 */
export interface IMonitor {
    subscribe(observer: Observer<any>): Subscription;
}