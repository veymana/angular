import { RouterOutletExDirective } from './router-outlet-ex.directive';

describe('RouterOutletExDirective', () => {
  it('should create an instance', () => {
    const directive = new RouterOutletExDirective();
    expect(directive).toBeTruthy();
  });
});
