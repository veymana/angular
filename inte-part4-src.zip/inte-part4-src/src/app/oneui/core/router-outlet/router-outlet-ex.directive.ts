import { Inject, Input, Directive, forwardRef } from '@angular/core';
import { Observable } from 'rxjs';
import { RouterOutlet } from '@angular/router';
import { UtilsService } from 'core/utils.service';
import { RouterOutletService, IOnActivateOrDeactivateEvent } from 'core/router-outlet/router-outlet.service';

/**
 * router-outlet Extension.
 * This directive is used to provide a default activate and deactivate events for the router-outlets.
 * 
 * @export
 * @class RouterOutletExDirective
 */
@Directive({
  selector: 'router-outlet'
})
export class RouterOutletExDirective {
  constructor( @Inject(forwardRef(() => RouterOutlet)) private actualRouterOutlet: RouterOutlet,
    private routerOutletService: RouterOutletService) {
    this.actualRouterOutlet.activateEvents.subscribe(_ => this.onActivateOrDeactivate());
    this.actualRouterOutlet.deactivateEvents.subscribe(_ => this.onActivateOrDeactivate());
  }

  ngOnInit() {

  }

  private onActivateOrDeactivate() {
    let outletName: string = this.actualRouterOutlet["name"];
    this.routerOutletService.broadcast({
      outletName: outletName || "primary",
      isActivated: this.actualRouterOutlet.isActivated,
      component: this.actualRouterOutlet["activated"] && this.actualRouterOutlet.component
    });
  }
}
