import { Injectable, ComponentRef } from '@angular/core';
import { Subject, Observable } from 'rxjs';

export interface IOnActivateOrDeactivateEvent {
  outletName: string;
  isActivated: boolean;
  component: ComponentRef<any> | Object;
}
@Injectable()
export class RouterOutletService {
  public routerOutlets: { [outletName: string]: IOnActivateOrDeactivateEvent } = {};
  private onActivateOrDeactivateSubject: Subject<IOnActivateOrDeactivateEvent> = new Subject<IOnActivateOrDeactivateEvent>();
  public get onActivateOrDeactivateEvent(): Observable<IOnActivateOrDeactivateEvent> {
    return this.onActivateOrDeactivateSubject.asObservable().share();
  }
  constructor() {
    this.onActivateOrDeactivateEvent.subscribe((onActivateOrDeactivateEvent: IOnActivateOrDeactivateEvent) => {
      this.routerOutlets[onActivateOrDeactivateEvent.outletName] = onActivateOrDeactivateEvent;
    });
  }

  /**
   * Broadcasts the onActivateOrDeactivateEvent event
   * 
   * @param {IOnActivateOrDeactivateEvent} onActivateOrDeactivateEvent 
   * 
   * @memberof RouterOutletService
   */
  public broadcast(onActivateOrDeactivateEvent: IOnActivateOrDeactivateEvent) {
    setTimeout(_ => this.onActivateOrDeactivateSubject.next(onActivateOrDeactivateEvent));
  }

}
