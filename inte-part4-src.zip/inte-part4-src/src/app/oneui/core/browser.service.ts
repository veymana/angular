import { Injectable, Inject } from '@angular/core';
import { AppSettings } from '#environments/environment';
import { DOCUMENT } from '@angular/platform-browser';


@Injectable()
export class BrowserService {

  constructor( @Inject(DOCUMENT) private document: any) {
    setTimeout(_ => { this.setup(); });
  }

  private setup() {
    if (!!this.document === false || !!this.document.body === false) {
      setTimeout(_ => { this.setup(); });
      return;
    }
    let c = AppSettings.BrowserConfig;
    for (let eventName of Object.keys(AppSettings.BrowserConfig)) {
      this.setHandler(eventName, AppSettings.BrowserConfig[eventName]);
    }
  }

  private setHandler(eventName: string, configValue: boolean | Function) {
    let nullify: () => void = () => { return false };
    let body: HTMLElement = this.document.body;
    if (typeof configValue === "boolean" && configValue === false) {
      body[`on${eventName}`] = nullify;
      return;
    }
    if (typeof configValue === "function") {
      body[`on${eventName}`] = function () {
        configValue();
        return false;
      }
      return;
    }
  }

}
