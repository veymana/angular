import { Injectable, Injector, ReflectiveInjector } from '@angular/core';
import { Location } from "@angular/common";
import { Subscription } from 'rxjs/Subscription';
import { Subject } from 'rxjs/Subject';
import { Router } from '@angular/router';
import { Observable, BehaviorSubject } from 'rxjs/Rx';
import { UtilsService } from 'core/utils.service';
import { IChannel, IFlows, FlowService } from 'core/flow';
import { Flow } from 'core/flow/models/flow';
import { Reason } from '../models/reason.model';
import { RestResource } from 'core/restclient/rest-resource';
import { Restclient } from 'core/restclient/restclient-base.service';
import { AppSettings } from '#environments/environment';
import { OneInterfaceService } from '@one-interface/one-interface.service';
import { XHRBackend, RequestOptions, Response } from '@angular/http';
import { IStageDirectorFlows } from '../models/interfaces';
import { IVisitReasons, IReasons } from '../models/interfaces';

import { PopupService } from '#shared/popup/popup.service';
import { IUserMessageOnClickEvent } from '#shared/popup/models';
import { SystemDeviceInformationEventEnum, ISystemDeviceInformationEvent } from '@one-interface/system-device-information';
import { IRestDetail } from '#environments/interfaces';

import { InactivityService } from 'core/inactivity.service';
import { TerminatesessionService } from 'core/restclient/terminate-session-restclient.service';
import { ConnectivityService } from 'core/connectivity.service';
import { AppLoggerService } from 'core/app-logger.service';

/*
 * jskFlowService
 * StageDirector-related FlowService
 * Extension of Main FlowService
 * 
 * @export
 * @class jskFlowService
 */
@Injectable()
export class JumpStartKitFlowService extends FlowService {

  /**
   * Name of this service
   * 
   * @type {string}
   * @memberOf jskFlowService
   */
  public readonly name: string = "jskFlowService";


  /**
   * Parsed __RAW__ Main flow definition
   * 
   * 
   * @memberOf FlowService
   */
  public get channels(): IStageDirectorFlows {
    return <IStageDirectorFlows>FlowService.channels;
  }

  public static instance: JumpStartKitFlowService;

  private static lastCommLoss: Date = void 0;

  constructor(router: Router,
    private ois: OneInterfaceService,
    private backend: XHRBackend,
    private popupService: PopupService,
    injector: Injector,
    location: Location,
    private inactivityService: InactivityService,
    private terminatesessionService: TerminatesessionService,
    private connectivityService: ConnectivityService,
    private appLoggerService: AppLoggerService) {
    super(router, injector, location, JumpStartKitFlowService.name);

    JumpStartKitFlowService.instance = this;
    this.subscribeToSystemDeviceInformationChanged();
    //Only in standalone mode show inactivity pop-up warning.
    if (!this.ois.isWrapped) {
      this.subscribeToInactivityService();
    }

    this.subscribeToConnectivityService();
  }

  /**
   * Subscribe to Device Changes
   * 
   * @private
   * 
   * @memberof jskFlowService
   */
  private subscribeToSystemDeviceInformationChanged(): void {
    this.ois.systemDeviceInformation.onSystemDevinceInformationChanged.subscribe(
      (event: ISystemDeviceInformationEvent) => {
        switch (event.eventId) {
          case SystemDeviceInformationEventEnum.Unknown:
            break;
          case SystemDeviceInformationEventEnum.ConsoleConnect:
            break;
          case SystemDeviceInformationEventEnum.ConsoleDisconnect:
            break;
          case SystemDeviceInformationEventEnum.RemoteConnect:
            break;
          case SystemDeviceInformationEventEnum.RemoteDisconnect:
            break;
          case SystemDeviceInformationEventEnum.SessionLock:
            console.warn("Workstation was locked!");
            break;
          case SystemDeviceInformationEventEnum.SessionLogoff:
            break;
          case SystemDeviceInformationEventEnum.SessionLogon:
            break;
          case SystemDeviceInformationEventEnum.SessionRemoteControl:
            break;
          case SystemDeviceInformationEventEnum.SessionUnlock:
            console.info("Workstation was unlocked!");
            break;
          case SystemDeviceInformationEventEnum.SessionLockWithScreenSaver:
            this.terminatesessionService.terminate(true);
            break;
          case SystemDeviceInformationEventEnum.SessionScreenSaverOn:
            console.warn("Screen Saver turned on");
            break;
          case SystemDeviceInformationEventEnum.SessionScreenSaverOff:
            console.warn("Screen Saver turned off");
            break;
          default:
            console.log(`Unhandled onSystemDevinceInformationChanged: ${event.eventId}`);
            break;
        }
      }
    );

  }

  /**
   * This is invoked when the FlowService detects a flow change that will cause
   * a possible data loss (from FlowService.resetAllData())
   * 
   * Because this is static and must be resolved in AOT, it will not have access to 
   * application services. According to Angular2 design guide, static methods should access the injector
   * to retrieve the service. In this case, the injector must statically exist first, for this to work.
   * 
   * onPossibleDataLossEntryCallback() has to be static because AppSettings in environment.ts is also a static class,
   * and therefore must be resolvable in AOT.
   * 
   * @static
   * @returns {Observable<any>} 
   * 
   * @memberof jskFlowService
   */
  public static onPossibleDataLossEntryCallback(): Observable<any> {
    let jskFlowService: JumpStartKitFlowService = FlowService && FlowService.injector && FlowService.injector.get(JumpStartKitFlowService);
    if (!!jskFlowService === false) {
      console.warn(`onPossibleDataLossEntryCallback(): injector could not resolve the service. Emitting successful value to continue flow.`);
      return Observable.of(true);
    }

    if (!!jskFlowService.onPossibleDataLoss === false) {
      console.warn(`onPossibleDataLossEntryCallback(): injector resolved the service but could not resolve onPossibleDataLoss()`);
      return Observable.of(true);
    }

    return jskFlowService.onPossibleDataLoss();
  }

  /**
   * Ask if user wants to proceed on possible data loss.
   * 
   * @returns {Observable<any>} 
   * 
   * @memberof jskFlowService
   */
  public onPossibleDataLoss(): Observable<boolean> {
    let clickSbj: Subject<boolean> = new Subject<boolean>();
    const dataLossPopupName: string = "CONTINUEWILLCANCEL";
    let popupServiceOnClickEvent: Observable<IUserMessageOnClickEvent> = this.popupService.show(dataLossPopupName);
    let retVal: Observable<boolean> = popupServiceOnClickEvent
      .map((val: IUserMessageOnClickEvent) => {
        let newMappedValue: boolean;
        if (val.button.action === "CONTINUE")
          newMappedValue = true;
        else
          newMappedValue = false;

        this.popupService.close();
        return newMappedValue;
      });

    return retVal;
  }

  private subscribeToInactivityService(): void {
    this.inactivityService.onWarningEvent.asObservable().subscribe(
      (dateTimeOccurred: Date) => {
        this.popupService.show("INACTIVITY_WARNING").subscribe(
          (clickEvent: IUserMessageOnClickEvent) => {
            this.inactivityService.restart();
          }
        );
      }
    );
    this.inactivityService.onLoggedOffEvent.asObservable().subscribe(
      (dateTimeOccurred: Date) => {
        this.popupService.show("INACTIVITY_LOGGEDOFF");
        //TODO: MORE LOGIC HERE based on requirements
        //call terminate session??
      }
    );
  }

  private subscribeToConnectivityService(): void {
    this.connectivityService.onConnectivityLostObservable
      .subscribe(
      (_: any) => {
        this.popupService.show("COMMERROR");
        JumpStartKitFlowService.lastCommLoss = new Date();
      },
      (error: any) => { }
      );

    this.connectivityService.onConnectivityRestoredObservable
      .subscribe(
      (_: any) => {
        this.popupService.show("COMMRESTORED");
        let lastCommLoss: string = !!JumpStartKitFlowService.lastCommLoss && JumpStartKitFlowService.lastCommLoss.toISOString();
        let logMsg: string = "COMMRESTORED";
        if (!!lastCommLoss) {
          logMsg += `: Previous commLoss: ${lastCommLoss}`;
        }
        this.appLoggerService.logWarn(logMsg);
        JumpStartKitFlowService.lastCommLoss = void 0;
      },
      (error: any) => { }
      );
  }




}
















