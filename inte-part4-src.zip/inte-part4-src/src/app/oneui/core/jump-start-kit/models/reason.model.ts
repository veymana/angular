
export class Reason {
    public reasonCode: string;
    public reasonText: string;
    public isSelected: boolean;
    constructor(reasonCode: string, reasonText: string) {
        this.reasonCode = reasonCode;
        this.reasonText = reasonText;
        this.isSelected = false;
    }

}