import { IChannel, IFlows } from 'core/flow';
import { Reason } from './reason.model';

/**
 * IStageDirectorFlows
 * IFlow definition internal to Stage Director 
 * 
 * @interface IStageDirectorFlows
 * @extends {IFlow}
 */
export interface IStageDirectorFlows extends IChannel {
    "defaultChannel": string;
    "customer": IFlows;
    "guest": IFlows;
}

export interface IReasons extends Array<Reason> { }

export interface IReasonsParent {
    reasons: Array<Reason>
}

export interface IVisitReasons {
    reasonsForCustomerVisit: Array<Reason>;
    reasonsForGuestVisit: Array<Reason>
}
