/**
 * flow steps Model
 * 
 * @export
 * @class Flowsteps
 */

export class FlowStep {
    
    /**
   * Id
   * 
   * @type {string}
   * @memberOf FlowSteps
   */
  public id: string = "";

  /**
   * Router Id
   * 
   * @type {string}
   * @memberOf FlowSteps
   */
  public routerId: string = "";

  /**
   * Header Text
   * 
   * @type {string}
   * @memberOf FlowSteps
   */
  public headerText: string = "";

    /**
   * Data
   * 
   * @type {string}
   * @memberOf FlowSteps
   */
  public data: any = null;


/**
   * Is Completed
   * 
   * @type {Boolean}
   * @memberOf FlowSteps
   */
  public isComplete: boolean = false;


/**
   * Creates an instance of steps for the flow.
   * 
   * @param none
   * 
   * @memberOf Flow Steps
   */
  public constructor(id: string, routerId: string, headerText: string, data: Object, isComplete: boolean) {
    this.id = id;
    this.routerId = routerId;
    this.headerText = headerText;
    this.data = data;
    this.isComplete = isComplete;    
  }
  

}
