/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { GlobalNavigationService } from './global-navigation.service';

describe('GlobalNavigationService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [GlobalNavigationService]
    });
  });

  it('should ...', inject([GlobalNavigationService], (service: GlobalNavigationService) => {
    expect(service).toBeTruthy();
  }));
});
