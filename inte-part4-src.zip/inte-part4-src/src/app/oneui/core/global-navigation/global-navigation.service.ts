import { Injectable, Inject, Injector } from '@angular/core';
import { IApplicationLink, IApplicationLinkIconType, IBranchConfigHostResponseAppLink, IBranchConfigHostResponse, ApplicationLink } from './models';
import { AppSettings } from '#environments/environment';
import { OneInterfaceService } from '@one-interface/one-interface.service';
import { Http, XHRBackend, RequestOptions } from '@angular/http';
import { Restclient } from 'core/restclient/restclient-base.service';
import { RestResource } from 'core/restclient/rest-resource';
import { UtilsService } from 'core/utils.service';

import { DataContext } from '@one-interface/models/data-context';
import { UserService } from 'core/user.service';
import { User } from '#shared/user.model';
import { Observable, BehaviorSubject } from 'rxjs';
import { AuthorizationService } from 'core/authorization.service';
import { WindowRefService } from 'core/window-ref.service';
import { IConfirmNavigateEvent } from 'core/one-interface/models/interfaces';
import { FlowService } from 'core/flow/flow.service';
import { IUserMessageOnClickEvent } from '#shared/popup/models/interfaces';
import { FlowStateEnum } from 'core/flow/models/interfaces';
import { PopupService } from '#shared/popup/popup.service';
import { TerminatesessionService } from 'core/restclient/terminate-session-restclient.service';

const BRANCHCONFIGNAVITEMSKEY: string = "branchConfigNavItems";
const CONFIRMNAVIGATEEVENTKEY: string = "confirmNavigate";

@Injectable()
export class GlobalNavigationService {
  private rc: Restclient = new Restclient(this.ois,
    this.backend,
    new RestResource(UtilsService.getResourceDetail("branchconfig")));

  public navigationItems: BehaviorSubject<Array<IApplicationLink | ApplicationLink>> = new BehaviorSubject<Array<IApplicationLink | ApplicationLink>>(AppSettings.GlobalNavigationConfig.fallbackApplicationList);
  private isInit: boolean = true;

  constructor(
    private ois: OneInterfaceService,
    private backend: XHRBackend,

    private userService: UserService,
    private authorizationService: AuthorizationService,
    private flowService: FlowService,
    private terminatesessionService: TerminatesessionService,
    @Inject(Injector) private injector: Injector) {
    this.userService.getUserObservable().subscribe(
      (user: User) => {
        if (!!user && user.isAuthenticated)
          this.init();
      },
      (err: any) => {

      }
    );
  }

  private get popupService(): PopupService {
    return this.injector.get(PopupService);
  }

  public init(): void {
    if (this.isInit === false)
      return;

    let dc: DataContext = this.ois.contextManager.get(BRANCHCONFIGNAVITEMSKEY, true);
    if (!!dc === false || dc.error) {
      this.rc.get()
        .map((res: Response) => res.json())
        .subscribe(
        (data: any) => { this.constructNavigationItems(data); this.isInit = false; },
        (err: any) => { this.isInit = true; }
        );
    }
    else {
      this.navigationItems.next(dc.data as Array<ApplicationLink>);
      this.isInit = false;
    }

    this.subscribeToConfirmNavigate();
  }

  /**
   * Parses host response and constructs navigation links
   * 
   * @private
   * @param {IBranchConfigHostResponse} dataFromHost 
   * 
   * @memberof GlobalNavigationService
   */
  private constructNavigationItems(dataFromHost: IBranchConfigHostResponse): void {
    let constructed: ApplicationLink[] = [];
    this.ois.systemDeviceInformation.storeAuLocation = dataFromHost.address;


  }

  /**
   * Sets everything to external.
   * 
   * @private
   * @memberof GlobalNavigationService
   */
  private setAllLinksToExternalIfNeeded(): void {
    if (!this.ois.isStandalone)
      return;

    let navItems: ApplicationLink[] = <ApplicationLink[]>this.navigationItems.getValue();
    for (let navLink of navItems) {
      navLink.isExternal = true;
    }
    this.navigationItems.next(navItems);
  }

  /**
   * Publishes to Native Wrapper
   * 
   * @private
   * 
   * @memberof GlobalNavigationService
   */
  private publishToOINW(navItems: any): void {
    let dC: DataContext = new DataContext(
      BRANCHCONFIGNAVITEMSKEY,
      navItems,
      false
    );
    this.ois.contextManager.publish(dC);

    // isStandalone flag of native wrapper depends on the branch config.
    // This means we can only check the flag after the publication.
    setTimeout(() => {
      this.setAllLinksToExternalIfNeeded();
    }, 1000);

  }

  // Subscribe to native wrapper for the confirmNavigate event.
  // When a user is trying to navigate, check if we need to confirm.
  private subscribeToConfirmNavigate(): void {
    if (this.ois.isWrapped && !!AppSettings.GlobalNavigationConfig.isCheckFlowBeforeNavigatingToLink) {

      Observable.fromEvent(WindowRefService.nativeWindow, CONFIRMNAVIGATEEVENTKEY)
        .map((event: any) => { return (event && event.detail) || event || {}; })
        .map((event: any) => {
          try {
            return <IConfirmNavigateEvent>JSON.parse(event);
          } catch (e) {
            return null;
          }
        })
        .subscribe((event: IConfirmNavigateEvent) => this.confirmNavigation(event));
    }
  }

  private confirmNavigation(event: IConfirmNavigateEvent): void {
    if (!!event === false || this.flowService.flowState !== FlowStateEnum.dirty) {
      this.navigate(event);
      return;
    }

    if (event.type === "navigate") {
      //CONTINUEWILLCANCEL: CLOSE/CONTINUE
      this.popupService.show("CONTINUEWILLCANCEL").subscribe(
        (clickEvent: IUserMessageOnClickEvent) => {
          let action: string = clickEvent && clickEvent.button && clickEvent.button.action || "";
          if (action === "CONTINUE") {
            this.onNavigateConfirmed(event);
          }
          else {
            this.popupService.close();
          }
        }
      );
    } else {
      //LEAVEWILLCANCEL: CLOSE/CONTINUE
      this.popupService.show("LEAVEWILLCANCEL").subscribe(
        (clickEvent: IUserMessageOnClickEvent) => {
          let action: string = clickEvent && clickEvent.button && clickEvent.button.action || "";
          if (action === "CONTINUE") {
            this.onCloseConfirmed();
          }
          else {
            this.popupService.close();
          }
        }
      );
    }
  }

  private onNavigateConfirmed(e: IConfirmNavigateEvent): void {
    this.navigate(e);
    this.flowService.start(null, null, null, true, true);
    this.popupService.close();
  }

  private onCloseConfirmed(): void {
    this.terminatesessionService.terminate(true, false);
  }

  private navigate(e: IConfirmNavigateEvent): void {
    if (e.isExternal) {
      window.open(e.url,
        e.isExternal ? "_blank" : "_self",
        e.isSticky ? "fullscreen=yes, menubar=no, resizable=no, status=no, toolbar=no" : "");
    } else {
      window.location.href = e.url;
    }
  }

}


