/**
 * Application Icon Type Interface
 * 
 * @export
 * @interface IApplicationIconType
 */
export interface IApplicationLinkIconType {
    /**
     * If present, this url is used, in conjunction with width and height.
     * @type {string}
     * @memberOf IApplicationIconType
     */
    url?: string;


    /**
     * Icon Width (if icon is used)
     * 
     * @type {string}
     * @memberOf IApplicationIconType
     */
    width?: string;


    /**
     * Icon Height (if icon is used)
     * 
     * @type {string}
     * @memberOf IApplicationIconType
     */
    height?: string;

    /**
     * Color of icon element
     * 
     * @type {string}
     * @memberOf IApplicationIconType
     */
    color?: string;
}


/**
 * 
 * 
 * @export
 * @interface IApplication
 */
export interface IApplicationLink {
    /**
     * Unique ID
     * 
     * @type {string}
     * @memberOf IApplication
     */
    id: string;

    /**
     * Category
     * 
     * @type {string}
     * @memberOf IApplication
     */
    category: string;

    /**
     * Order number as displayed on list
     * 
     * @type {number}
     * @memberOf IApplication
     */
    displayOrder: number;

    /**
     * Application Name
     * 
     * @type {string}
     * @memberOf IApplication
     */
    name: string;
    /**
     * Text to be displayed.
     * Ignored if textKey is used.
     * 
     * @type {string}
     * @memberOf IApplication
     */
    text?: string;

    /**
     * Language Database key to use.
     * Ignores text property if this is set.
     * 
     * @type {string}
     * @memberOf IApplication
     */
    textKey?: string;
    /**
     * 
     * 
     * @type {string}
     * @memberOf IApplication
     */
    url: string;
    /**
     * Link target
     * 
     * @type {string}
     * @memberOf IApplication
     */
    isExternal?: boolean; // Optional: Defaults to self
    /**
     * Application Icon Type
     * 
     * @type {IApplicationLinkIconType}
     * @memberOf IApplication
     */
    icon?: IApplicationLinkIconType;
    /**
     * Should app remain in native?
     * 
     * @type {boolean}
     * @memberof IApplication
     */
    isSticky?: boolean;
    /**
     * The translated display name.
     * This is sent to native wrapper and the native wrapper uses this text.
     * 
     * @type {string}
     * @memberof IApplicationLink
     */
    translatedName?: string;
    /**
     * Function Identifier
     * 
     * @type {string}
     * @memberof IApplicationLink
     */
    functionId: string;
    
    /**
     * Show on pages?
     * 
     * @type {boolean}
     * @memberof IApplicationLink
     */
    isShow?: boolean;

    /**
     * True if user is authorized to use this link.
     * 
     * @type {boolean}
     * @memberof IApplicationLink
     */
    isAuthorized?: boolean;

    /**
     * The context to be used in translations.
     * 
     * @type {*}@memberof ApplicationLink
     */
    translateContext?: any;    

    /**
     * OnClick handler
     */
    onClick?: Function;
}

export interface IBranchConfigHostResponseAddress {
    lineList: string[];
    city: string;
    zipCode: string;
    stateCode: string;
}

export interface IBranchConfigHostResponse {
    address?: IBranchConfigHostResponseAddress;
    branchConfigs: Array<IBranchConfigHostResponseAppLink>;
}

/**
 * Host response structure for /branchconfig
 * 
 * @export
 * @interface IAppLinkHostResponse
 */
export interface IBranchConfigHostResponseAppLink {
  id: string;
  textKey: string;
  displayName: string;
  category: string;
  displayOrder: number;
  url: string;
  iconColor: string;
  iconHeight: string;
  iconWidth: string;
  iconImage: string;
  external: boolean;
  sticky: boolean;
  functionId: string;
}
