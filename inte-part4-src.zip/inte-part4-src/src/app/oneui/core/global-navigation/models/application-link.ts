import {
    IApplicationLink,
    IApplicationLinkIconType,
    IBranchConfigHostResponseAppLink
} from './';

import { OneInterfaceService } from '@one-interface/one-interface.service';
import { SetEnumerable } from 'core/decorators';

export class ApplicationLink implements IApplicationLink {
    /**
 * Unique ID
 * 
 * @type {string}
 * @memberOf IApplication
 */
    id: string;

    /**
     * Category
     * 
     * @type {string}
     * @memberOf IApplication
     */
    category: string;

    /**
     * Order number as displayed on list
     * 
     * @type {number}
     * @memberOf IApplication
     */
    displayOrder: number;

    /**
     * Application Name
     * 
     * @type {string}
     * @memberOf IApplication
     */
    name: string;
    /**
     * Text to be displayed.
     * Ignored if textKey is used.
     * 
     * @type {string}
     * @memberOf IApplication
     */
    text?: string;

    /**
     * Language Database key to use.
     * Ignores text property if this is set.
     * 
     * @type {string}
     * @memberOf IApplication
     */
    textKey?: string;
    /**
     * 
     * 
     * @type {string}
     * @memberOf IApplication
     */
    url: string;
    /**
     * hostResponse target
     * 
     * @type {string}
     * @memberOf IApplication
     */
    isExternal?: boolean; // Optional: Defaults to self
    /**
     * Application Icon Type
     * 
     * @type {IApplicationIconType}
     * @memberOf IApplication
     */
    icon?: IApplicationLinkIconType;
    /**
     * Should app remain in native?
     * 
     * @type {boolean}
     * @memberof IApplication
     */
    isSticky?: boolean;

    /**
     * Function Identifier (2)
     * 
     * @type {string}
     * @memberof ApplicationLink
     */
    functionId: string;

    /**
     * Show on page
     * 
     * @type {boolean}
     * @memberof ApplicationLink
     */
    isShow: boolean = false;

    /**
     * True if user is authorized to use this link.
     * 
     * @type {boolean}
     * @memberof ApplicationLink
     */
    isAuthorized: boolean = false;

    /**
     * The translated display name.
     * This is sent to native wrapper and the native wrapper uses this text.
     * 
     * @type {string}
     * @memberof ApplicationLink
     */
    translatedName?: string;

    /**
     * OnClick handler
     */
    onClick?: Function;

    /**
     * The context to be used in translations.
     * 
     * @type {*}@memberof ApplicationLink
     */
    translateContext?: any = void 0;

    constructor(hostResponse: IBranchConfigHostResponseAppLink,
        ois: OneInterfaceService) {

        if (!!hostResponse === false)
            return;

        // Map Response
        this.id = "" + hostResponse.id;
        this.text = hostResponse["text"] || hostResponse.displayName;
        this.category = hostResponse.category;
        this.displayOrder = hostResponse.displayOrder;
        this.name = hostResponse.displayName;
        this.isExternal = hostResponse.external;
        this.isSticky = hostResponse.sticky || false;
        this.functionId = hostResponse.functionId;
        this.icon = {
            url: hostResponse.iconImage,
            color: hostResponse.iconColor,
            height: hostResponse.iconHeight,
            width: hostResponse.iconWidth
        };
    }

    /**
     * Constructs URL based on query params {param_<PARAM>}
     * Uses languageService to resolve();
     * 
     * @private
     * @param {string} rawUrl 
     * @returns {string} 
     * 
     * @memberof GlobalNavigationService
     */
    private constructUrl(rawUrl: string,
        ois: OneInterfaceService): string {
        // Extract all params:
        let regexp: RegExp = new RegExp(/\{param_(.*?)\}/ig);
        let found: RegExpExecArray = regexp.exec(rawUrl);
        let replacedUrl: string = rawUrl.replace(regexp, "\$\{$1\}");
        let context: any = {
            storeAU: ois.systemDeviceInformation.storeAU,
            storeau: ois.systemDeviceInformation.storeAU,
            computerName: ois.systemDeviceInformation.deviceId,
            computername: ois.systemDeviceInformation.deviceId,
            "storeAU:padFront=AU": `AU${ois.systemDeviceInformation.storeAU}`,
            state: ois.systemDeviceInformation.storeAuLocation.stateCode
        };
        return null;
    }
}