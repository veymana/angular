export interface ITeamMember {
    employeeId: string;
    teamMemberInfo: ITeamMemberInfo;
    language: ILanguage[];
    jobCode: string;
    functions: ITeamMemberFunctionType[];
    schedules: ISchedule[];
    emailAddress?: string;
    userId?: string;
    accountingUnit?: string;
    thumbnailPhoto?: any;
    thumbnailPhotoAvailable?: boolean;
    attributes?: { [key: string]: any };
}
export interface ITeamMemberInfo {
  firstName: string;
  middleInitial?: string;
  lastName: string;
}
export interface ITeamMemberFunctionType {
  functionId: string;
  functionType: string;
  functionIdentifier1: string;
  functionIdentifier2: string;
  functionIdentifier3: string;
  prescribedAuthorityValue: string;
  assignedAuthorityValue: string;
}
export interface ISchedule {
  start: string;
  finish: string;
}
export interface IAddress {
  lineList: string[];
  city: string;
  postalCode: string;
  zipCode: string
  stateCode: string;
  provinceCode: string;
  countryCode: string;
  countryName: string;
}

export interface IBankers {
  bankersFunctionsAndSchedule: ITeamMember[];
  address: IAddress;
}

export interface IJobCodeCustomerSegmentMap {
  jobCode: string;
  customerSegments: string[];
}










export interface IBasicInformation {
  firstName: string;
  middleInitial: string;
  lastName: string;
  preferredFirstName: string;
  preferredMiddleInitial: string;
  preferredLastName: string;
  emailAddress: string;
  jobCode: string;
  jobCodeDescription: string;
  jobCodeDescriptionPublic: string;
  payrollGLAU: string;
  macNumber: string;
  phoneNumber: string;
  corporateTitle: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  employeeStatus: string;
  hrStatus: string;
  lastChangeDate: string;
  displayName: string;
}

export interface IEntitlement {
  valid: boolean;
  entitlementId: string;
  entitlementDescription: string;
  entitlementIdentifier: string;
  entitlementEffectiveDate: string;
  entitlementExpirationDate: string;
  entitlementStatus: string;
  lastChangeDate: string;
}
export interface ILanguage {
  valid: boolean;
  languageId: string;
  languageDescription: string;
  lastChangeDate: string;
}

export interface ILocation {
  valid: boolean;
  outletId: string;
  outletMappingType: string;
  primaryFlag: string;
  outletGLAU: string;
  outletLocationNumber: string;
  outletCostCenter: string;
  lastChangeDate: string;
}

export interface IFunctionIdentifierType {
  functionIdentifier1: string;
  functionIdentifier2: string;
  functionIdentifier3: string;
  functionId: string;
}

export interface IFunctionAuthority {
  valid: boolean;
  functionId: string;
  functionType: string;
  ranking: string;
  prescribedAuthorityValue: string;
  PrescribedAuthorityFormat: string;
  assignedAuthorityValue: string;
  assignedAuthorityFormat: string;
  overrideTypeOverLimit: string;
  overrideTypeOverLimitAOC: string;
  overrideTypeWithinLimit: string;
  overrideTypeWithinLimitAOC: string;
  lastChangeDate: string;
}

export interface IFunction {
  valid: boolean;
  functionIdentifier: IFunctionIdentifierType;
  functionAuthorityList: IFunctionAuthority[];
}

export interface ITeamMemberInformationData {
  employeeId: string;
  basicInformation: IBasicInformation;
  entitlementList: IEntitlement[];
  languageList: ILanguage[];
  locationList: ILocation[];
  functionList: IFunction[];
}

export interface ITeamMemberServiceResponse {
  [key: string]: any;
  teamMemberInformationDataList: ITeamMemberInformationData[];
}

export interface IUserServerData {
  userSessionId: string;
  teamMemberLanId: string;
  teamMemberInformationResponse: ITeamMemberServiceResponse;
}
