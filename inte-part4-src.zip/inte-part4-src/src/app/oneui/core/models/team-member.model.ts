import { ITeamMember,ITeamMemberInfo,ITeamMemberFunctionType,ISchedule,ILanguage } from '.';

/**
 * TeamMember Model Class
 * 
 * @export
 * @class TeamMember
 * @implements {ITeamMember}
 */
export class TeamMember implements ITeamMember {     
   
    public employeeId: string;   
    public teamMemberInfo: ITeamMemberInfo;
    public language: ILanguage[];
    public jobCode: string;
    public functions: ITeamMemberFunctionType[];
    public schedules: ISchedule[];   
    public emailAddress: string;
    public userId: string;
    public accountingUnit: string;
    public thumbnailPhoto: any;
    public thumbnailPhotoAvailable: boolean;
    public attributes: { [key: string]: any }

    public constructor() {

    }
}