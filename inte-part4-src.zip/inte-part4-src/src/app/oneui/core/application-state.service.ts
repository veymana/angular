import { Injectable } from '@angular/core';
import { ApplicationState } from '#shared/application-state.model';

@Injectable()
export class ApplicationStateService {
  currentState: ApplicationState; 

  getCurrentState() {
    return this.currentState;
  }


}
