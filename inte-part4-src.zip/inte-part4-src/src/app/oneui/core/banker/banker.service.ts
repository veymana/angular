import { Injectable } from '@angular/core';
import { Subscription, Observable, BehaviorSubject, Subject } from 'rxjs/Rx';
import { AppSettings } from '#environments/environment';
import { Restclient } from 'core/restclient/restclient-base.service';
import { Http, XHRBackend, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { RestResource } from 'core/restclient/rest-resource'
import { RestclientBaseService } from 'core/restclient/restclient-base.service';
import { OneInterfaceService } from '@one-interface/one-interface.service';
import { ITeamMember, IJobCodeCustomerSegmentMap, ITeamMemberInfo, IBankers, IAddress } from '../models';
import { TeamMember } from '../models/team-member.model';

import { UtilsService } from 'core/utils.service';
import { IRestDetail } from '#environments/interfaces';
import { UserService } from 'core/services';

// DATA FILE
import * as jobcodemapping$json from '#compiled-data/jobcodemapping.json';

@Injectable()
export class BankerService {
  /**
   * Name of this service
   * 
   * @type {string}
   * @memberOf BankerService
   */
  public name: string = 'BankerService';
  private resourceAppSettingsKey: string = 'bankers';
  public readonly _jobCodeMappings$: any = jobcodemapping$json;
  public jobcodeCustomerSegmentMappings: IJobCodeCustomerSegmentMap[] = <[IJobCodeCustomerSegmentMap]>this._jobCodeMappings$;
  public bankers: ITeamMember[] = new Array<ITeamMember>();
  public address: IAddress;
  public readonly bankerSubject: BehaviorSubject<ITeamMember[]> = new BehaviorSubject<ITeamMember[]>(this.bankers);
  public readonly storeAddressSubject: BehaviorSubject<IAddress> = new BehaviorSubject<IAddress>(this.address);

  constructor(private ois: OneInterfaceService,
    private backend: XHRBackend,
    private userService: UserService) {
    // Initialize after user is authenticated
    userService.getUserObservable().subscribe(
      user => {
        if ((user != null) && (user.isAuthenticated)) {
          this.init();
        }
      },
      error => {
        console.log("QueueService: could not initialize: " + error);
      });
  }

  private init() {
    if (this.bankers === null || typeof (this.bankers) === "undefined" || this.bankers.length === 0) {
      this.getBankers();
    }
  }
  public get(): Observable<IBankers> {
    let params = new URLSearchParams();     // Construct query params
    params.set('storeAU', this.ois.systemDeviceInformation.storeAU);
    let ro: RequestOptions = new RequestOptions({ search: params });
    let rd: IRestDetail = UtilsService.getResourceDetail(this.resourceAppSettingsKey, ro);
    let rr: RestResource = new RestResource(rd);
    let rc: Restclient = new Restclient(this.ois, this.backend, rr);
    let obs: Observable<IBankers> = rc.get().map((res: Response) => res.json());
    return obs;
  }
  public getBankers(): void {
    let obsOfBankers: Observable<IBankers> = this.get();
    obsOfBankers.subscribe(
      //Fix for DR # 9832, sort bankers by firstname
      (bankers: IBankers) => {
        this.bankers = bankers.bankersFunctionsAndSchedule.sort((tm1, tm2) => {
          return tm1.teamMemberInfo.firstName < tm2.teamMemberInfo.firstName ? -1 : 1;
        });
        this.bankerSubject.next(bankers.bankersFunctionsAndSchedule);
        this.address = bankers.address;
        this.storeAddressSubject.next(bankers.address);
      },
      (err: any) => {
        console.warn('BankerService.getBankers error!', err);
      });
  }
}

