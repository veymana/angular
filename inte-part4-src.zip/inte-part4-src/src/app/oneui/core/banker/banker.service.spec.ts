/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { BankerService } from './banker.service';

describe('BankerService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [BankerService]
    });
  });

  it('should ...', inject([BankerService], (service: BankerService) => {
    expect(service).toBeTruthy();
  }));
});
