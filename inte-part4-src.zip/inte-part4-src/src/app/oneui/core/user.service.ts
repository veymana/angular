import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Subscription } from 'rxjs/Subscription';
import { User } from '#shared/user.model';
import { AppSettings } from '#environments/environment';
import { OneInterfaceService } from '@one-interface/one-interface.service';
import { UtilsService } from 'core/utils.service';
import { IRestDetail } from '#environments/interfaces';
import { IUserServerData } from 'core/models/interfaces';
import { Restclient, RestclientBaseService } from 'core/restclient/restclient-base.service';
import { Http, XHRBackend, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { TerminatesessionService } from 'core/restclient/terminate-session-restclient.service';

@Injectable()
export class UserService {

  public userSubject: BehaviorSubject<User> = new BehaviorSubject<User>(null);

  private _user: User = void 0;

  public get user(): User {
    return this._user;
  }

  public set user(user: User) {
    this._user = user;
    this.userSubject.next(user);
  }

  private resourceAppSettingsKey: string = 'user';
  private restClient: Restclient = void 0;

  constructor(
    private oneInterface: OneInterfaceService,
    private backend: XHRBackend,
    private terminatesessionService: TerminatesessionService) {
    let requestOptions: RequestOptions = new RequestOptions();
    requestOptions.search = new URLSearchParams();
    requestOptions.search.set("storeAU", this.oneInterface.systemDeviceInformation.storeAU);
    this.restClient = RestclientBaseService.create(oneInterface, backend, this.resourceAppSettingsKey, requestOptions);
  }


  /**
   * Makes the GET rest call and returns the User object
   * when the observable emits.
   * 
   * @returns {Observable<User>} 
   * 
   * @memberof UserService
   */
  login(): Observable<User> {
    let user: User = this._user || this.oneInterface.getUser();

    if (!!user && user.isAuthenticated) {
      return Observable.of(user);
    }

    user.isAuthenticated = true; //Set to true whenver login() is called, regardless of result.
    let obs: Observable<User> = this.restClient.get()
      .map((res: Response) => res.json())
      .map((serverData: IUserServerData) => {
        user.mapServerData(serverData);
        return user;
      }).share();

    obs.take(1).subscribe(
      (user: User) => {
        AppSettings.REST.commonHeaders["WF-User-Session-ID"] = user.userSessionId;
        console.info(`UserService. SessionID set to ${user.userSessionId}`);
        this.user = user;
      },
      (error: any) => {
        user.error = error;
        this.userSubject.error("error logging in");
      }
    );

    return obs;
  }

  logout(): void {
    this.terminatesessionService.terminate();
    this.user = null;
  }

  public getUserObservable(): Observable<User> {
    return this.userSubject.asObservable();
  }
}
