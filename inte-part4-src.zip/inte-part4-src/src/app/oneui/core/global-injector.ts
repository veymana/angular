import { Injector } from '@angular/core';
export class GlobalInjector {
    private static _INJECTOR: Injector = null;
    public static get INJECTOR(): Injector {
        return GlobalInjector._INJECTOR;
    }
    public static setInjector(i: any): void {
        GlobalInjector._INJECTOR = i;
    }

}
