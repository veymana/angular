import { Injectable, Injector } from '@angular/core';
import { LogTraceLevel } from 'core/restclient/applogger/log-trace-level';
import { AppLoggerModel } from 'core/restclient/applogger/app-logger-model';
import { ApploggerRestClientService } from 'core/restclient/applogger/applogger-restclient.service';
import { OneInterfaceService } from '@one-interface/one-interface.service';

/**
 * AppLogger Service
 * 
 * @export
 * @class AppLoggerService
 */
@Injectable()
export class AppLoggerService {

  /**
   * Service name
   * 
   * @private
   * @type {string}
   * @memberOf AppLoggerService
   */
  private readonly name: string = "AppLoggerService";
  private readonly ois: OneInterfaceService = void 0;
  public constructor(private _apploggerRestClientService: ApploggerRestClientService, injector: Injector) {
    this.ois = injector.get(OneInterfaceService);
  }

  /**
   * Logs to host
   * 
   * @param {string} message Message to log
   * @param {LogTraceLevel} messageLevel Level of message
   * 
   * @memberOf AppLoggerService
   */
  public log(message: string, messageLevel: LogTraceLevel): void {

    let logdata: AppLoggerModel = new AppLoggerModel(message, messageLevel, this.ois);
    let noop: () => any = () => { };
    let consoleLogFn: (...p: any[]) => any;

    // Detect proper console.* method
    switch (logdata.messageLevel) {
      case LogTraceLevel.trace:
      case LogTraceLevel.debug:
        consoleLogFn = (console && console.log) || noop;
        break;

      case LogTraceLevel.info:
        consoleLogFn = (console && console.info) || noop;
        break;

      case LogTraceLevel.warn:
        consoleLogFn = (console && console.warn) || noop;
        break;

      case LogTraceLevel.error:
      case LogTraceLevel.fatal:
        consoleLogFn = (console && console.error) || noop;
        break;

      default:
      case LogTraceLevel.default:
      case LogTraceLevel.all:
        consoleLogFn = (console && console.log) || noop;
        break;
    }

    // Also log to console.
    try {
      // consoleLogFn && consoleLogFn(`${this.name}.${messageLevel}: ${logdata.message}`);
    } catch (e) { }

    // Post to host.
    this._apploggerRestClientService.log(logdata);

  }

  /**
   * Log message to Host with ALL level
   * 
   * @param {any} message 
   * 
   * @memberOf AppLoggerService
   */
  public logAll(message): void {
    this.log(message, LogTraceLevel.all);
  }

  /**
   * Log message to Host with TRACE level
   * 
   * @param {any} message 
   * 
   * @memberOf AppLoggerService
   */
  public logTrace(message): void {
    this.log(message, LogTraceLevel.trace);
  }

  /**
   * Log message to Host with DEBUG level
   * 
   * @param {any} message 
   * 
   * @memberOf AppLoggerService
   */
  public logDebug(message): void {
    this.log(message, LogTraceLevel.debug);
  }

  /**
   * Log message to Host with INFO level
   * 
   * @param {any} message 
   * 
   * @memberOf AppLoggerService
   */
  public logInfo(message): void {
    this.log(message, LogTraceLevel.info);
  }

  /**
   * Log message to Host with WARN level
   * 
   * @param {any} message 
   * 
   * @memberOf AppLoggerService
   */
  public logWarn(message): void {
    this.log(message, LogTraceLevel.warn);
  }

  /**
   * Log message to Host with ERROR level
   * 
   * @param {any} message 
   * 
   * @memberOf AppLoggerService
   */
  public logError(message): void {
    this.log(message, LogTraceLevel.error);
  }

  /**
   * Log message to Host with FATAL level
   * 
   * @param {any} message 
   * 
   * @memberOf AppLoggerService
   */
  public logFatal(message): void {
    this.log(message, LogTraceLevel.fatal);
  }
}