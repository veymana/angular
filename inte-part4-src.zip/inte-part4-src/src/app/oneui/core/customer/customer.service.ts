import { Injectable, isDevMode } from '@angular/core';
import { Subscription, Observable, BehaviorSubject, Subject } from 'rxjs/Rx';
import { AppSettings } from '#environments/environment';
import { Restclient } from 'core/restclient/restclient-base.service';
import { Http, XHRBackend, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { RestResource } from 'core/restclient/rest-resource';
import { RestclientBaseService } from 'core/restclient/restclient-base.service';
import { OneInterfaceService } from '@one-interface/one-interface.service';
import { ICustomerSearch, ICustomer, ICustomers } from './models';
import { UtilsService } from 'core/utils.service';
import { IRestDetail } from '#environments/interfaces';

/**
 * CustomerService
 * Responsible for
 * - retrieving customer information from REST services.
 * - retrieving customer profile from REST services.
 * 
 * @export
 * @class QueueService
 */
@Injectable()
export class CustomerService {
  /**
   * Name of this service
   * 
   * @type {string}
   * @memberOf CustomerService
   */
  public name: string = 'CustomerService';

  /**
   * Resource name (Multi)
   * 
   * @private
   * @type {string}
   * @memberOf InteractionsRestclientService
   */
  private resourcenameMulti: string = 'customers';

  /**
   * Resource Name (Single)
   * 
   * @private
   * @type {string}
   * @memberOf CustomerService
   */
  private resourcenameSingle: string = 'customer';


  /**
   * Creates an instance of CustomerService.
   * @param {OneInterfaceService} ois 
   * @param {XHRBackend} backend 
   * @param {RequestOptions} defaultOptions 
   * 
   * @memberOf CustomerService
   */
  constructor(private ois: OneInterfaceService,
    private backend: XHRBackend) {
  }

  /**
   * Retrieves customer data
   * 
   * Pass either ICustomerSearch or params of data.
   * 
   * Notes: 
   * If card number is used. All other data is ignored for searching.
   * If searching with name, both firstname and lastname are required
   * 
   * Example usages:
   * 
   * @example
   * Using ICustomerSearch
   * let customersearch: ICustomerSearch = {
   *  firstName: 'Lucky',
   *  lastName: 'Mallari'
   * };
   * get(customersearch);
   * 
   * @example
   * Using object notation
   * get({
   *  firstName: 'Lucky',
   *  lastName: 'Mallari'
   * });
   * 
   * @example
   * Using plain params:
   * get('lucky', 'mallari');
   * 
   * @example
   * Using card number:
   * get({
   *  cardNumber: 12345
   * });
   * 
   * @example
   * Using card number through plain params
   * MUST BE type number. Otherwise it will be treated as firstname
   * get(12345);
   * 
   * 
   * @param {(number | string | ICustomerSearch)} firstNameOrCardNumberOrCustomerSearch Either firstName or cardNumber or an object of ICustomerSearch
   * @param {string} [lastName] Last name
   * @param {string} [dateOfBirth] Birth date
   * @param {string} [zipCode] Zip code
   * @returns {Observable<ICustomer>} 
   * 
   * @memberOf CustomerService
   */
  public get(firstNameOrCardNumberOrCustomerSearch: number | string | ICustomerSearch, lastName?: string, dateOfBirth?: string, zipCode?: string): Observable<ICustomers | ICustomer> {
    let searchCriteria: ICustomerSearch;
    let isPlainParamsValid: boolean = true;

    // Search using ICustomerSearch
    if (typeof (firstNameOrCardNumberOrCustomerSearch) !== "string" && typeof (firstNameOrCardNumberOrCustomerSearch) !== "number") {
      searchCriteria = firstNameOrCardNumberOrCustomerSearch;

      // ICustomerSearch has customerNumber:
      if (!!searchCriteria.customerNumber)
        return this.getByCustomerNumber(searchCriteria);

      // ICustomerSearch has accountNumber:
      if (!!searchCriteria.cardNumber === true)
        return this.getByCardNumber(searchCriteria);
    }
    // Search using Account Number
    else if (typeof (firstNameOrCardNumberOrCustomerSearch) === "number") {
      searchCriteria.cardNumber = firstNameOrCardNumberOrCustomerSearch;
      return this.getByCardNumber(searchCriteria);
    }
    // Search using plain parameters
    else {
      searchCriteria.firstName = firstNameOrCardNumberOrCustomerSearch || undefined;
      searchCriteria.lastName = lastName || undefined;
      searchCriteria.dateOfBirth = dateOfBirth || undefined;
      searchCriteria.zipCode = zipCode || undefined;

      // When using plain params,
      // both firstName and lastName are required.
      isPlainParamsValid = !!searchCriteria.firstName && !!searchCriteria.lastName;
      if (!isPlainParamsValid) {
        console.warn(`${this.name}.get() Error: invalid parameters. When using plain params, first and last names are both required.`, searchCriteria);
        return null;
      }
    }
    if (searchCriteria && searchCriteria.dateOfBirth){
      let dateOfBirth = new Date(searchCriteria.dateOfBirth);
      searchCriteria.dateOfBirth =  UtilsService.formatDate(dateOfBirth, "YYYYMMDD");
    }
    let params: URLSearchParams = RestclientBaseService.toUrlSearchParams(searchCriteria); // Construct query params
    let ro: RequestOptions = new RequestOptions({ search: params });

    let rd: IRestDetail = UtilsService.getResourceDetail(this.resourcenameMulti, ro);
    let rr: RestResource = new RestResource(rd);
    let rc: Restclient = new Restclient(this.ois, this.backend, rr);

    return rc.get()
      .map((res: Response) => res.json())
      .map((v: any) => v.data || v);
  }

  /**
   * Alise of get. @see {@link get}
   * 
   * @param {(number | string | ICustomerSearch)} firstNameOrAccountNumberOrCustomerSearch Either firstName or cardNumber or an object of ICustomerSearch
   * @param {string} [lastName] Last name
   * @param {string} [dateOfBirth] Birth date
   * @param {string} [zipCode] Zip code
   * @returns {Observable<ICustomer>} 
   * 
   * @memberOf CustomerService
   */
  public search(firstNameOrCardNumberOrCustomerSearch: number | string | ICustomerSearch, lastName?: string, dateOfBirth?: string, zipCode?: string): Observable<ICustomers> {
    return this.get(firstNameOrCardNumberOrCustomerSearch, lastName, dateOfBirth, zipCode);
  }

  /**
   * Searches based on card number.
   * 
   * @private
   * @param {ICustomerSearch} searchCriteria 
   * @returns {Observable<ICustomers>} 
   * 
   * @memberOf CustomerService
   */
  private getByCardNumber(searchCriteria: ICustomerSearch): Observable<ICustomers> {
    // When CardNumber is used. Use ONLY this for searching. And use POST!
    if (!!searchCriteria.cardNumber === true) {
      for (let key in searchCriteria) {
        if (key !== 'cardNumber')
          delete searchCriteria[key];
      }
    }

    let ro: RequestOptions = new RequestOptions({ body: searchCriteria });
    let rd: IRestDetail = UtilsService.getResourceDetail(this.resourcenameMulti, ro);
    let rr: RestResource = new RestResource(rd);
    let rc: Restclient = new Restclient(this.ois, this.backend, rr);

    return rc.post().map((res: Response) => res.json())
      .map((v: any) => v.data || v);
  }

  /**
   * Searches based on card number.
   * 
   * @private
   * @param {ICustomerSearch} searchCriteria 
   * @returns {Observable<ICustomers>} 
   * 
   * @memberOf CustomerService
   */
  private getByCustomerNumber(searchCriteria: ICustomerSearch): Observable<ICustomer> {
    // When CardNumber is used. Use ONLY this for searching. And use POST!
    if (!!searchCriteria.customerNumber === true) {
      for (let key in searchCriteria) {
        if (key !== 'customerNumber')
          delete searchCriteria[key];
      }
    }

    let ro: RequestOptions = new RequestOptions({ body: searchCriteria });
    let rd: IRestDetail = UtilsService.getResourceDetail(this.resourcenameSingle, ro);
    let rr: RestResource = new RestResource(rd);
    let rc: Restclient = new Restclient(this.ois, this.backend, rr);

    return rc.post().map((res: Response) => res.json())
      .map((v: any) => v.data || v);
  }

}
