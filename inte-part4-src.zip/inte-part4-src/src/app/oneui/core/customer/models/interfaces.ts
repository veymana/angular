/**
 * Customer Models - Interfaces
 */

export interface ICustomerSearch {
    cardNumber?: number;
    customerNumber?: number;
    firstName?: string;
    lastName?: string;
    dateOfBirth?: string;
    zipCode?: string;
}

