import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { UserService } from './user.service';
import { User } from '#shared/user.model';
import { AppSettings } from '#environments/environment';
import { UtilsService } from 'core/utils.service';

@Injectable()
export class AuthorizationService {
  constructor(private router: Router,
    private userService: UserService) {
  }

  /**
   * Returns true if user is authorized to use the application based on the applicationID that was passed.
   * Supports multi-user. Pass a user object to check against that user. Otherwise, logged in user is used.
   * 
   * @public
   * @param {string} applicationId 
   * @param {User} [user] 
   * @returns {boolean} 
   * 
   * @memberof AuthorizationService
   */
  public isAuthorizedForApplication(applicationId: string, user: User = null): boolean {
    user = user || this.userService.user;
    applicationId = (applicationId || "").toString().toUpperCase();
    if (!!applicationId === false)
      return false;

    // Some applications will have "_OPEN_" functionID.
    // True for "open" applications like TeamWorks, etc.
    // Always show/allow these items.
    if (applicationId === "_OPEN_")
      return true;
    return user.authorizedApplicationsOrPaths.findIndex((authorizedApp: string) => authorizedApp.toUpperCase() === applicationId) !== -1;
  }

  /**
   * Returns true if user is authorized to use THIS particular application, 
   * based on the APPID set in AppSettings.
   * 
   * Supports multi-user. Pass a user object to check against that user. Otherwise, logged in user is used.
   * 
   * @public
   * @returns {boolean} 
   * 
   * @memberof AuthorizationService
   */
  public isAuthorizedForThisApplication(user: User = null): boolean {
    user = user || this.userService.user;
    return this.isAuthorizedForApplication(AppSettings.APPID, user);
  }

  /**
   * Returns true if user (optional) is allowed for a specific path.
   * For example: isAuthorizedForPath("home")
   * 
   * @param {string} path 
   * @param {string} [appId=null] 
   * @param {User} [user=null] 
   * @returns 
   * 
   * @memberof AuthorizationService
   */
  public isAuthorizedForRoute(path: string, user: User = null): Observable<boolean> {
    user = user || this.userService.user;

    if (!!user === false || !!this.userService.user === false || this.userService.user.isAuthenticated === false) {
      this.router.navigate(['/login']);
      return Observable.of(false);
    }

    let pathMapping: string[] = AppSettings.UrlToFunctionIdentifier2Mapping[path] || null;
    if (!!pathMapping === false)
      return Observable.of(false);
    let intersectedArray: string[] = UtilsService.lodash.intersection(user.authorizedApplicationsOrPaths, pathMapping);
    return Observable.of(intersectedArray && intersectedArray.length > 0);
  }
}
