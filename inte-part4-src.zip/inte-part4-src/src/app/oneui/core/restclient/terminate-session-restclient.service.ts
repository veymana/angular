import { Injectable } from '@angular/core';
import { AppSettings } from '#environments/environment';
import { Restclient } from 'core/restclient/restclient-base.service';
import { RestResource } from 'core/restclient/rest-resource';
import { OneInterfaceService } from '@one-interface/one-interface.service';
import { Http, XHRBackend, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { UtilsService } from 'core/utils.service';
import { IActivityMonitorEvent } from 'core/one-interface/models/interfaces';
import { StartupService } from 'core/startup.service';
import { Router } from '@angular/router';

/**
 * Terminates the session.
 * 
 * @export
 * @class TerminatesessionService
 */
@Injectable()
export class TerminatesessionService {

  public readonly name: string = "TerminatesessionService";
  private rr: RestResource = new RestResource(UtilsService.getResourceDetail("terminateSession"));
  private rc: Restclient = new Restclient(this.ois, this.backend, this.rr);

  constructor(private ois: OneInterfaceService,
    private backend: XHRBackend,
    private startupService: StartupService,
    private router: Router) {

    this.ois.activityMonitor.activityChangedEvent.subscribe(
      (e: IActivityMonitorEvent) => this.onActivityChanged(e)
    );
  }

  /**
   * Terminates the session.
   * 
   * @param {boolean} [isForceClose=false] if true, browser is closed.
   * @param {boolean} [isRouteToDeadEnd=true] if true, routes to /deadend
   * @returns {Observable<any>} 
   * @memberof TerminatesessionService
   */
  public terminate(isForceClose: boolean = false, isRouteToDeadEnd: boolean = true): Observable<any> {
    console.info(`TerminatesessionService: Session to be terminated. Application Uptime was ${(+this.startupService.uptimeInMilliseconds / 1000)} seconds`);
    let postObservable: Observable<any> = this.rc.post();

    if (isRouteToDeadEnd) {
      this.router.navigate(['/deadend', { errorId: "LOGGEDOFF" }]);
    }

    if (!isForceClose)
      return postObservable;

    this.ois.browserManager.closeBrowser();
    return postObservable;
  }

  private onActivityChanged(payload: IActivityMonitorEvent): void {
    if (payload && payload.activity === "forceTerminateSession") {
      this.terminate().subscribe(
        (e: any) => { this.ois.browserManager.closeBrowser(); },
        (error: any) => { this.ois.browserManager.closeBrowser(); }
      );
    }
  }
}
