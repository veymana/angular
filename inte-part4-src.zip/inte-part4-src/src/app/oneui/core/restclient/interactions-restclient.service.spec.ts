/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { InteractionsRestclientService } from './interactions-restclient.service';

describe('InteractionsRestclientService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [InteractionsRestclientService]
    });
  });

  it('should ...', inject([InteractionsRestclientService], (service: InteractionsRestclientService) => {
    expect(service).toBeTruthy();
  }));
});
