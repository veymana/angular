import { RestclientBaseService } from './restclient-base.service';
import { IRestDetail } from '#environments/interfaces';
import { RequestOptionsArgs } from '@angular/http';
import { AppSettings } from '#environments/environment';


/*
 * RestResource
 * Main definition of a rest service object
 * 
 * @export
 * @class RestResource
 */
export class RestResource {
    public name: string = "";
    public resource: string;
    public endpoint: string;
    public requestOptions: RequestOptionsArgs;
    public isCacheToNative: boolean = false;
    public timeout: number;
    public isTickFirst: boolean = false;
    public retryCount: number = void 0;
    public get url(): string {
        return RestclientBaseService.createServiceUrl(this.resource, this.endpoint);
    }

    /**
     * Creates an instance of RestResource.
     * @param {(string | IRestDetail)} nameOrRestDetail Name of resource or a IRestDetail object itself.
     * @param {string} [_resource] resource string
     * @param {string} [_endpoint] enpoint string
     * @param {boolean} [isCacheToNative] Whether or not the data is cachable to the native wrapper.
     * @param {number} [timeout] Duration in ms in which the call will timeout
     * 
     * For example
     * @example for a service
     * http://www.example.com/version1/path/ServiceName
     * 
     * Endpoint is http://www.example.com/version1/path/
     * Resource is ServiceName
     * 
     * For local/relative to base url such as /ServiceName,
     * Endpoint is /
     * Resource is ServiceName
     * 
     * @memberOf RestResource
     */
    constructor(nameOrRestDetail: string | IRestDetail,
        _resource?: string, _endpoint?: string,
        isCacheToNative?: boolean,
        requestOptions?: RequestOptionsArgs,
        timeout?: number, isTickFirst?: boolean,
        retryCount?: number) {
        if (typeof (nameOrRestDetail) === "string") {
            this.isCacheToNative = isCacheToNative;
            this.name = name;
            this.requestOptions = requestOptions;
            this.resource = _resource;
            this.endpoint = _endpoint;

            if (typeof (timeout) === "number" && timeout > -1)
                this.timeout = timeout;

            if (typeof (retryCount) === "number" && retryCount > 0)
                this.retryCount = retryCount;

            if (typeof (isTickFirst) === "undefined") {
                this.isTickFirst = (AppSettings.REST.resource[nameOrRestDetail] && AppSettings.REST.resource[nameOrRestDetail].isTickFirst) || false;
            }
        }
        else {
            let nameOrRestDetailClone: any = Object.assign({}, nameOrRestDetail);
            this.isCacheToNative = nameOrRestDetailClone.isCacheToNative;
            this.name = nameOrRestDetailClone.name;
            this.resource = nameOrRestDetailClone.resource;
            this.endpoint = nameOrRestDetailClone.endPoint || AppSettings.REST.endPoints.default;

            this.requestOptions = nameOrRestDetailClone.requestOptions;

            if (typeof (nameOrRestDetailClone.timeout) === "number" && nameOrRestDetailClone.timeout > -1)
                this.timeout = nameOrRestDetailClone.timeout;

            this.isTickFirst = nameOrRestDetailClone.isTickFirst || false;
            this.retryCount = nameOrRestDetailClone.retryCount || 0;
        }
    }
}
