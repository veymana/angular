import { Injectable } from '@angular/core';
import { Restclient } from 'core/restclient/restclient-base.service';
import { RestResource } from 'core/restclient/rest-resource'
import { AppSettings } from '#environments/environment';
import { IInteraction, IInteractions, InteractionStatusTypeEnum } from 'app/oneui/queue/models';
import { Observable } from 'rxjs/Rx';
import { OneInterfaceService } from '@one-interface/one-interface.service';
import { XHRBackend, RequestOptions, Response, URLSearchParams, Headers } from '@angular/http';
import { Location } from '@angular/common';
import { UtilsService } from 'core/utils.service';
import { IRestDetail } from '#environments/interfaces';


/**
 * GETs/POSTs interactions to/from REST service.
 * 
 * @export
 * @class InteractionsRestclientService
 */
@Injectable()
export class InteractionsRestclientService {

  /**
   * Name of this service
   * 
   * @type {string}
   * @memberOf InteractionsRestclientService
   */
  public name: string = 'InteractionsRestclientService';

  /**
   * Resource name for retrieving a single interaction
   * 
   * @private
   * @type {string}
   * @memberOf InteractionsRestclientService
   */
  private resourcenameSingle: string = 'interaction';

  /**
   * Resource name for retrieving multiple interactions
   * 
   * @private
   * @type {string}
   * @memberOf InteractionsRestclientService
   */
  private resourcenameMulti: string = 'interactions';

  /**
   * Creates an instance of InteractionsRestclientService.
   * @param {OneInterfaceService} ois 
   * @param {XHRBackend} backend 
   * @param {RequestOptions} defaultOptions 
   * 
   * @memberOf InteractionsRestclientService
   */
  constructor(private ois: OneInterfaceService,
    private backend: XHRBackend) {
  }


  /**
   * Returns interactions from Rest Service.
   * If fromTimestamp is used, a list of interactions will be returned ranging from timestamp to current time.
   * If interactionId is used, only that interaction will be returned.
   * 
   * @param {(Date|string)} [timestampOrInteractionId] all interactions from this timestamp will be retrieved.
   * @param {InteractionStatusTypeEnum} [status] If this is used, only interactions with this status is returned
   * @returns {(Observable<IInteraction | IInteractions>)} 
   * 
   * @memberOf InteractionsRestclientService
   */
  public getInteraction(timestampOrInteractionId?: Date | string, status?: InteractionStatusTypeEnum): Observable<IInteraction | IInteractions> {
    if (typeof (timestampOrInteractionId) === "string")
      return this.getSingleInteraction(<string>timestampOrInteractionId);

    return this.getMultipleInteractions(<Date>timestampOrInteractionId, status);
  }

  /**
   * Alias of getInteraction
   * 
   * @param {(Date | string)} [timestampOrInteractionId] 
   * @param {InteractionStatusTypeEnum} [status] If this is used, only interactions with this status is returned
   * @returns {(Observable<IInteraction | IInteractions>)} 
   * 
   * @memberOf InteractionsRestclientService
   */
  public get(timestampOrInteractionId?: Date | string, status?: InteractionStatusTypeEnum): Observable<IInteraction | IInteractions> {
    return this.getInteraction(timestampOrInteractionId, status);
  }

  /**
   * Retrieves a single interaction from HOST Rest service based on interaction id
   * 
   * @private
   * @param {string} interactionId 
   * @returns {Observable<IInteraction>} 
   * 
   * @memberOf InteractionsRestclientService
   */
  private getSingleInteraction(interactionId: string): Observable<IInteraction> {
    if (!!interactionId === false)
      return Observable.throw(new Error(`${this.name}.getSingleInteraction: missing interaction id`));

    let rd: IRestDetail = UtilsService.getResourceDetail(this.resourcenameSingle);
    rd.resource = Location.joinWithSlash(rd.resource, interactionId);
    let rr: RestResource = new RestResource(rd);
    let rc: Restclient = new Restclient(this.ois, this.backend, rr);

    return rc.get().map((res: Response) => res.json());
  }

  /**
   * Retrieves multiple interactions from HOST Rest service based on FROM timestamp
   * 
   * @private
   * @param {Date} fromTimestamp 
   * @returns {Observable<IInteractions>} 
   * 
   * @memberOf InteractionsRestclientService
   */
  private getMultipleInteractions(fromTimestamp: Date, status?: InteractionStatusTypeEnum): Observable<IInteractions> {
    const dateFormat: string = "YYYY-MM-DD HH:mm:ss";

    if (!!fromTimestamp === false)
      return Observable.throw(new Error(`${this.name}.getMultipleInteractions: missing fromTimestamp`));

    let dateAsString = UtilsService.moment(fromTimestamp).format(dateFormat);
    let params = new URLSearchParams();     // Construct query params
    params.set('fromTimestamp', dateAsString);
    params.set('status', status || undefined);
    if (status.toUpperCase() === "ALL")
      params.set('status', undefined);
    let ro: RequestOptions = new RequestOptions({ search: params });
    let rd: IRestDetail = UtilsService.getResourceDetail(this.resourcenameMulti, ro);
    let rr: RestResource = new RestResource(rd);
    let rc: Restclient = new Restclient(this.ois, this.backend, rr);

    return rc.get().map((res: Response) => res.json());
  }

  /**
   * POSTs Interaction to Host.
   * 
   * @param {IInteraction} interaction 
   * @returns 
   * 
   * @memberOf InteractionsRestclientService
   */
  public postInteraction(interaction: IInteraction, isUpdate: boolean = false): Observable<IInteraction> {

    let ro: RequestOptions = new RequestOptions({ body: interaction });
    let rd: IRestDetail = UtilsService.getResourceDetail(this.resourcenameSingle, ro);
    if (isUpdate)
      rd.resource = Location.joinWithSlash(rd.resource, interaction.idAsString);
    let rr: RestResource = new RestResource(rd);
    let rc: Restclient = new Restclient(this.ois, this.backend, rr);

    return rc.post().map((res: Response) => res.json());
  }

  /**
   * Updates an interaction.
   * 
   * @param {IInteraction} interactionOrInteractionId Either an interaction object (IInteraction) or the interaction id
   * @returns {Observable<IInteraction>} 
   * 
   * @memberOf InteractionsRestclientService
   */
  public updateInteraction(interactionOrInteractionId: IInteraction): Observable<IInteraction> {
    return this.postInteraction(interactionOrInteractionId, true);
  }



}
