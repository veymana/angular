import { Injectable } from '@angular/core';
import { UtilsService } from 'core/utils.service';
import { Http, XHRBackend, } from '@angular/http';
import { AppSettings } from '#environments/environment';
import { Restclient } from 'core/restclient/restclient-base.service';
import { RestResource } from 'core/restclient/rest-resource';
import { OneInterfaceService } from '@one-interface/one-interface.service';
import { Observable } from 'rxjs';

@Injectable()
export class InactivitycheckRestclientService {

  public readonly name: string = "InactivityCheck";
  private rr: RestResource = new RestResource(UtilsService.getResourceDetail("inactivitycheck"));
  private rc: Restclient = new Restclient(this.ois, this.backend, this.rr);
  constructor(private ois: OneInterfaceService,
    private backend: XHRBackend) {
  }

  /**
   * Calls the rest service to revice session.
   * @returns {Observable<any>} 
   * 
   * @memberof InactivitycheckRestclientService
   */
  public tick(isReturnSuccessOnFail: boolean = false): Observable<any> {
    return this.rc.get();
  }

  /**
   * Calls tick, then the callback.
   * 
   * @template T 
   * @param {() => Observable<T>} callBack 
   * @returns {Observable<T>} 
   * 
   * @memberof InactivitycheckRestclientService
   */
  public tickThen<T>(callBack: () => Observable<T>): Observable<T> {
    return this.tick()
      .flatMap((_: any) => callBack());
  }
}
