import { RequestOptionsArgs, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { RestResource } from './rest-resource'

/**
 * RestClient interface
 * Every restclient class must adhere to this interface.
 * @export
 * @interface IRestclient
 */
export interface IRestclient {
    get?: (...params: any[]) => any;
    post?: (...params: any[]) => any;
    readonly name: string;
    readonly restResource: RestResource;
}
