/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { RestclientBaseService } from './restclient-base.service';

describe('RestclientBaseService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [RestclientBaseService]
    });
  });

  it('should ...', inject([RestclientBaseService], (service: RestclientBaseService) => {
    expect(service).toBeTruthy();
  }));
});
