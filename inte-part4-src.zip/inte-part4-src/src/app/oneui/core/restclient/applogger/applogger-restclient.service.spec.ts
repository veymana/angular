/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { ApploggerRestClientService } from './applogger-restclient.service';

describe('ApploggerRestClientService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ApploggerRestClientService]
    });
  });

  it('should ...', inject([ApploggerRestClientService], (service: ApploggerRestClientService) => {
    expect(service).toBeTruthy();
  }));
});
