/**
 * Defines LogTraceLevel
 * 
 * @export
 * @class LogTraceLevel
 */
export class LogTraceLevel {
  private constructor() { }
  public static default: string = "DEFAULT";
  public static all: string = "ALL";
  public static trace: string = "TRACE";
  public static debug: string = "DEBUG";
  public static info: string = "INFO";
  public static warn: string = "WARN";
  public static error: string = "ERROR";
  public static fatal: string = "FATAL";
}
