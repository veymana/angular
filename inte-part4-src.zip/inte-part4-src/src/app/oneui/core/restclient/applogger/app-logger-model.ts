import { LogTraceLevel } from 'core/restclient/applogger/log-trace-level';
import { OneInterfaceService } from '@one-interface/one-interface.service';
import { Inject } from "@angular/core";
import { AppSettings } from '#environments/environment';

/**
 * Object model for the logging.
 * This has to match the data contract with host.
 * Host expects in body:
 * message
 * messagelevel
 * 
 * @class AppLoggerModel
 */
export class AppLoggerModel {

  /**
   * Timestamp
   * 
   * @private
   * @type {Date}
   * @memberOf AppLoggerModel
   */
  private _timestamp: Date;

  /**
   * Creates an instance of AppLoggerModel.
   * @param {string} _rawMessage 
   * @param {LogTraceLevel} messageLevel 
   * 
   * @memberOf AppLoggerModel
   */
  constructor(private _rawMessage: string,
    public messageLevel: LogTraceLevel,
    private ois: OneInterfaceService) {
    this._timestamp = new Date();
  }

  /**
   * Returns the constructed message.
   * 
   * @readonly
   * @type {string}
   * @memberOf AppLoggerModel
   */
  public get message(): string {
    let deviceId: string = this.ois.systemDeviceInformation.deviceId;
    let isWrapped: boolean = this.ois.isWrapped;
    let storeAu: string = this.ois.systemDeviceInformation.storeAU;
    let appInfo: string = `${AppSettings.APP_NAME} v${AppSettings.VERSION}`;

    return `${this._timestamp.toISOString()} - App: ${appInfo}, Wrapped: ${isWrapped}, DeviceId: ${deviceId}, StoreAu: ${storeAu}, Msg: ${this._rawMessage}.`;
  }

}