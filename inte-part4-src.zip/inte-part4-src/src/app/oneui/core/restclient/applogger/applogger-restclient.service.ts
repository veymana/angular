import { Injectable } from '@angular/core';
import { RestclientBaseService } from '../restclient-base.service';
import { OneInterfaceService } from '@one-interface/one-interface.service';
import { Http, XHRBackend, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { IRestclient } from '../irestclient';
import { AppSettings } from '#environments/environment';
import { RestResource } from '../rest-resource'
import { Observable, Subscription } from 'rxjs/Rx';
import { UtilsService } from 'core/utils.service';
import { AppLoggerModel } from 'core/restclient/applogger/app-logger-model';

/**
 * RestClient interaction with Host.
 * 
 * @class ApploggerRestClientService
 * @extends {RestclientBaseService}
 * @implements {IRestclient}
 */
@Injectable()
export class ApploggerRestClientService extends RestclientBaseService implements IRestclient {

  public readonly name: string = "ApploggerRestClient";
  public restResource = new RestResource(AppSettings.REST.resource['appLogger']);

  /**
   * Creates an instance of ApploggerRestClientService.
   * @param {OneInterfaceService} _ois 
   * @param {XHRBackend} _backend 
   * @param {RequestOptions} _defaultOptions 
   * 
   * @memberOf ApploggerRestClientService
   */
  constructor(_ois: OneInterfaceService, _backend: XHRBackend) {
    super(_ois, _backend, ApploggerRestClientService.name);
    if (AppSettings.REST.resource["appLogger"])
      AppSettings.REST.resource["appLogger"].resolvedUrl = this.restResource.url;
  }

  /**
   * Posts to host the log message/data.
   * 
   * @private
   * @param {AppLoggerModel} logData 
   * @returns {void} 
   * 
   * @memberOf ApploggerRestClientService
   */
  public log(logData: AppLoggerModel): void {
    if (!!logData === false)
      return;

    // Refresh requestOptions
    this.restResource.requestOptions = new RequestOptions({
      body: {
        message: logData.message,
        messageLevel: logData.messageLevel
      }
    });

    let proxy = super.post.bind(this);
    let httpCallResult = proxy();

    if (httpCallResult instanceof Observable) {
      let subsription: Subscription =
        httpCallResult
          .take(1)
          .map((res: Response) => {
            let mappedJson: any = {};
            try {
              mappedJson = res.json();
            } catch (e) {
              mappedJson = { response: res.text() || "" };
            }
            return mappedJson;
          })
          .catch((err, caught) => this.onException(err, caught))
          .subscribe(
          res => this.onSuccess(res),
          error => this.onError(error),
          () => subsription.unsubscribe()
          );
    }

    return httpCallResult;
  }

  /**
   * onSuccess handler
   * 
   * @private
   * @param {*} payload 
   * 
   * @memberOf ApploggerRestClientService
   */
  private onSuccess(payload: any): void {
    console.log(`${this.name}.onSuccess: ${!!payload && UtilsService.stringifySafe(payload)}`);
  }


  /**
   * onError handler
   * 
   * @private
   * @param {*} data 
   * 
   * @memberOf ApploggerRestClientService
   */
  private onError(data: any): void {
    data = data || "Empty";
    console.error(`${this.name}.onError: ${UtilsService.stringifySafe(data)}`)
  }


  /**
   * OnException. Usually called when mapping fails.
   * 
   * @private
   * @param {(Response | any)} error 
   * @returns 
   * 
   * @memberOf ApploggerRestClientService
   */
  private onException(error: Response | any, caught: Observable<any>): Observable<any> {
    let errMsg: string;
    if (error instanceof Response) {
      const body: any = error.json() || error.text();
      const err = (body && body.error) || UtilsService.stringifySafe(body);
      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
    } else {
      errMsg = error.message ? error.message : error.toString();
    }
    console.error(console.log(`${this.name}.onException: ${errMsg}`));
    return Observable.of(error);
  }

}
