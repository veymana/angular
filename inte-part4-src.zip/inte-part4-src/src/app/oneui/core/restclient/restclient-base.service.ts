// Framework Modules:
import { Inject, Injectable, Optional, Injector } from '@angular/core';
import { Http, XHRBackend, RequestOptions, RequestOptionsArgs, Response, ResponseType, ResponseOptions, URLSearchParams, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Subscription } from 'rxjs/Subscription';
import { isDevMode } from '@angular/core';

import { AppSettings } from '#environments/environment';
import { OneInterfaceService } from '@one-interface/one-interface.service';

import { IRestclient } from './irestclient';
import { RestResource } from './rest-resource';
import { DataContext } from '@one-interface/models/data-context';
import { Location, PlatformLocation } from '@angular/common';

import { IRestDetail } from '#environments/interfaces';
import { InactivitycheckRestclientService } from 'core/restclient/inactivitycheck-restclient.service';
import { GlobalInjector } from 'core/global-injector';

//Helpers:
import { UtilsService } from 'core/utils.service';
import { AppLoggerService } from 'core/app-logger.service';
import { StartupService } from 'core/startup.service';
import { AppLoggerModel } from 'core/restclient/applogger/app-logger-model';
import { LogTraceLevel } from 'core/restclient/applogger/log-trace-level';

@Injectable()
export class RestclientBaseService extends Http implements IRestclient {

  /**
   * Name of this service
   * 
   * @type {string}
   * @memberof RestclientBaseService
   */
  public readonly name: string = "RestclientBaseService";

  /**
   * Base URL used for relative paths
   * 
   * @static
   * @type {string}
   * @memberof RestclientBaseService
   */
  public static base: string = (function (b: any): any {
    if (!!b === true)
      return b;
    let bases: NodeListOf<HTMLBaseElement> = document.getElementsByTagName('base');
    let baseHref: string = null;
    if (bases.length > 0) {
      if (bases[0].attributes.length > 0)
        baseHref = bases[0].attributes[0].value;
    }
    return Location.joinWithSlash(location.origin, baseHref);
  })(RestclientBaseService.base);

  private static isHeaderInitialized: boolean = false;

  private get inactivitycheckRestclientService(): InactivitycheckRestclientService {
    return (GlobalInjector && GlobalInjector.INJECTOR.get<InactivitycheckRestclientService>(InactivitycheckRestclientService)) || null;
  }

  /**
   * Creates an instance of RestclientBaseService.
   * @param {OneInterfaceService} _ois One Interface Provider Instance
   * @param {XHRBackend} _backend Backend 
   * @param {RequestOptions} _defaultOptions Defaut Options
   * @param {string} name Name of resource
   * @param {RestResource} [resource] Resource Object
   * 
   * @memberOf RestclientBaseService
   */
  constructor(
    @Inject(OneInterfaceService) private _ois: OneInterfaceService,
    @Inject(XHRBackend) _backend: XHRBackend,
    @Inject("RestclientBaseService") name?: string,
    @Optional() resource?: RestResource) {
    super(_backend, new RequestOptions());

    if (!!resource === true) {
      this.name = resource.name;
      this.restResource = resource;
    }
    else {
      if (typeof (name) === "string")
        this.name = name;
    }

    if (RestclientBaseService.isHeaderInitialized === false) {
      AppSettings.REST.commonHeaders["WF-Initiator-ID"] = AppSettings.REST.commonHeaders["WF-Initiator-ID"] || this._ois.systemDeviceInformation.deviceId;
      AppSettings.REST.commonHeaders["WF-Message-ID"] = UtilsService.createGuid();
      if (isDevMode())
        console.info(`${this.name}: Initialized. CommonHeaders:`, AppSettings.REST.commonHeaders);

      RestclientBaseService.isHeaderInitialized = true;
    }
  }

  /**
   * RestResource object
   * 
   * @private
   * @type {RestResource}
   * @memberOf RestclientBaseService
   */
  public readonly restResource: RestResource = null;

  /**
   * Creates the service url.
   * 
   * @param {string} endpoint This is the path to the service
   * @param {string} resource The actual service name
   * @param {string} site 
   * @returns {string} 
   * 
   * For example
   * @example  For a service
   * http://www.example.com/version1/path/ServiceName
   * 
   * Endpoint is http://www.example.com/version1/path/
   * Resource is ServiceName
   * 
   * For local/relative to base url such as /ServiceName,
   * Endpoint is /
   * Resource is ServiceName
   * 
   * @memberOf RestclientBaseService
   */
  public static createServiceUrl(resource: string, endpoint: string, site?: string): string {
    let retVal: any;
    /* OPTIONS */
    let isLowercaseSite: boolean = false;

    // User param or default to main.
    endpoint = endpoint || AppSettings.REST.endPoints['main'] || '';

    if (!!endpoint === false && !!resource === false) {
      let errorString: string = `${this.name}: createServiceUrl: Unable to create service url for endpoint:'${endpoint}', resource:'${resource}', site:'${site}'`;
      console.error(errorString);
      throw new Error(errorString);
    }

    //Check to see if endpoint starts with "http" (also covers https).
    //if so, use this endpoint. Otherwise, use relative path, based on origin/port.
    let find: string = "http";
    if (endpoint.indexOf(find) !== 0) {
      if (endpoint.toString().toLowerCase() === "[[relative]]")
        endpoint = this.base;
      else
        endpoint = Location.joinWithSlash(this.base, endpoint);
    }

    // Remove trailing slashes
    endpoint = endpoint && Location.stripTrailingSlash(endpoint);
    resource = resource && Location.stripTrailingSlash(resource);
    site = site && Location.stripTrailingSlash(site);

    if (!!site) {
      if (isLowercaseSite) {
        site = site.toLowerCase();
      }
      retVal = Location.joinWithSlash(Location.joinWithSlash(endpoint, site), resource);
    }
    else {
      retVal = Location.joinWithSlash(endpoint, resource);
    }
    return retVal;
  }

  /****************************************************
   **  Overloaded methods of Http 
   ****************************************************/

  /**
   * Performs a GET request
   * 
   * @returns {Observable<Response>} 
   * 
   * @memberOf RestclientBaseService
   */
  public get(...params: any[]): Observable<any> {
    // NOTE: "this" is not the "this" of this class, but the "this" as the result of bind()/apply()
    // "this" is "curried" from derived classes to preserve abstraction.
    let restRsrc: RestResource = this.restResource;

    // In case the caller uses http.post, these will be called:
    if (!!restRsrc === false) {
      let rs: any = UtilsService.getRestResource(params[0]);
      restRsrc = new RestResource(
        params[0],
        rs.resource,
        rs.endPoint,
        false
      );
      restRsrc.requestOptions = params[1];
    }

    // Time when call was started
    let callStarted: Date = new Date();

    // Check to see if we need to query native wrapper to get cached data.
    if (this._ois.isWrapped && restRsrc.isCacheToNative) {
      let cachedData: DataContext = this._ois.contextManager.get(restRsrc.name, true);

      if ((!!cachedData === false || !!cachedData.error === true) === false) {
        let response: any = cachedData.data || cachedData;
        // Cache found. Return this instead.
        console.log(`${this.name}: Request [GET] was retrieved from CACHE: ${UtilsService.stringifySafe(response)}`);
        let result: Observable<Response> =
          Observable.from(
            [
              new Response(new ResponseOptions(
                {
                  body: response,
                  status: 200,
                  statusText: "Success",
                  type: ResponseType.Default,
                  url: restRsrc.url
                }
              ))
            ]);

        // Construct the default handlers:
        let defaultObserver: Subscription =
          result.subscribe(
            (res: Response) => { this.always_onNext(res, callStarted); },
            (error: any) => { this.always_onError(error, callStarted); },
            () => { this.always_onComplete(defaultObserver); }
          );

        // Return the observable created
        return result;
      }
    }

    restRsrc.requestOptions = this.constructRequestOptions(restRsrc.requestOptions || new RequestOptions());

    console.log(`${this.name}: Rest request [GET]: ${restRsrc.url}`, restRsrc);

    // Actual HttpModule.get
    let result: Observable<Response> = super.get(restRsrc.url, restRsrc.requestOptions)
      .timeout(restRsrc.timeout || AppSettings.REST.defaultTimeout) // If restRsrc has timeout, use it. Otherwise, use default
      .share();

    // Subscribe so we can add to cache
    if (this._ois.isWrapped && restRsrc.isCacheToNative) {
      let getSub: Subscription = result
        .map((res: Response) => res.json())
        .subscribe((data: any) => {
          data = UtilsService.stringifySafe(data.body || data || "");
          console.log(`${this.name}: Request [GET] published to CACHE: ${data}`);
          this._ois.contextManager.publish(new DataContext(restRsrc.name, data));
          getSub.unsubscribe();
        });
    }

    // Construct the default handlers:
    let defaultObserver: Subscription =
      result.subscribe(
        (res: Response) => { this.always_onNext(res, callStarted); },
        (error: any) => { this.always_onError(error, callStarted, restRsrc); },
        () => { this.always_onComplete(defaultObserver); }
      );

    // Return the observable created
    return result;
  }

  /**
   * Performs a POST request
   * 
   * @param {string} url 
   * @param {*} body 
   * @param {RequestOptionsArgs} [requestOptions] 
   * @returns {Observable<Response>} 
   * 
   * @memberOf RestclientBaseService
   */
  public post(...params: any[]): Observable<any> {
    // NOTE: "this" is not the "this" of this class, but the "this" as the result of bind()/apply()
    // "this" is "curried" from derived classes to preserve abstraction.
    let restRsrc: RestResource = this.restResource;

    // In case the caller uses http.post, these will be called:
    if (!!restRsrc === false) {
      let rs: any = UtilsService.getRestResource(params[0]);
      restRsrc = new RestResource(
        params[0],
        rs.resource,
        rs.endPoint,
        false
      );
      restRsrc.requestOptions = params[2];
    }

    // Time when call was started
    let callStarted: Date = new Date();

    restRsrc.requestOptions = this.constructRequestOptions(restRsrc.requestOptions || new RequestOptions());

    console.log(`${this.name}: Request [POST]: ${restRsrc.url}`, restRsrc);

    let ticker: Observable<boolean> = restRsrc.isTickFirst
      ? ((this.inactivitycheckRestclientService && this.inactivitycheckRestclientService.tick()) || Observable.of(true))
      : Observable.of(true);

    // Actual HttpModule.post
    let result: Observable<any> = ticker
      .flatMap((_: any) => super.post(restRsrc.url, null, restRsrc.requestOptions).retry(restRsrc.retryCount || 0))
      .timeout(restRsrc.timeout || AppSettings.REST.defaultTimeout) // If restRsrc has timeout, use it. Otherwise, use default
      .share();

    // Construct the default handlers:
    let defaultObserver: Subscription =
      result.subscribe(
        (res: Response) => { this.always_onNext(res, callStarted); },
        (error: any) => { this.always_onError(error, callStarted, restRsrc); },
        () => { this.always_onComplete(defaultObserver); }
      );


    return result;
  }

  /**
   * Creates request options by using defaults.
   * Parameter passed will override default.
   * 
   * @private
   * @param {RequestOptionsArgs} [requestOptions] 
   * @returns 
   * 
   * @memberOf RestclientBaseService
   */
  private constructRequestOptions(requestOptionsArgs?: RequestOptionsArgs): RequestOptions {
    AppSettings.REST.commonHeaders["WF-User-Session-ID"] = AppSettings.REST.commonHeaders["WF-User-Session-ID"] || undefined;
    AppSettings.REST.commonHeaders["WF-Session-ID"] = AppSettings.REST.commonHeaders["WF-User-Session-ID"] || undefined;
    // Create copy:
    requestOptionsArgs = new RequestOptions(Object.assign({}, requestOptionsArgs));
    if (!!requestOptionsArgs.headers === false) {
      requestOptionsArgs.headers = new Headers(AppSettings.REST.commonHeaders);
    }
    else {
      for (let key of Object.keys(AppSettings.REST.commonHeaders)) {
        if (typeof (AppSettings.REST.commonHeaders[key]) !== "undefined" && AppSettings.REST.commonHeaders[key] !== null)
          requestOptionsArgs.headers.set(key, AppSettings.REST.commonHeaders[key]);
      }
    }

    requestOptionsArgs.headers.set('If-Modified-Since', 'Wed, 28 Mar 1984 05:00:00 GMT');
    requestOptionsArgs.headers.set('Cache-Control', 'no-cache');
    requestOptionsArgs.headers.set('Pragma', 'no-cache');

    let retVal: RequestOptions = new RequestOptions(requestOptionsArgs);
    return retVal;
  }


  /**
   * This is ALWAYS called on GET/POST observable's onNext, on top of the other subscribers.
   * This way we can act (such as logging) on the observable even when there are no observers.
   * 
   * @private
   * 
   * @memberOf RestclientBaseService
   */
  private always_onNext(data: any | Response, callStarted: Date): void {
    let duration: number = +(new Date()) - +(callStarted);
    let durationString: string = `${duration} ms.`;
    if (duration >= 1000)
      durationString = `${duration / 1000} seconds.`;

    if (isDevMode())
      console.log(`${this.name}.always_onNext(). (raw) [${durationString}]}`, data);
  }

  /**
   * This is ALWAYS called on GET/POST observable's onError, on top of the other subscribers.
   * This way we can act (such as logging) on the observable even when there are no observers.
   * 
   * @private
   * 
   * @memberOf RestclientBaseService
   */
  private always_onError(error: any | Response, callStarted: Date, originalRestRsrc?: RestResource): void {

    // Always IGNORE tabletlog to avoid loops:
    if (this.restResource.name === "AppLogger" || (originalRestRsrc && originalRestRsrc.name) === "AppLogger") {
      return;
    }



    let duration: number = +(new Date()) - +(callStarted);
    let durationString: string = `${duration} ms.`;
    if (duration >= 1000)
      durationString = `${duration / 1000} seconds.`;

    if (isDevMode())
      console.log(`${this.name}.always_onError(). (raw) [${durationString}]`, error);

    // On error, attempt to POST using vanilla Javascript so that the request is outside of angular domain
    // and should function independently of our angular services.
    let vanillaUrl: string = AppSettings.REST.resource["appLogger"] && AppSettings.REST.resource["appLogger"].resolvedUrl;
    if (!!vanillaUrl) {
      try {
        let headers: any = originalRestRsrc && originalRestRsrc.requestOptions && originalRestRsrc.requestOptions.headers;
        let msg: AppLoggerModel = new AppLoggerModel(error.toString(), LogTraceLevel.error, this._ois);
        UtilsService.vanillaXhr.post(vanillaUrl, {
          "message": msg.message,
          "messageLevel": msg.messageLevel
        }, headers || null);
      } catch (e) {
        // ignored
        // Never let the error handling throw errors :)
      }
    }
  }

  /**
   * This is ALWAYS called on GET/POST observable's onComplete, on top of the other subscribers.
   * This way we can act (such as logging) on the observable even when there are no observers.
   * 
   * @private
   * 
   * @memberOf RestclientBaseService
   */
  private always_onComplete(defaultObserver?: Subscription): void {
    if (!!defaultObserver === true && defaultObserver.closed === false)
      defaultObserver.unsubscribe();
  }

  /**
   * Converts an object to URLSearchParams object.
   * 
   * @static
   * @param {Object} o 
   * @returns {URLSearchParams} 
   * 
   * @memberOf RestclientBaseService
   */
  public static toUrlSearchParams(o: Object): URLSearchParams {
    let retVal: URLSearchParams = new URLSearchParams();
    if (typeof (o) !== "object") {
      return retVal;
    }

    for (let key in o) {
      retVal.set(key, o[key]);
    }

    return retVal;
  }

  /**
   * Creates a new RestClient
   * 
   * @static
   * @param {OneInterfaceService} ois 
   * @param {XHRBackend} backend 
   * @param {string} resourceName 
   * @param {(RequestOptions | { method?, headers?, body?, url?, search?, params?, withCredentials?, responseType?})} requestOptions 
   * @returns {Restclient} 
   * 
   * @memberof RestclientBaseService
   */
  public static create(
    ois: OneInterfaceService,
    backend: XHRBackend,
    // tslint:disable-next-line:typedef
    resourceName: string, requestOptions?: RequestOptions | { method?, headers?, body?, url?, search?, params?, withCredentials?, responseType?}): Restclient {
    let ro: RequestOptions = new RequestOptions(requestOptions);
    let rd: IRestDetail = UtilsService.getResourceDetail(resourceName, ro);
    let rr: RestResource = new RestResource(rd);
    return new Restclient(ois, backend, rr);
  }
}

// Alias
export class Restclient extends RestclientBaseService {
  constructor(_ois: OneInterfaceService, _backend: XHRBackend, resource: RestResource) {
    super(_ois, _backend, resource.name, resource);
  }
}