import { NgModule, Optional, SkipSelf } from '@angular/core';
import { Router } from '@angular/router';
import { ApplicationStateService } from './application-state.service';
import { AuthorizationService } from './authorization.service';
import { AuthorizationGuardsAndResolves } from './authorization-guards-and-resolves.service';
import { UserService } from './user.service';
import { SessionService } from './session.service';
import { OneInterfaceService } from '@one-interface/one-interface.service';
import { WindowRefService } from './window-ref.service';
import { UtilsService } from 'core/utils.service';
import { ErrorSinkService } from 'core/error-sink.service';
import { ErrorHandler } from '@angular/core';
import { AppLoggerService } from 'core/app-logger.service';
import { Http, XHRBackend, RequestOptions } from '@angular/http';

import { RouterEventsService } from './router-events.service';
import { InactivityService } from 'core/inactivity.service';
import { ConnectivityService } from 'core/connectivity.service';
import { CustomerService } from 'core/customer/customer.service';
import { HeaderService } from 'core/header/header.service';
import { GlobalNavigationService } from 'core/global-navigation/global-navigation.service';
import { FlowService, FLOW_SERVICE_PRIMARY_TOKEN } from 'core/flow/flow.service';
import { BankerService } from 'core/banker/banker.service';

import { RouterOutletService } from './router-outlet/router-outlet.service';
import { BrowserService } from 'core/services';
import { DeviceManagementService } from 'core/dms/device-management.service';

// RestClients
import { ApploggerRestClientService } from 'core/restclient/applogger/applogger-restclient.service';
import { InteractionsRestclientService } from 'core/restclient/interactions-restclient.service';
import { RouterOutletExDirective } from './router-outlet/router-outlet-ex.directive';
import { TerminatesessionService } from 'core/restclient/terminate-session-restclient.service';
import { InactivitycheckRestclientService } from 'core/restclient/inactivitycheck-restclient.service';

@NgModule({
  providers: [
    { provide: ErrorHandler, useClass: ErrorSinkService },
    { provide: FLOW_SERVICE_PRIMARY_TOKEN, useValue: FLOW_SERVICE_PRIMARY_TOKEN },
    OneInterfaceService,
    WindowRefService,
    ApplicationStateService,
    AuthorizationService,
    AuthorizationGuardsAndResolves,
    UserService,
    SessionService,
    UtilsService,
    AppLoggerService,
    InactivityService,
    RouterEventsService,
    CustomerService,
    HeaderService,
    GlobalNavigationService,
    FlowService,
    BankerService,
    RouterOutletService,
    BrowserService,
    DeviceManagementService,

    // Rest Clients
    ConnectivityService,
    ApploggerRestClientService,
    InteractionsRestclientService,
    TerminatesessionService,
    InactivitycheckRestclientService
  ],
  declarations: [RouterOutletExDirective],
  exports: [RouterOutletExDirective]
})
export class CoreModule {
  constructor( @Optional() @SkipSelf() coreModule: CoreModule,
    browserService: BrowserService) {
    if (coreModule) {
      throw new Error("Core module must be imported in App/Main Module only");
    }
  }
}