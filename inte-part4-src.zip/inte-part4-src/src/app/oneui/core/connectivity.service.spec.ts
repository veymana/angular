/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { ConnectivityService } from './connectivity.service';

describe('ConnectivityService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ConnectivityService]
    });
  });

  it('should ...', inject([ConnectivityService], (service: ConnectivityService) => {
    expect(service).toBeTruthy();
  }));
});
