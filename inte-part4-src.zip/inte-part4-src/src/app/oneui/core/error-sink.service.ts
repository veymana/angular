import { Injectable, ErrorHandler } from '@angular/core';
import { AppSettings } from '#environments/environment';
import { AppLoggerService } from 'core/app-logger.service';
import { LogTraceLevel } from 'core/restclient/applogger/log-trace-level';

/**
 * ErrorSinkService is a global sink for all errors.
 * All errors are caught here so that we can act on the error such as logging.
 * All errors MUST be rethrown so that calling code can handle them gracefully.
 * 
 * @export
 * @class ErrorSinkService
 */
@Injectable()
export class ErrorSinkService implements ErrorHandler {

  public NAME: string = "ErrorSinkService";

  /**
   * Creates an instance of ErrorSinkService.
   * 
   * @memberOf ErrorSinkService
   */
  constructor(private _appLoggerService: AppLoggerService) { }

  /**
   * Implementation of Errorhandler.handleError interface
   * 
   * @param {*} error 
   * 
   * @memberOf ErrorSinkService
   */
  handleError(error: any) {
    this.logToHost(error);

    // Rethrow based on settings
    // if (AppSettings.ErrorSinkConfig.rethrowError)
    //throw new Error(error); //FIXME
  }


  /**
   * Logs message to host.
   * 
   * @private
   * @param {*} error 
   * 
   * @memberOf ErrorSinkService
   */
  private logToHost(error: any): void {
    this._appLoggerService.log(this.createMessageForLogging(error), LogTraceLevel.error);
  }

  /**
   * Creates message for logging.
   * 
   * @private
   * @param {*} error 
   * @returns {string} 
   * 
   * @memberOf ErrorSinkService
   */
  private createMessageForLogging(error: any): string {
    error = (error && error.originalError) || error || {};
    let summary: string = error.message || "";
    let stacktrace: string = error.stack || error.originalStack || error.zoneAwareStack || error.stack || "Stack not available";
    let stacktracestring: string = stacktrace
      .split('\n')
      .slice(0, AppSettings.ErrorSinkConfig.stacktraceMaxLines)// To minimize traffic, only use first AppSettings.ErrorSinkConfig.stacktraceMaxLines lines of stack trace.
      .join("\r\n");

    return `Uncaught Error: [${summary}.]\nStack: [${stacktracestring}]`;
  }
}
