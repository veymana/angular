/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { RouterEventsService } from './router-events.service';

describe('RouterEventsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [RouterEventsService]
    });
  });

  it('should ...', inject([RouterEventsService], (service: RouterEventsService) => {
    expect(service).toBeTruthy();
  }));
});
