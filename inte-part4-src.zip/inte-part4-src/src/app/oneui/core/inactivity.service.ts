import { Injectable } from '@angular/core';
import { AppSettings } from '#environments/environment';
import { Observable, Subscription, Subscriber, Notification, Observer, Subject } from 'rxjs/Rx';
import { isDevMode } from '@angular/core';

/**
 * Inactivity Service tracks user idle time
 * 
 * @export
 * @class InactivityService
 */
@Injectable()
export class InactivityService {

  /**
   * Service name
   * 
   * @private
   * 
   * @memberOf InactivityService
   */
  // tslint:disable-next-line:typedef
  private readonly NAME = 'InactivityService';

  /**
   * Timeout Duration in seconds
   * Defaults to 900 (15 minutes) if not defined in AppSettings
   * 
   * @private
   * 
   * @memberOf InactivityService
   */
  private readonly timeoutDurationInSeconds: number = AppSettings.INACTIVITY.timeoutInSeconds || 900;

  /**
   * Warning Duration in seconds
   * Defaults to 30 seconds if not defined in AppSettings
   * 
   * @private
   * 
   * @memberOf InactivityService
   */
  private readonly secondsUntilLoggedOff: number = AppSettings.INACTIVITY.warningInSeconds || 30;

  /**
   * This is the interval in which this service will log (in console) the time remaining before warning is shown.
   * 
   * @private
   * @type {number}
   * @memberOf InactivityService
   */
  private readonly _logEveryXinSeconds: number = 3;

  /**
   * Duration until warning popup is shown to customer.
   * 
   * @private
   * @type {number}
   * @memberOf InactivityService
   */
  private readonly secondsUntilWarningIsShown: number = (this.timeoutDurationInSeconds - this.secondsUntilLoggedOff);

  /**
   * Keys to ignore
   * 
   * @private
   * @type {string[]}
   * @memberOf InactivityService
   */
  private readonly ignoredKeys: any[] = AppSettings.INACTIVITY.ignoredKeys || [];

  /**
   * events to watch
   * 
   * @private
   * @type {string[]}
   * @memberOf InactivityService
   */
  private readonly eventsToMonitor: string[] = AppSettings.INACTIVITY.eventsToMonitor || ['keydown', 'mousedown'];

  /**
   * Main timer
   * 
   * @type {Observable<number>}
   * @memberOf InactivityService
   */
  private mainCountdownObservable: Observable<number> = Observable.interval(1000).take(this.secondsUntilWarningIsShown);

  /**
   * Timer to show warning
   * 
   * @type {Observable<number>}
   * @memberOf InactivityService
   */
  private warningCountdownObservable: Observable<number> = Observable.interval(1000).take(this.secondsUntilWarningIsShown);


  /**
   * Timer to logoff user
   * 
   * @type {Observable<number>}
   * @memberOf InactivityService
   */
  private logoffCountdownObservable: Observable<number> = Observable.interval(1000).take(this.secondsUntilLoggedOff);

  /**
   * The subscription to warning timer
   * 
   * @type {Subscription}
   * @memberOf InactivityService
   */
  private warningCountdownObserver: Subscription = null;

  /**
   * The subscription to logoff timer
   * 
   * @type {Subscription}
   * @memberOf InactivityService
   */
  private logoffCountdownObserver: Subscription = null;

  /**
   * onWarning event subject.
   * when used asObvervable(), will emit an event upon warning
   * Emitted value is the Date object when the event occurred.
   * 
   * @type {Subject<Date>}
   * @memberOf InactivityService
   */
  public readonly onWarningEvent: Subject<Date> = new Subject<Date>();

  /**
   * onLoggedOffEvent event subject.
   * when used asObvervable(), will emit an event upon logoff.
   * Emitted value is the Date object when the event occurred.
   * 
   * @type {Subject<any>}
   * @memberOf InactivityService
   */
  public onLoggedOffEvent: Subject<Date> = new Subject<Date>();

  /**
   * onActivityEvent event subject.
   * when used asObvervable(), will emit an event upon any UI Activity.
   * Emitted value is the Date object when the event occurred.
   * 
   * @private
   * @type {Subject<Date>}
   * @memberof InactivityService
   */
  public readonly onActivityEvent: Subject<Date> = new Subject<Date>();

  /**
   * constructor
   * 
   * @memberOf InactivityService
   */
  constructor() {
    this.init();
  }

  /**
   * Initialize timers and subscriptions.
   * 
   * @private
   * 
   * @memberOf InactivityService
   */
  private init(): void {
    // Create an collectin of observables based on the events that need monitoring.
    let obsCollection: Observable<any>[] = [];
    for (let eventName of AppSettings.INACTIVITY.eventsToMonitor) {
      // Create an observable for each eventsToMonitor
      let newObservable: Observable<any> = Observable
        .fromEvent(document, eventName)
        .map((event$: any) => { return event$; });

      //Add to our array
      obsCollection.push(newObservable);
    }

    // Merge all Observables:
    let mergedUIEventObservables: Observable<any> = Observable.merge(...obsCollection);

    // Map our data:
    mergedUIEventObservables = mergedUIEventObservables.map((event$: KeyboardEvent | MouseEvent | TouchEvent) => { return event$; });

    // Filter based on ignored keys (only for keyboard events)
    mergedUIEventObservables = mergedUIEventObservables.filter((event$: any) => { return this.filter(event$); });

    // Subscribe!
    mergedUIEventObservables.subscribe((event$: KeyboardEvent | MouseEvent | TouchEvent) => this.onUIEvent(event$));

    // Start Warning Timers
    this.resetWarningCountdownObservable();
    this.resetSubscription();

  }

  /**
   * Reset subscription
   * 
   * @private
   * 
   * @memberOf InactivityService
   */
  private resetSubscription(): void {

    if (this.logoffCountdownObserver && this.logoffCountdownObserver.closed === false)
      this.logoffCountdownObserver.unsubscribe();

    if (this.warningCountdownObserver && this.warningCountdownObserver.closed === false)
      this.warningCountdownObserver.unsubscribe();

    // Emit an event that an activity was found.
    this.onActivityEvent.next(new Date());

    this.warningCountdownObserver = this.warningCountdownObservable.subscribe(
      //onNext
      (remaining: number) => {
        let remainder: number = this.secondsUntilWarningIsShown - remaining;
        if (isDevMode() && AppSettings.INACTIVITY.isLogRemainderToConsole && (remainder % this._logEveryXinSeconds === 0))
          console.log(`${this.NAME}: Time Remaining until warning: ${remainder}`);
      },

      //onError (just map)
      (error: any) => error,

      //onComplete
      () => { this._onWarningDurationReached(); }
    );
  }



  /**
   * Observable emission's filter
   * 
   * @private
   * @param {(KeyboardEvent | MouseEvent | TouchEvent)} event$ 
   * @returns {boolean} 
   * 
   * @memberOf InactivityService
   */
  private filter(event$: KeyboardEvent | MouseEvent | TouchEvent): boolean {
    // Make sure it is valid:
    if (!!event$ !== true)
      return false;

    let retVal: boolean = true; // OK as Default

    if (event$ instanceof KeyboardEvent) {
      retVal = this.isKeyboardEventIgnored(event$) === false;
    }

    return retVal;
  }


  /**
   * Ignore KeyboardEvents based on ignoredKeys
   * 
   * @private
   * @param {KeyboardEvent} keyboardEvent 
   * @returns {boolean} 
   * 
   * @memberOf InactivityService
   */
  private isKeyboardEventIgnored(keyboardEvent: KeyboardEvent): boolean {
    let retVal: boolean = false; // Ignore to false (do not ignore)

    for (let ignoredKey of this.ignoredKeys) {
      if (typeof (ignoredKey) === "string"
        && (ignoredKey.toUpperCase() === (keyboardEvent.code || "").toUpperCase() || ignoredKey.toUpperCase() === (keyboardEvent.key || "").toUpperCase())
      ) {
        retVal = true; // true means ignore this event
        break;
      }

      if (typeof (ignoredKey) === "number" && ((keyboardEvent.which || keyboardEvent.keyCode || -99) === ignoredKey)
      ) {
        retVal = true; // true means ignore this event
        break;
      }
      return retVal;
    }
  }


  /**
   * Reset WarningCountdown timers.
   * 
   * @private
   * 
   * @memberOf InactivityService
   */
  private resetWarningCountdownObservable(): void {
    if (this.warningCountdownObservable === null)
      this.mainCountdownObservable = this.warningCountdownObservable;
    else
      this.warningCountdownObservable.switchMap(() => this.warningCountdownObservable);
  }

  /**
   * Reset Logoff Countdown timers.
   * 
   * @private
   * 
   * @memberOf InactivityService
   */
  private resetLogoffCountdownObservable(): void {
    if (this.logoffCountdownObservable === null)
      this.logoffCountdownObservable = Observable.interval(1000).take(this.secondsUntilLoggedOff);
    else
      this.logoffCountdownObservable.switchMap(() => Observable.interval(1000).take(this.secondsUntilLoggedOff));
  }


  /**
   * This event is fired on KeyboardEvent | MouseEvent | TouchEvent observables merged.
   * 
   * @private
   * @param {(KeyboardEvent | MouseEvent | TouchEvent)} event$ 
   * 
   * @memberOf InactivityService
   */
  private onUIEvent(event$: KeyboardEvent | MouseEvent | TouchEvent): void {
    console.info(`${this.NAME}: UIEVENT: Resetting idle timers`);
    let e: UIEvent = event$ as UIEvent;
    this.resetSubscription();
  }

  /**
   * Starts timer
   * 
   * @param {any} isLog 
   * 
   * @memberOf InactivityService
   */
  public start(): void {
    this.resetSubscription();
  }

  /**
   * Restarts timers (ALIAS)
   * 
   * 
   * @memberOf InactivityService
   */
  public restart(): void {
    this.start();
  }

  /**
   * This will fire when warning duration was reached.
   * 
   * @private
   * 
   * @memberOf InactivityService
   */
  private _onWarningDurationReached(): void {
    this.onWarningEvent.next(new Date());

    this.warningCountdownObservable.switchMap(() => this.logoffCountdownObservable);
    this.logoffCountdownObserver = this.warningCountdownObservable.subscribe(
      //onNext
      (remaining: number) => {
        let remainder: number = this.secondsUntilWarningIsShown - remaining;
        if (isDevMode() && (remainder % this._logEveryXinSeconds === 0))
          console.log(`${this.NAME}: Time Remaining until being logged off due to inactivity: ${remainder}`);
      },

      //onError (just map)
      (error: any) => error,

      //onComplete
      () => { this._onLogoffDurationReached(); }
    );

    console.warn(`${this.NAME}: Warning: You have been idle, and will be logged off in ${this.secondsUntilLoggedOff} seconds.`);
  }

  /**
   * This will fire when user has been idle for the set duration.
   * 
   * @private
   * 
   * @memberOf InactivityService
   */
  private _onLogoffDurationReached(): void {
    this.onLoggedOffEvent.next(new Date());
  }


}
