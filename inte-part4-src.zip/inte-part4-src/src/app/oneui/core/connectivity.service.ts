import { Injectable, AfterViewInit } from '@angular/core';
import { Observable, Subscription, Subject } from 'rxjs/Rx';
import { WindowRefService } from './window-ref.service';

@Injectable()
export class ConnectivityService {

  private _name: string = "ConnectivityService";

  /**
   * Returns true if online
   * 
   * @static
   * @type {boolean}@memberof ConnectivityService
   */
  public static isOnline: boolean = true;

  private readonly eventDefinition: any = {
    onConnectivityRestored: {
      eventName: "online",
      handler: this._onConnectivityRestored,
      source: WindowRefService.nativeWindow
    },
    onConnectivityLost: {
      eventName: "offline",
      handler: this._onConnectivityLost,
      source: WindowRefService.nativeWindow
    }
  };

  /**
   * Constructor
   * 
   * @memberOf ConnectivityService
   */
  constructor() {
    setTimeout(() => { this._init(); }, 0);
  }

  private _onConnectivityLostSubject: Subject<any> = new Subject<any>();
  private _onConnectivityRestoredSubject: Subject<any> = new Subject<any>();

  /**
   * Observable that emits when connectivity is lost based on browser implementatin of onoffline event.
   * 
   * @type {Observable<any>}
   * @memberOf ConnectivityService
   */
  public get onConnectivityLostObservable(): Observable<any> {
    return this._onConnectivityLostSubject.asObservable();
  }

  /**
   * * Observable that emits when connectivity is lost based on browser implementatin of ononline event.
   * 
   * @type {Observable<any>}
   * @memberOf ConnectivityService
   */
  public get onConnectivityRestoredObservable(): Observable<any> {
    return this._onConnectivityRestoredSubject.asObservable();
  }

  /**
   * Initializes observables and other supporting features.
   * 
   * @private
   * 
   * @memberOf ConnectivityService
   */
  private _init(): void {
    Observable
      .fromEvent(this.eventDefinition.onConnectivityLost.source, this.eventDefinition.onConnectivityLost.eventName)
      .subscribe(
      (event$: any) => { this._onConnectivityLost(event$); },
      (onError: any) => { this._init(); } // resubscribe on error
      );

    Observable
      .fromEvent(this.eventDefinition.onConnectivityRestored.source, this.eventDefinition.onConnectivityRestored.eventName)
      .subscribe(
      (event$: any) => { this._onConnectivityRestored(event$); },
      (onError: any) => { this._init(); } // resubscribe on error
      );
  }


  /**
   * Main logic when Connectivity is lost.
   * Note that this will fire regardless of whether or not there are other subscribers/observers.
   * This ensures that we handle the event even though there are no other subscribers/observer.
   * 
   * @private
   * 
   * @memberOf ConnectivityService
   */
  private _onConnectivityLost(event$: any): void {
    console.warn(`${this._name}: Connectivity Lost!`);
    ConnectivityService.isOnline = false;
    this._onConnectivityLostSubject.next(event$);
  }

  /**
   * Main logic when Connectivity is lost.
   * Note that this will fire regardless of whether or not there are other subscribers/observers.
   * This ensures that we handle the event even though there are no other subscribers/observer.
   * 
   * @private
   * 
   * @memberOf ConnectivityService
   */
  private _onConnectivityRestored(event$: any): void {
    if (ConnectivityService.isOnline === false) {
      console.info(`${this._name}: Connectivity Restored!`);
      ConnectivityService.isOnline = true;
      this._onConnectivityRestoredSubject.next(event$);
    }
  }
}
