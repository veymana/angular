import {
  OnInit,
  OnDestroy,
  AfterContentChecked,
  AfterContentInit,
  AfterViewChecked,
  AfterViewInit,
  isDevMode
} from '@angular/core';
import { FlowService } from 'core/flow';

export enum ComponentLifeCyclePhase {
  Unknown = -1,
  OnInit = 0,
  OnDestroy = 1,
  DoCheck = 2,
  OnChanges = 3,
  AfterContentInit = 4,
  AfterContentChecked = 5,
  AfterViewInit = 6,
  AfterViewChecked = 7
}

export class BaseComponent implements
  OnInit,
  OnDestroy,
  AfterContentChecked,
  AfterContentInit,
  AfterViewChecked,
  AfterViewInit {

  public name: string = BaseComponent.name;
  private componentLifeCyclePhase: ComponentLifeCyclePhase = ComponentLifeCyclePhase.Unknown;
  private _onInits: Array<Function> = new Array<Function>();

  constructor(private flowServiceInstance: FlowService) {

  }

  ngOnInit() {
    this.componentLifeCyclePhase = ComponentLifeCyclePhase.OnInit;
    if (isDevMode())
      console.info(`${this.name} phase: OnInit`);

    Array.isArray(this["onInits"])
      && this["onInits"].forEach((f) => f(this, this.flowServiceInstance));

    delete this["onInits"];
  }
  ngOnDestroy() {
    this.componentLifeCyclePhase = ComponentLifeCyclePhase.OnDestroy;
    if (isDevMode())
      console.info(`${this.name} phase: OnDestroy`);
  }
  ngAfterContentChecked() {
    this.componentLifeCyclePhase = ComponentLifeCyclePhase.AfterContentChecked;
    // if (isDevMode())
    //   console.log(`${this.name} phase: AfterContentChecked`);
  }
  ngAfterContentInit() {
    this.componentLifeCyclePhase = ComponentLifeCyclePhase.AfterContentInit;
    // if (isDevMode())
    //   console.log(`${this.name} phase: AfterContentInit`);
  }
  ngAfterViewChecked() {
    this.componentLifeCyclePhase = ComponentLifeCyclePhase.AfterViewChecked;
    // if (isDevMode())
    //   console.log(`${this.name} phase: AfterViewChecked`);
  }
  ngAfterViewInit() {
    this.componentLifeCyclePhase = ComponentLifeCyclePhase.AfterViewInit;
    // if (isDevMode())
    //   console.log(`${this.name} phase: AfterViewInit`);
  }
}
