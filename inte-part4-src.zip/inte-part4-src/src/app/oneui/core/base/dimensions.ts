import {
  Component,
  OnInit,
  ElementRef
} from '@angular/core';

/**
 * Abstract case class that provides DOM dimensions of the component.
 * Children classes extending this base class will have to implement getMainElement() as
 * a form of enforcement. This way, the child class can have a different mainElement for dimensions
 * as opposed to just it's host/content container.
 * 
 * @export
 * @abstract
 * @class Dimensions
 */
export abstract class Dimensions {

  /**
   * Retrieves the mainElement that will be the basis for the dimension calculations/properties.
   * 
   * @abstract
   * @returns {ElementRef} 
   * 
   * @memberOf Dimensions
   */
  public abstract getMainElement(): ElementRef;

  constructor() { }

  /**
   * Returns main element's height
   * 
   * @readonly
   * @type {number}
   * @memberOf Dimensions
   */
  get height(): number {
    let nativeElement: HTMLElement = this.getMainElementNativeHTMLElement();
    return nativeElement && nativeElement.offsetHeight;
  }

  /**
 * Returns main element's width
 * 
 * @readonly
 * @type {number}
 * @memberOf Dimensions
 */
  get width(): number {
    let nativeElement: HTMLElement = this.getMainElementNativeHTMLElement();
    return nativeElement && nativeElement.getBoundingClientRect().width;
  }

  /**
   * Returns main element's top
   * 
   * @readonly
   * @type {number}
   * @memberOf Dimensions
   */
  get top(): number {
    let nativeElement: HTMLElement = this.getMainElementNativeHTMLElement();
    return nativeElement && nativeElement.getBoundingClientRect().top;
  }

  /**
   * Returns main element's right
   * 
   * @readonly
   * @type {number}
   * @memberOf Dimensions
   */
  get right(): number {
    let nativeElement: HTMLElement = this.getMainElementNativeHTMLElement();
    return nativeElement && nativeElement.getBoundingClientRect().right;
  }

  /**
   * Returns main element's bottom
   * 
   * @readonly
   * @type {number}
   * @memberOf Dimensions
   */
  get bottom(): number {
    let nativeElement: HTMLElement = this.getMainElementNativeHTMLElement();
    return nativeElement && nativeElement.getBoundingClientRect().bottom;
  }

  /**
   * Returns main element's left
   * 
   * @readonly
   * @type {number}
   * @memberOf Dimensions
   */
  get left(): number {
    let nativeElement: HTMLElement = this.getMainElementNativeHTMLElement();
    return nativeElement && nativeElement.getBoundingClientRect().left;
  }


  /**
   * Returns main element's scrollTop
   * 
   * @readonly
   * @type {number}
   * @memberOf Dimensions
   */
  get scrollTop(): number {
    let nativeElement: HTMLElement = this.getMainElementNativeHTMLElement();
    return nativeElement && nativeElement.scrollTop;
  }

  /**
   * Returns main element's scrollHeight
   * 
   * @readonly
   * @type {number}
   * @memberOf Dimensions
   */
  get scrollHeight(): number {
    let nativeElement: HTMLElement = this.getMainElementNativeHTMLElement();
    return nativeElement && nativeElement.scrollHeight;
  }

  private getMainElementNativeHTMLElement(el?: ElementRef): HTMLElement {
    el = el || this.getMainElement();
    return el && el.nativeElement;
  }

}
