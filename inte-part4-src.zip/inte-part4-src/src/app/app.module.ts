
/* FRAMEWORK */
import { BrowserModule } from '@angular/platform-browser';
import { NgModule, ApplicationRef, isDevMode, Injector } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';
import { NgbModule, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { environment } from '#environments/environment';


/* SUBMODULES */
import { CoreModule } from './oneui/core/core.module';
import { AppRoutingModule } from './app-routing.module';

/* CORE */
import { StartupService } from './oneui/core/startup.service';
import { WebSocketService } from './oneui/core/web-socket.service';

/* COMPONENTS */

/* SERVICES */
//import { RouterEventsService } from 'oneui/core/router-events.service';

import { InactivityService } from './oneui/core/inactivity.service';
import { RestclientBaseService } from './oneui/core/restclient/restclient-base.service';
import { ConnectivityService } from './oneui/core/connectivity.service';
import { GlobalNavigationService } from './oneui/core/global-navigation/global-navigation.service';
import { UserService } from './oneui/core/user.service';
import { TerminatesessionService } from './oneui/core/restclient/terminate-session-restclient.service';
import { AppLoggerService } from './oneui/core/app-logger.service';
import { AppSettings } from '#environments/environment';

/* HELPERS */
/* HELPERS */
import { GlobalInjector } from './oneui/core/global-injector';
import { AppComponent } from './app.component'
import { RouterEventsService } from "./oneui/core/router-events.service";
/*import { SharedModule } from "./oneui/shared/shared.module";*/
import { UsageTrackingModule } from "./oneui/usage-tracking/usage-tracking.module";
import { QueueModule } from "./oneui/queue/queue.module";
import { ValidatorsModule } from "./oneui/shared/validators/validators.module";
import { PopupService } from "./oneui/shared/popup";

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { Routes } from '@angular/router';
import { EwithdrawalComponent } from './itemcashing/ewithdrawal/ewithdrawal.component'
import { BoardTransactionComponent } from './shared/boardtransaction/boardtransaction.component';
import { EdebititemComponent } from './shared/edebititem/edebititem.component';
import { LcashitemComponent } from './shared/lcashitem/lcashitem.component';
import { routes } from './itemcashing/itemcashing.routes'
import { ItemCashingService } from './itemcashing/itemcashing.service'
import { SummaryComponent } from './shared/summary/summary.component';
import { BoardService } from './shared/board.service'
import { TellerFlowService } from "app/common/teller-flow.service";
import { Tv2Module } from "app/tv2/tv2.module";


@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    NgbModule.forRoot(),
    CoreModule,
    AppRoutingModule,
    UsageTrackingModule,
    QueueModule,
    ValidatorsModule,
    Tv2Module.forRoot()
  ],
  providers: [
    TellerFlowService,
    WebSocketService,
    PopupService,
    StartupService,
    RouterEventsService,
    ItemCashingService, BoardService
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
}
