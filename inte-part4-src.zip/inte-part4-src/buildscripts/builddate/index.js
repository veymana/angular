var fs = require('fs');
var config = require('./builddate-config.js');
var parameters = {};
var _self = this;
(function (params) {
	process.argv.forEach(function (val, index) {
		if (val.indexOf("--") == 0 && val.indexOf("=") > -1) {
			var parts = val.split("=");
			if (parts.length > 1) {
				var paramKey = parts[0].toString().trim().replace("--", "");
				var paramValue = parts[1].toString().trim();
				params[paramKey.toLowerCase()] = paramValue;
			}
		}
	});
})(parameters);

function trimTrailingSlashes(str) {
	if (!!str === false)
		return str;

	return str.replace(/(\/|\\)$/, "");
}

function createDirStructure(dir) {
	const splitPath = dir.split('/');
	splitPath.reduce((path, subPath) => {
		let currentPath;
		if (subPath != '.' && subPath != '..') {
			currentPath = path + '/' + subPath;
			if (!fs.existsSync(currentPath)) {
				fs.mkdirSync(currentPath);
			}
		}
		else {
			currentPath = subPath;
		}
		return currentPath
	}, '');
}

function getFullPathToFile() {
	var retval = "";
	var path = trimTrailingSlashes(parameters["location"] || config.defaultOutputPath || "");
	var filename = trimTrailingSlashes(parameters["filename"] || config.defaultOutputFile || "");
	var isCreateDir = (typeof (parameters["createdir"]) !== "undefined") ? parameters["createdir"] : config.createDir || false;

	if (isCreateDir) {
		console.log(`Creating dir ${path}`);
		createDirStructure(path);
	}

	retval = path + "/" + filename;

	return retval;
}

function getTemplate() {
	return config.template || "ERROR: TEMPLATE NOT SET!";
}

var write = function () {
	fs.writeFile(getFullPathToFile(), getTemplate(), { flag: 'w' }, function (err) {
		if (err) {
			return console.log(err);
		}
		console.log("Build Date file created");
	});
}

write();

exports.builddatewriter = write;