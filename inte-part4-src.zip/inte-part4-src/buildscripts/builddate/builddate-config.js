/**
 * builddate-config.js
 * Configures builldate module
 */


var config = {
	// Where the file will be written to.
	// Change this config or
	// Override this with --location="path/to/folder"
	defaultOutputPath: "../src/environments/",

	// Filename to write to
	// Change this config or
	// Override this with --filename="file.ts"
	defaultOutputFile: "builddate.ts",

	// Creates directory too if true. 
	// If false and directory does not exist, it will throw an error. 
	// Change this config or
	// Override this with --createDir=true/false
	createDir: true,

	// Template
	// What will be written to the file.
	// Must be valid Javascript String
	template: `
	/* DO NOT EDIT. THIS FILE IS GENERATED */
	export const builddate = "${new Date().toString()}";
	`
};

module.exports = config;