/**
 * config.js
 * Configures appcachegen module
 */
var config = {
    // The default file where output will be written to:
    defaultOutputFile: "src\\static\\appcache.manifest",

    // Files in these folders will be added to the manifest.
    globs: [
        "assets\\images\\**.*"
    ],

    // Options for the glob() call.
    globOptions: {
        ignore: [
            "*.js",
            "*.md"
        ],
        cwd: ".\\src",
        nodir: true,
        mark: true
    },

    // This will be prepended to the list of files.
    prepend: "/",

    // These will be written under NETWORK: of the manifest file.
    networkFiles: [
        "index.html",
        "*"
    ],

    // Extra files aside from the generated files.
    extraCachedFiles: [
        "inline.bundle.js",
        "main.bundle.js",
        "ngsw-manifest.json",
        "polyfills.bundle.js",
        "sw-register.bundle.js",
        "vendor.bundle.js",
        "worker-basic.min.js"
    ]
};

module.exports = config;