/**
 * Application Cache Manifest Generator
 * @author Lucky Mallari
 */

var fs = require('fs');
var glob = require('glob');
var path = require('path');

var config = require('./config.js');

/*  config has the following:
 *      defaultOutputFile: string;
 *      globs: Array<string>;
 *      exclude: Array<string>;
 *      networkFiles: Array<string>;
 *      extraCachedFiles: Array<string>;
 */

var template = `CACHE MANIFEST

#App Cache Manifest (Auto Generated. Do not edit manually!)
#Generated: ${new Date().toString()}

CACHE:
${getCachedFiles()}
${getExtraCachedFiles()}

NETWORK:
${getNetworkFiles()}
`;

/**
 * Returns all Cached Files 
 * 
 * @returns 
 */
function getCachedFiles() {

    let globs = config.globs || [];
    let allFilesFromAllFolders = new Array();
    for (let _glob of globs) {
        //let resolvegGlob = path.resolve(_glob);
        let found = glob.sync(_glob, config.globOptions || {});
        allFilesFromAllFolders = allFilesFromAllFolders.concat(found);
    }
    let arrayOfFiles = allFilesFromAllFolders || [];
    return (config.prepend || "") + arrayOfFiles.join("\r\n" + (config.prepend || ""));
}

/**
 * Returns all extra Cached Files 
 * 
 * @returns 
 */
function getExtraCachedFiles() {
    let arrayOfFiles = config.extraCachedFiles || [];
    return arrayOfFiles.join("\r\n");
}

/**
 * Returns all network files 
 * 
 * @returns 
 */
function getNetworkFiles() {
    let arrayOfFiles = config.networkFiles || [];
    return arrayOfFiles.join("\r\n");
}

/**
 * List files from a directory.
 * 
 * @param {any} directoryPath 
 */
function listFilesFromDirectory(directoryPath) {
    let retVal = new Array();
    fs.readdir(directoryPath, (err, files) => {
        files.forEach(directoryPath => {
            retVal.push(file);
        });
    })
}

var parameters = {};
var _self = this;
(function (params) {
    process.argv.forEach(function (val, index) {
        if (val.indexOf("--") == 0 && val.indexOf("=") > -1) {
            var parts = val.split("=");
            if (parts.length > 1) {
                var paramKey = parts[0].toString().trim().replace("--", "");
                var paramValue = parts[1].toString().trim();
                params[paramKey] = paramValue;
            }
        }
    });
})(parameters);

function getFullPathToFile() {
    return parameters["output"] || config.defaultOutputFile;
}

fs.writeFile(getFullPathToFile(), template, function (err) {
    if (err) {
        return console.error(err);
    }
    console.log(`Success: ${getFullPathToFile()}`);
}); 