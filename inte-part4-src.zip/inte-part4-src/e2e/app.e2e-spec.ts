import { StageDirectorPage } from './app.po';

describe('StageDirector App', function() {
  let page: StageDirectorPage;

  beforeEach(() => {
    page = new StageDirectorPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
