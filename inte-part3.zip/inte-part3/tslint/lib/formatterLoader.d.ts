import { FormatterFunction } from "./index";
export declare function findFormatter(name: string | FormatterFunction, formattersDirectory?: string): any;
