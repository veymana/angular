

export class TellerProfile {
  id: number;
  type:string;
  branchCode:string;
  
}