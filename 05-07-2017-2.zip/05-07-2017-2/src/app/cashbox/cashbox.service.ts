
import {Injectable} from '@angular/core';
import {Http, Response} from '@angular/http';
import {Account} from './account.model';
import 'rxjs/add/operator/map';
    
@Injectable()
export class CashboxService {
    
    accounts;
    items;

    constructor(private http: Http) {}

    getAccounts() {
        return this.http.get('./data/accounts.json')
        .map((res:Response) => <Account[]> res.json());
    }

 getMockAccounts(){

   this.accounts= [
               {accountNumber:4342342424,lob:"",productName:"Wells Fargo Platinum Savings",
                openDate : "07/29/16",status:"Active",custRel:"Sole Owner",transAuth:"Yes",
                ledgerBalance:"$12,3444,12"},
                {accountNumber:7686234224,lob:"",productName:"Wells Fargo Platinum Savings",
                openDate : "07/29/16",status:"Active",custRel:"Sole Owner",transAuth:"Yes",
                ledgerBalance:"$12,3444,12"}
       ]

   return this.accounts;
  }

getMenuItems(){
       this.items = [
                            {
                                label: '4Sales',
                                items: [
                                    {label: 'Sales Items'},
                              
                                    {label: 'Sales Items'}  
                                ]
                            },
                            {
                                label: '5Misc$',
                                items: [
                                    {label: 'Misc$ Items',command: (event) =>{
                                    console.log(event.originalEvent);
                                }},
                                    {label: 'Misc$ Items'},
                                    
                                    {label: 'Misc$ Items'}
                                ]
                            },
                            {
                                label: '6Admin',
                                items: [
                                    {label: 'Admin Items'},
                                   
                                    {label: 'Admin Items'}
                                ]
                            },
                            {
                                label: '7Non-Dollar',
                                items: [
                                        {label: 'NON-Dollar Items'},
                                    {label: 'NON-Dollar Items'},
                                    {label: 'NON-Dollar Items'},
                                    {label: 'NON-Dollar Items '}
                                ]
                            },
                            {
                                label: '8Desktop',
                            
                            },
                            {
                                label: '9Customer Session',
                                items: [
                                   
                                    {label: 'Customer Session'}
                                ]
                            }
        ];
return this.items;
}

}