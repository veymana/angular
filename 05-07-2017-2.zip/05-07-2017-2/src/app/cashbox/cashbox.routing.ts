import { Routes, RouterModule } from '@angular/router';
import {ItemCashingEWithdrawalComponent} from './item-cashing-ewithdraw/item-cashing.component' ;


const routes: Routes = [
  {
    path: 'ewidthdrawal',
    component: ItemCashingEWithdrawalComponent,
  }
];

export const appRouterModule = RouterModule.forRoot(routes);