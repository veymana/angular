
import {Injectable} from '@angular/core';
import {Http, Response} from '@angular/http';
import {Account} from './account.model';
import 'rxjs/add/operator/map';
    
@Injectable()
export class Tv2Service {
    
    accounts;
    items;

    constructor(private http: Http) {}

    getAccounts() {
        return this.http.get('./data/accounts.json')
        .map((res:Response) => <Account[]> res.json());
    }

 getMockAccounts(){

   this.accounts= [
               {accountNumber:4342342424,lob:"",productName:"Wells Fargo Platinum Savings",
                openDate : "07/29/16",status:"Active",custRel:"Sole Owner",transAuth:"Yes",
                ledgerBalance:"$12,3444,12"},
                {accountNumber:7686234224,lob:"",productName:"Wells Fargo Platinum Savings",
                openDate : "07/29/16",status:"Active",custRel:"Sole Owner",transAuth:"Yes",
                ledgerBalance:"$12,3444,12"}
       ]

   return this.accounts;
  }

getMenuItems(){
       this.items = [
                            {
                                label: 'Selected',
                                items: [
                                    {label: 'Select PIN'},
                                    {label: 'PINPAD View'},
                                    {label: 'Reset PINPAD'},
                                    {label: 'Express Send '}  
                                ]
                            },
                            {
                                label: 'Services',
                                items: [
                                    {label: 'Select PIN',command: (event) =>{
                                    console.log(event.originalEvent);
                                }},
                                    {label: 'PINPAD View'},
                                    {label: 'Reset PINPAD'},
                                    {label: 'Express Send '}
                                ]
                            },
                            {
                                label: 'Administration',
                                items: [
                                    {label: 'Select PIN'},
                                    {label: 'PINPAD View'},
                                    {label: 'Reset PINPAD'},
                                    {label: 'Express Send '}
                                ]
                            },
                            {
                                label: 'Customer Session',
                                items: [
                                        {label: 'Select PIN'},
                                    {label: 'PINPAD View'},
                                    {label: 'Reset PINPAD'},
                                    {label: 'Express Send '}
                                ]
                            },
                            {
                                label: 'Customer Session',
                                items: [
                            {label: 'Select PIN'},
                                    {label: 'PINPAD View'},
                                    {label: 'Reset PINPAD'},
                                    {label: 'Express Send '}
                                ]
                            }
        ];
return this.items;
}

}