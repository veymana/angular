

export class AuthorizedAccount {
    accountNumber: number;
    productName: string;
    balance: string;
}