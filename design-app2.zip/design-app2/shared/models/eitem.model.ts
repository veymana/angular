import { BoardItem } from './boarditem.model'
export class ElectronicItem implements BoardItem {

}