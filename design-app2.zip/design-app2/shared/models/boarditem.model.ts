
export interface BoardItem {

} 