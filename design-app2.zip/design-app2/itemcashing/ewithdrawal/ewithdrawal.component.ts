import { Component, OnInit } from '@angular/core';
import { AuthorizedAccount } from '../../shared/models/authorized-acct.model'
import { TransactionModel } from '../../shared/models/transaction.model';
import { LessCashItem } from '../../shared/models/lcash-item.model';
import { ItemCashingService } from '../../itemcashing/itemcashing.service'
import { EDebitItem } from '../../shared/models/edebit-item.model';

@Component({
  selector: 'ewithdrawal',
  templateUrl: 'ewithdrawal.component.html',
  styleUrls: ['ewithdrawal.component.scss']
})
export class EwithdrawalComponent implements OnInit {

  trnxModel: TransactionModel = new TransactionModel();
  authorizedAccounts: AuthorizedAccount[];
  summary: boolean = false;
  constructor(private itemsCashingService: ItemCashingService) {
  }

  ngOnInit() {
    this.trnxModel.addCreditItem(new LessCashItem());
    this.authorizedAccounts = this.itemsCashingService.getMockAuthorizedAccounts();
  }

  addEDebitItem() {
    this.trnxModel.addDebitItem(new EDebitItem(this.authorizedAccounts));
    this.summary = true;
  }

  validateItems(): boolean {
    return true;
  }

  onSubmit() {

  }
  onComplete() {

  }

}
