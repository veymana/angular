

export class TellerProfile {
 
     transferLimit: string;
     onlineConsumerDepLimit: number;
     onlineBusinessDepLimit: number;
     effectivePostingDate: string;
     firstName: string;
     lastName: string;
     onNextDay: boolean;
     eid: string;
     lastTmaSync: string ;
     status: string;
     enabled: boolean;
     cashboxNum: number;
     lastSignOffDate: string;
     lastSignOnDate: string;
     workstationId: string;
     privId: string;
     modifiedCount: number;
     vault00Access: boolean;
     vault50Access: boolean;
     cashRoleCode: string;
     cashRoleDesc: string;
     roleIndicator: string;
     away: boolean;
     authority: string;
     cashLimit: number;
     preferredFirstName: string;
     preferredLastName: string;
     phone: string;
     email: string;
     cashboxAccess: boolean; 
     pinselAccess: boolean;
     openCloseAccess: boolean;
     vaultAccessEnabled: boolean;
     onlineWithdrawalLimit: number;
     offlineWithdrawalLimit: number;
     offlineConsumerDepLimi: number;
     offlineBusinessDepLimit: number;
     nonWFBLimit: number;
     assistedService: boolean; 
     useAssignedLimits: boolean;
     riskEvalDeposit: number;
     riskEvalCashout: number;
  
}