
export enum TransactionState{
        CONSTRUCTION,
        COLLECTION,
        CONFIRMATION,
        CORRECTION,
        CONCLUSION,
        CIRCLEBACK
}


