

export class BranchProfile {
 
    merchantId: string;
    merchantName: string;
    terminalId: string;
    topsideAu: string;
    branchAu: string;
    locationId: string;
    outletId: string;
    outletName: string;
    storeProfileUrl: string;
    trainingStoreProfileUrl: string;
    companyId: string;
    branchRtn: string;
    federalRegion: string;
    outletMac: string;
    phoneNumber: string;
    branchAddress: string;
    branchCity: string;
    branchState: string;
    branchZip: string;
    managerName: string;
    outletFormat: string;
    timeZone: string;
    daylightSavings: string;

}