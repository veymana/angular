

export class CustomerProfile {
    indentification: Indentification;
    contact: Contact;
    services: Services;
    session: Session;
    history: HistoryDetails;
    consumerAccounts: Account[];
    businessAccounts: Account[];
    brokerageAccounts: Account[];
    otherAccounts: Account[];

}

class Indentification {
    name: string;
    customerSelected: string
    dob: string
    ssn: string
    highValue: string
    customerSince: string
    customerNumber: number
}
class Contact { }
class Services { }
class Session { }
class HistoryDetails { }

class Account {
    accountNumber: number;
    lob: string;
    product: string;
    open: string;
    status: string;
    relation: string;
    transAuth: boolean;
    balance: number;
}
