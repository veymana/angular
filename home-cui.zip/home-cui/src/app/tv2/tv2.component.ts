import { Component, Input, Output, EventEmitter,OnInit } from '@angular/core';
import { MenubarModule, MenuItem } from 'primeng/primeng';
import { CheckboxModule } from 'primeng/primeng';
import { DataTableModule, SharedModule } from 'primeng/primeng';
import { ButtonModule } from 'primeng/primeng';
import { DialogModule } from 'primeng/primeng';
import { OverlayPanelModule } from 'primeng/primeng';
import { FieldsetModule } from 'primeng/primeng';
import { MessagesModule } from 'primeng/primeng';
import { TabViewModule } from 'primeng/primeng';
import { Tv2Service } from './tv2.service';

@Component({
    selector: 'tv2-app',
    templateUrl: 'tv2.component.html',
    styleUrls: ['tv2.component.scss']
})
export class Tv2Component implements OnInit{
    title = 'Store Vision Teller';
    items: MenuItem[];
    selectedValues: string[] = [];
    accounts;
    accountDetails = [];
    dlgWidth: number = 800;
    dlgHeight: number = 800;
    cssProfiledisplay: string = "none";
    cssBlankProfiledisplay: string = "block";

    @Output() onCbClose = new EventEmitter<boolean>();

    cbDisplay = false;
    tv2Display = true;

    constructor(private tv2Service: Tv2Service) {
        this.dlgWidth = window.screen.width - 20;
        this.dlgHeight = window.screen.height - 10;
    }

    ngOnInit(){
        this.accounts = this.tv2Service.getMockAccounts();
        this.items = this.tv2Service.getMenuItems();
    }

    pinSelect: boolean = false;
    pinSelectTemp: boolean = false;
    findCustDlg: boolean = false;

    pinpadStatus: string = "eWithdrawal Ready";

    showCbDialog() {
        this.cbDisplay = true;
        this.pinpadStatus = "Customer waiting";

    }

    findCustomer() {
        this.findCustDlg = true;
    }

    findCustSearch() {
        let temp = this.tv2Service.getCustProfile();
        this.tv2Service.getCusProfileTemp();
    }

    findCustOk() {
        this.findCustDlg = false;
        this.cssProfiledisplay = "block";
        this.cssBlankProfiledisplay = "none";
    }

    findCustCan() {
        this.findCustDlg = false;
        this.cssProfiledisplay = "none";
        this.cssBlankProfiledisplay = "block";
    }

    onItemCashingCloseHandle(status: boolean) {
        this.cbDisplay = false;
        this.pinpadStatus = "eWithdrawal Ready";
    }
    registerHotKey($event) {
        console.log("TV2 Component:" + $event.keyCode);
        if (($event.keyCode == 116 || $event.keyCode == 84) && $event.altKey) {
            $event.stopPropagation();
            $event.preventDefault();

            if (this.cbDisplay) {
                this.cbDisplay = false;
            }
            else {
                this.cbDisplay = true;
            }
        }
    }

    msgs = [{ severity: 'info', summary: '', detail: 'PIN updated' }];
    pinMsgs = [{ severity: 'info', summary: '', detail: 'Verify that customer knows current PIN and click OK to start PIN Pad' }];

}
