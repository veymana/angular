import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TotalsBarComponent } from './totals-bar.component';

describe('TotalsBarComponent', () => {
  let component: TotalsBarComponent;
  let fixture: ComponentFixture<TotalsBarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TotalsBarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TotalsBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
