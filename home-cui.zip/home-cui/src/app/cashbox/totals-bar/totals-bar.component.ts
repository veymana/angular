import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cb-totals-bar',
  templateUrl: './totals-bar.component.html',
  styleUrls: ['./totals-bar.component.scss']
})
export class TotalsBarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
