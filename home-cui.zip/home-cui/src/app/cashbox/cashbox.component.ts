import { Component, Input, Output, EventEmitter } from '@angular/core';
import { MenubarModule, MenuItem } from 'primeng/primeng';
import { CheckboxModule } from 'primeng/primeng';
import { DataTableModule, SharedModule } from 'primeng/primeng';
import { ButtonModule } from 'primeng/primeng';
import { DialogModule } from 'primeng/primeng';
import { OverlayPanelModule } from 'primeng/primeng';
import { FieldsetModule } from 'primeng/primeng';
import { MessagesModule } from 'primeng/primeng';
import { TabViewModule } from 'primeng/primeng';
import { CashboxService } from './cashbox.service';
import { RouterModule, Routes } from '@angular/router';

@Component({
    selector: 'cashbox-app',
    templateUrl: 'cashbox.component.html',
    styleUrls: ['cashbox.component.scss']
})
export class CashboxComponent {
    title = 'Store Vision Teller';
    items: MenuItem[];
    selectedValues: string[] = [];

    accounts;
    @Input()
    display = false;
    @Output() onTv2Close = new EventEmitter<boolean>();



    constructor(private cashboxService: CashboxService) {
        this.accounts = cashboxService.getMockAccounts();
        this.items = cashboxService.getMenuItems();
    }

    pinSelect: boolean = false;

    pinpadStatus: string = "eWithdrawal Ready";

    ewithdrawal: boolean = false;

    showDialog() {
        this.display = true;
    }

    launchEWithdrawal() {
        this.ewithdrawal = true;
        this.pinpadStatus = "Customer waiting"
    }

    onItemCashingCloseHandle(status: boolean) {
        this.ewithdrawal = false;
        this.pinpadStatus = "PIN Pad:Ready"
    }

    onTv2CloseHandle(agreed: boolean) {
        this.display = false;
    }
    closeTv2() {
        this.onTv2Close.emit(false);
    }
    registerHotKey($event) {

        if (($event.keyCode == 116 || $event.keyCode == 84) && $event.altKey) {
            $event.stopPropagation();
            $event.preventDefault();

            if (this.display) {
                this.display = false;
            }
            else {
                this.display = true;
            }

        }
    }

    msgs = [{ severity: 'info', summary: '', detail: 'PIN updated' }];
    pinMsgs = [{ severity: 'info', summary: '', detail: 'Verify that customer knows current PIN and click OK to start PIN Pad' }];



}
