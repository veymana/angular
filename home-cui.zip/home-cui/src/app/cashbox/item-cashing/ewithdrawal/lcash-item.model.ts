import { BaseDebitItem } from './base-debit-item';

export class LessCashItem implements BaseDebitItem {
    debitIcon: string;
    statusIcon: string;
    amount: number;

    constructor() {
        this.debitIcon = "assets/images/less-cash.png";
        this.statusIcon = "assets/images/check-error.png";
        this.amount = 0.00;
    }
}