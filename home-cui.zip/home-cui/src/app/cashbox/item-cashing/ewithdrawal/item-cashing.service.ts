
import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { AuthorizedAccount } from './authorized-acct.model';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/throw';
import { ApplicationError } from './error/app.error'

@Injectable()
export class ItemCashingEwithdrawService {

    constructor(private http: Http) { }

    endPoint: string = "http://10.92.99.115:8080/SVTRest/customer/getCustomer?ecn=1";//@FIXME Config File

    getAuthorizedAccounts(): Observable<AuthorizedAccount[]> {
        return this.http.get(this.endPoint)
            .map(response => response.json() as AuthorizedAccount[])
            .catch(this.processErrors);
    }

    private processErrors(error: Response) {
        if (error.status === 400) {
            return Observable.throw(new ApplicationError("324", "sample error message"));//@FIXME
        }
        else
            return Observable.throw(error);//@FIXME should be specific
    }

    getMockAuthorizedAccounts(): AuthorizedAccount[] {

        return [{
            accountNumber: 98563257415,
            productName: 'Wells Fargo Preferred Checking',
            balance: "$76,86,23"
        },
        {
            accountNumber: 4562875225,
            productName: 'Wells Fargo Preferred Checking',
            balance: "$76,86,23"
        }
        ];
    }

}