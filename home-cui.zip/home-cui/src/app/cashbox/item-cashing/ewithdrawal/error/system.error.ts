import { ErrorHandler } from '@angular/core'
import { Response } from '@angular/http'

export class SystemErrorHandler implements ErrorHandler {

    handleError(error) {
        console.log("***** SYSTEM ERROR ****");
        if (error instanceof Response) {
            console.log("HTTP ERROR");//@FIXME
        }
        else
            console.log(error);
    }

}