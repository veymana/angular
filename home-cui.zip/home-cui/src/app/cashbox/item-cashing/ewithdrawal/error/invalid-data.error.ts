import { ApplicationError } from './app.error'

export class InvalidData extends ApplicationError {

}