

export class ApplicationError {
    constructor(public errorCode: string, public errorMsg: string) { }
}