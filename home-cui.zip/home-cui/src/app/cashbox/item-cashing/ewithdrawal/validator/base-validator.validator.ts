


export class BaseValidator {

}