import { BaseValidator } from './base-validator.validator'
import { AbstractControl, ValidationErrors } from '@angular/forms'

export class BoardTotalsValidator extends BaseValidator {

  static unbalancedBoard(control: AbstractControl): ValidationErrors | null {
    if ((control.value as string).indexOf("$") >= 0) {
      return {
        invalidAmout: true
      }
    } else { return null; }
  }

}
