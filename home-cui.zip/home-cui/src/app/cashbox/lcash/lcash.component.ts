import { Component, OnInit, Input } from '@angular/core';
import { LessCashItem } from '../item-cashing/lcash-item.model'

@Component({
  selector: 'lcash-item',
  templateUrl: './lcash.component.html',
  styleUrls: ['./lcash.component.scss']
})
export class LcashComponent implements OnInit {

  @Input("itemModel") lessCashItem: LessCashItem;
  @Input("serial") serial: number;

  constructor() { }

  ngOnInit() {
  }

}
