import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LcashComponent } from './lcash.component';

describe('LcashComponent', () => {
  let component: LcashComponent;
  let fixture: ComponentFixture<LcashComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LcashComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LcashComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
