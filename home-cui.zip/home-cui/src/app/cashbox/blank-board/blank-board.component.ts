import { Component, OnInit, Input } from '@angular/core';
import { MenubarModule, MenuItem } from 'primeng/primeng';
import { CashboxService } from '.././cashbox.service'

@Component({
  selector: 'cashbox-board',
  templateUrl: './blank-board.component.html',
  styleUrls: ['./blank-board.component.scss']
})
export class BlankBoardComponent implements OnInit {
  dlgWidth: number;
  dlgHeight: number;
  items: MenuItem[];
  @Input()
  display = true;
  constructor(private cashboxService: CashboxService) {
    this.dlgWidth = window.screen.width - 20;
    this.dlgHeight = window.screen.height - 10;
    this.items = cashboxService.getMenuItems();
  }
  ngOnInit() {

  }

}
