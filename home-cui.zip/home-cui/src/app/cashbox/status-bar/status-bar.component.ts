import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cb-status-bar',
  templateUrl: './status-bar.component.html',
  styleUrls: ['./status-bar.component.scss']
})
export class StatusBarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
