import { Component, OnInit, Input } from '@angular/core';
import { AuthorizedAccount } from '../item-cashing/ewithdrawal/authorized-acct.model';
import { ItemCashingEwithdrawService } from '../item-cashing/ewithdrawal/item-cashing.service'
import { EDebitItem } from '../item-cashing/ewithdrawal/edebit-item.model';
@Component({
  selector: 'edebit-item',
  templateUrl: './edebit.component.html',
  styleUrls: ['./edebit.component.scss']
})
export class EdebitComponent implements OnInit {

  @Input("itemModel") eDebitItem: EDebitItem;
  @Input("serial") serial: number;

  showDetails: boolean = false;
  ngOnInit() {
  }

  toggleDetails() {
    this.showDetails = !this.showDetails;
  }


}
