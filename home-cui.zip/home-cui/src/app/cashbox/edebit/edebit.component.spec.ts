import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EdebitComponent } from './edebit.component';

describe('EdebitComponent', () => {
  let component: EdebitComponent;
  let fixture: ComponentFixture<EdebitComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EdebitComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EdebitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
