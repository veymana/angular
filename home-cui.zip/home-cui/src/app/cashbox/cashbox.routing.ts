import { Routes, RouterModule } from '@angular/router';
import { WithdrawalComponent } from '.././cashbox/item-cashing/withdrawal/withdrawal.component';

export const routes: Routes = [
  {
    path: 'ewidthdrawal',
    component: WithdrawalComponent,
  }
];
