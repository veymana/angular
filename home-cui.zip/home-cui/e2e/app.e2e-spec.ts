import { TellerCuiPage } from './app.po';

describe('teller-cui App', () => {
  let page: TellerCuiPage;

  beforeEach(() => {
    page = new TellerCuiPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
