

export interface BoardItem {

}
