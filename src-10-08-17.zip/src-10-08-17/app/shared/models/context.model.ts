

export class TrnxContext {

    source: string;

}