
import { BoardItem } from './board-item.model';
import { TrnxContext } from './context.model';

export class TransactionModel {

    debitItems: BoardItem[] = [];
    creditItems: BoardItem[] = [];
    context: TrnxContext;

    addDebitItem(debitItem: BoardItem) {
        this.debitItems.push(debitItem);
    }
    addCreditItem(debitItem: BoardItem) {
        this.creditItems.push(debitItem);
    }
    setContext(context: TrnxContext) {
        this.context = context;
    }
}