

import { AbstractControl, ValidationErrors } from '@angular/forms'
export class EDebitValidator {

    static invalidItem(control: AbstractControl): ValidationErrors | null {
        if (+(control.value as string) <= 0) {
            return {
                invalidItem: true
            }
        } else { return null; }
    }
}