import { Injectable, EventEmitter } from '@angular/core';
import { BoardEvent } from './board-event.model'
@Injectable()
export class BoardService {

  boardEvent: EventEmitter<BoardEvent> = new EventEmitter();

}

