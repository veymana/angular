import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BoardtransactionComponent } from './boardtransaction.component';

describe('BoardtransactionComponent', () => {
  let component: BoardtransactionComponent;
  let fixture: ComponentFixture<BoardtransactionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BoardtransactionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BoardtransactionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
