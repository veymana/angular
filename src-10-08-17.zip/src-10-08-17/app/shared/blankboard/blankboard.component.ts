import { Component, OnInit, Input } from '@angular/core';
import { MenubarModule, MenuItem } from 'primeng/primeng';
import { ItemCashingService } from '../../itemcashing/itemcashing.service'
import { BoardService } from '../../shared/board.service';


@Component({
  selector: 'blank-board',
  templateUrl: './blankboard.component.html',
  styleUrls: ['./blankboard.component.scss']
})
export class BlankboardComponent implements OnInit {

  @Input() displayBoard: boolean = false;
  dlgWidth: number;
  dlgHeight: number;
  items: MenuItem[];
  hostUpdateDlg: boolean = true;
  hotkeysHelp: boolean = true;
  displayTestDlg: boolean = false;
  blockedPanel: boolean = false;



  constructor(private icService: ItemCashingService, private bs: BoardService) {
    this.dlgWidth = window.screen.width - 20;
    this.dlgHeight = (window.screen.height - 150);
    this.items = icService.getMenuItems();
  }
  test() {

    this.displayTestDlg = !this.displayTestDlg;

  }


  ngOnInit() {
    this.bs.boardEvent.subscribe((event) => {
      console.log("EVENT RECIEVED..");
      this.hotkeysHelp = false;
    });
  }

}
