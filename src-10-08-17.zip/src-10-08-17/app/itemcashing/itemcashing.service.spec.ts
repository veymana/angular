import { TestBed, inject } from '@angular/core/testing';

import { ItemcashingService } from './itemcashing.service';

describe('ItemcashingService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ItemcashingService]
    });
  });

  it('should ...', inject([ItemcashingService], (service: ItemcashingService) => {
    expect(service).toBeTruthy();
  }));
});
