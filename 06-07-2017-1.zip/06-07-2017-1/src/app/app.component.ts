import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
 
 tv2Display: boolean=false;

  displayTv2(){
    this.tv2Display=true;
  }
offTv2(){
    this.tv2Display=false;
  }
  onTv2Close(agreed: boolean) {
     this.tv2Display=false;
  }
    registerHotKey($event) {

      console.log("APP Component:"+$event.keyCode);
        if (($event.keyCode == 116 ||$event.keyCode == 84) && $event.altKey){
            $event.stopPropagation();
            $event.preventDefault();

            if(this.tv2Display){
            this.tv2Display=false;
            }
            else{
              this.tv2Display=true;
            }

        }
   } 

}
