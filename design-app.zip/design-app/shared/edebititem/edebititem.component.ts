
import { Component, OnInit, Input } from '@angular/core';
import { AuthorizedAccount } from '../models/authorized-acct.model';
import { EDebitItem } from '../models/edebit-item.model';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { EDebitValidator } from './edebititem.validator';
@Component({
  selector: 'edebit-item',
  templateUrl: './edebititem.component.html',
  styleUrls: ['./edebititem.component.scss']
})
export class EdebititemComponent implements OnInit {

  @Input("itemModel") eDebitItem: EDebitItem;
  @Input("serial") serial: number;

  showDetails: boolean = false;
  form = new FormGroup({
    amount: new FormControl('', [Validators.required, Validators.minLength(5)]),
    item: new FormControl('', [EDebitValidator.invalidItem]),

  });

  get amount() {
    return this.form.get('amount');
  }

  get item() {
    return this.form.get('item');
  }

  ngOnInit() {
  }

  toggleDetails() {
    this.showDetails = !this.showDetails;
  }


}
