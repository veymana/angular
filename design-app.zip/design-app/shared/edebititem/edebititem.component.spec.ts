import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EdebititemComponent } from './edebititem.component';

describe('EdebititemComponent', () => {
  let component: EdebititemComponent;
  let fixture: ComponentFixture<EdebititemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EdebititemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EdebititemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
