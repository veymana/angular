

import { Component, OnInit, Input } from '@angular/core';
import { LessCashItem } from '../models/lcash-item.model'

@Component({
  selector: 'lcash-item',
  templateUrl: './lcashitem.component.html',
  styleUrls: ['./lcashitem.component.scss']
})
export class LcashitemComponent implements OnInit {

  @Input("itemModel") lessCashItem: LessCashItem;
  @Input("serial") serial: number;

  constructor() { }

  ngOnInit() {
  }

}
