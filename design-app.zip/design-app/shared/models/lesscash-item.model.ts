

export class LessCash {
    id: number;
    valid: boolean;
    amount: number;
    status: string;
  }

