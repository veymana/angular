

export interface Account {
    accountNumber: number;
    productName: string;
    openDate: string;
    status: string;
    custRel: string;
    transAuth: string;
    ledgerBalance: number;
    lob: string;
}

