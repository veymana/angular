import { BaseDebitItem } from './base-debit-item';
import { AuthorizedAccount } from './authorized-acct.model';
import { BoardItem } from './board-item.model';

export class EDebitItem implements BoardItem {

    debitIcon: string;
    statusIcon: string;
    amount: number;
    itemType: string;
    constructor(public authorizedAccounts: AuthorizedAccount[]) {
        this.debitIcon = "assets/images/check_on.png";
        this.statusIcon = "assets/images/check-error.png";
        this.amount = 0.00;
        this.itemType = "EDEBIT"
    }
}