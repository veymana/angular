import { Component, OnInit, Input } from '@angular/core';
import { MenubarModule, MenuItem } from 'primeng/primeng';
import { ItemCashingService } from '../../itemcashing/itemcashing.service'

@Component({
  selector: 'blank-board',
  templateUrl: './blankboard.component.html',
  styleUrls: ['./blankboard.component.scss']
})
export class BlankboardComponent implements OnInit {

  @Input() displayBoard: boolean = false;
  dlgWidth: number;
  dlgHeight: number;
  items: MenuItem[];
  hostUpdateDlg: boolean = true;

  constructor(private icService: ItemCashingService) {
    this.dlgWidth = window.screen.width - 20;
    this.dlgHeight = window.screen.height - 10;
    this.items = icService.getMenuItems();
  }
  ngOnInit() {
  }

}
