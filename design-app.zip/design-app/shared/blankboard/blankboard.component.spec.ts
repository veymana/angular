import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BlankboardComponent } from './blankboard.component';

describe('BlankboardComponent', () => {
  let component: BlankboardComponent;
  let fixture: ComponentFixture<BlankboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BlankboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BlankboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
