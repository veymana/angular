
import {Injectable} from '@angular/core';
import {Http, Response} from '@angular/http';
import {Account} from './account.model';
import 'rxjs/add/operator/map';
    
@Injectable()
export class Tv2Service {
    
    accounts;
    items;

    constructor(private http: Http) {}

    getAccounts() {
        return this.http.get('./data/accounts.json')
        .map((res:Response) => <Account[]> res.json());
    }


  getCustProfile() {
        return this.http.get('http://10.92.99.115:8080/SVTRest/customer/getCustomer?ecn=1')
        .map((res:Response) => res.json());
    }

getCusProfileTemp(){

    this.http.get('http://10.92.99.115:8080/SVTRest/customer/getCustomer?ecn=1').subscribe(data => {
     console.log(data);
     },
err => {
      console.log('Something went wrong!');
   
 });  
}


 getMockAccounts(){

   this.accounts= [
               {accountNumber:4342342424,lob:"",productName:"Wells Fargo Platinum Savings",
                openDate : "07/29/16",status:"Active",custRel:"Sole Owner",transAuth:"Yes",
                ledgerBalance:"$12,3444,12"},
                {accountNumber:7686234224,lob:"",productName:"Wells Fargo Preferred Checking ",
                openDate : "07/29/16",status:"Active",custRel:"Sole Owner",transAuth:"Yes",
                ledgerBalance:"$12,3444,12"},
                {accountNumber:12342342424,lob:"",productName:"Wells Fargo Teen Checking",
                openDate : "07/29/16",status:"Active",custRel:"Sole Owner",transAuth:"Yes",
                ledgerBalance:"$12,3444,12"},
                {accountNumber:75686234224,lob:"",productName:"Wells Fargo Platinum Savings",
                openDate : "07/29/16",status:"Active",custRel:"Sole Owner",transAuth:"Yes",
                ledgerBalance:"$12,3444,12"},
                {accountNumber:4382342424,lob:"",productName:"Wells Fargo Platinum Savings",
                openDate : "07/29/16",status:"Active",custRel:"Sole Owner",transAuth:"Yes",
                ledgerBalance:"$12,3444,12"},
                {accountNumber:76786234224,lob:"",productName:"Wells Fargo Platinum Savings",
                openDate : "07/29/16",status:"Active",custRel:"Sole Owner",transAuth:"Yes",
                ledgerBalance:"$12,3444,12"},
                {accountNumber:4342342424,lob:"",productName:"Wells Fargo Platinum Savings",
                openDate : "07/29/16",status:"Active",custRel:"Sole Owner",transAuth:"Yes",
                ledgerBalance:"$12,3444,12"},
                {accountNumber:7686234224,lob:"",productName:"Wells Fargo Preferred Checking ",
                openDate : "07/29/16",status:"Active",custRel:"Sole Owner",transAuth:"Yes",
                ledgerBalance:"$12,3444,12"},
                {accountNumber:12342342424,lob:"",productName:"Wells Fargo Teen Checking",
                openDate : "07/29/16",status:"Active",custRel:"Sole Owner",transAuth:"Yes",
                ledgerBalance:"$12,3444,12"}
       ]

   return this.accounts;
  }

getMenuItems(){
       this.items = [
                            {
                                label: 'Selected',
                                items: [
                                    {label: 'Open/Inquire'},
                                    {label: 'Converted Acct'},
                                    {label: 'Account Signatures'},
                                    {label: 'Clear Customer Information'}  
                                ]
                            },
                            {
                                label: 'Services',
                                items: [
                                    {label: 'Validate PIN',command: (event) =>{
                                    console.log(event.originalEvent);
                                }},
                                    {label: 'Select PIN'},
                                    {label: 'Foreign Exchange Rates'},
                                    {label: 'Customer/Acct Locator'},
                                    {label: 'Wire Transfers'},
                                    {label: 'Holds'}
                                ]
                            },
                            {
                                label: 'Administration',
                                items: [
                                    {label: 'Signoff'},
                                    {label: 'Goto Next Day'},
                                    {label: 'Host Userid & password'},
                                    {label: 'Code of the Day'},
                                    {label: 'Branch Profile'},
                                    {label: 'User Profiles'},
                                    {label: 'Vault Limits'},
                                     {label: 'Close Store'},
                                    {label: 'Force Signoff'}
                                ]
                            },
                            {
                                label: 'Customer Session',
                                items: [
                                        {label: 'Swipe Card'},
                                    {label: 'Cardless PIN'},
                                    {label: 'Find Customer'},
                                    {label: 'End Session'},
                                    {label: 'Solutions'}
                                ]
                            },
                            {
                                label: 'Window',
                                items: [
                            {label: 'Cashbox'},
                                    {label: '1 <window>'},
                                    {label: '2 <window> '},
                                    
                                ]
                            }
        ];
return this.items;
}

}