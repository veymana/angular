import { Injectable } from '@angular/core';
import { AuthorizedAccount } from '../shared/models/authorized-acct.model';

@Injectable()
export class ItemCashingService {

  items;

  constructor() { }

  getMockAuthorizedAccounts(): AuthorizedAccount[] {

    return [{
      accountNumber: 98563257415,
      productName: 'Wells Fargo Preferred Checking',
      balance: "$76,86,23"
    },
    {
      accountNumber: 4562875225,
      productName: 'Wells Fargo Preferred Checking',
      balance: "$76,86,23"
    }
    ];
  }

  getMenuItems() {
    this.items = [
      {
        label: '4Sales',
        items: [
          { label: 'Sales Items' },

          { label: 'Sales Items' }
        ]
      },
      {
        label: '5Misc$',
        items: [
          {
            label: 'Misc$ Items', command: (event) => {
              console.log(event.originalEvent);
            }
          },
          { label: 'Misc$ Items' },

          { label: 'Misc$ Items' }
        ]
      },
      {
        label: '6Admin',
        items: [
          { label: 'Admin Items' },

          { label: 'Admin Items' }
        ]
      },
      {
        label: '7Non-Dollar',
        items: [
          { label: 'NON-Dollar Items' },
          { label: 'NON-Dollar Items' },
          { label: 'NON-Dollar Items' },
          { label: 'NON-Dollar Items ' }
        ]
      },
      {
        label: '8Desktop',

      },
      {
        label: '9Customer Session',
        items: [

          { label: 'Customer Session' }
        ]
      }
    ];
    return this.items;
  }
}
