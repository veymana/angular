import { Component,Input } from '@angular/core';
import {MenubarModule,MenuItem} from 'primeng/primeng';

@Component({
  selector: 'cashbox-app',
   host: {'(window:keydown)': 'hotkeys($event)'},
  templateUrl: 'cashbox.component.html',
  styleUrls: ['cashbox.component.css']
})
export class CashBoxComponent {
 
       title = 'Store Vision Teller';
       display: boolean=false; 
        pinSelect:boolean=false;
        accounts;
       items: MenuItem[];
       msgs = [{severity:'info', summary:'', detail:'PIN updated'}];
       pinMsgs = [{severity:'info', summary:'', detail:'Verify that customer knows current PIN and click OK to start PIN Pad'}];
        openTV2() {
            console.log("Open TV2 .......");
            this.display = true;
        }

        hotkeys($event) {
                if (($event.keyCode == 116 ||$event.keyCode == 84) && $event.altKey){
                    $event.preventDefault();
                    this.display=true;
                }
        } 

   ngOnInit() {

   this.accounts= [
      
                {account:"1342342424",lob:"",product:"Wells Fargo Platinum Savings",open : "07/29/16",status:"Active",custRel:"Sole Owner",transAuth:"Yes",
            ledgerBalance:"$12,3444,12"},
                
                {account:"2342342424",lob:"",product:"Wells Fargo Platinum Savings",open : "07/29/16",status:"Active",custRel:"Sole Owner",transAuth:"Yes",
            ledgerBalance:"$12,3444,12"},

                {account:"3342342424",lob:"",product:"Wells Fargo Platinum Savings",open : "07/29/16",status:"Active",custRel:"Sole Owner",transAuth:"Yes",
            ledgerBalance:"$12,3444,12"},

                {account:"4342342424",lob:"",product:"Wells Fargo Platinum Savings",open : "07/29/16",status:"Active",custRel:"Sole Owner",transAuth:"Yes",
            ledgerBalance:"$12,3444,12"},
       ]


        this.items =  [
                            {
                                label: '<u>S</u>elected',
                                items: [
                                    {label: '<u>S</u>elect PIN'},
                                    {label: 'PINPAD View'},
                                    {label: 'Reset PINPAD'},
                                    {label: 'Express Send '}  
                                ]
                            },
                            {
                                label: 'Services',
                                items: [
                                    {label: 'Select PIN',command: (event) =>{
                                    console.log(event.originalEvent);
                                    console.log(event.item);
                                    this.pinSelect=true;
                                }},
                                    {label: 'PINPAD View'},
                                    {label: 'Reset PINPAD'},
                                    {label: 'Express Send '}
                                ]
                            },
                            {
                                label: 'Administration',
                                items: [
                                    {label: 'Select PIN'},
                                    {label: 'PINPAD View'},
                                    {label: 'Reset PINPAD'},
                                    {label: 'Express Send '}
                                ]
                            },
                            {
                                label: 'Customer Session',
                                items: [
                                        {label: 'Select PIN'},
                                    {label: 'PINPAD View'},
                                    {label: 'Reset PINPAD'},
                                    {label: 'Express Send '}
                                ]
                            },
                            {
                                label: 'Customer Session',
                                items: [
                            {label: 'Select PIN'},
                                    {label: 'PINPAD View'},
                                    {label: 'Reset PINPAD'},
                                    {label: 'Express Send '}
                                ]
                            }
        ];
    }

}
