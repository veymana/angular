'use strict';
module.exports = /<!--([\s\S]*?)-->/g;
