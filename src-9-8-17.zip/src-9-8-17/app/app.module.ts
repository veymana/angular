import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';

import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MenubarModule, MenuItem } from 'primeng/primeng';
import { CheckboxModule } from 'primeng/primeng';
import { DataTableModule, SharedModule } from 'primeng/primeng';
import { ButtonModule } from 'primeng/primeng';
import { DialogModule } from 'primeng/primeng';
import { OverlayPanelModule } from 'primeng/primeng';
import { FieldsetModule } from 'primeng/primeng';
import { MessagesModule } from 'primeng/primeng';
import { TabViewModule } from 'primeng/primeng';
import { Tv2Component } from './tv2/tv2.component';
import { Tv2Service } from './tv2/tv2.service';
import { OrderListModule } from 'primeng/primeng';
import { Routes, RouterModule } from '@angular/router';
import { EwithdrawalComponent } from './itemcashing/ewithdrawal/ewithdrawal.component'
import { BoardTransactionComponent } from './shared/boardtransaction/boardtransaction.component';
import { EdebititemComponent } from './shared/edebititem/edebititem.component';
import { BlankboardComponent } from './shared/blankboard/blankboard.component';

import { LcashitemComponent } from './shared/lcashitem/lcashitem.component';
import { routes } from './itemcashing/itemcashing.routes'
import { ItemCashingService } from './itemcashing/itemcashing.service'

import { SummaryComponent } from './shared/summary/summary.component';
import { ReactiveFormsModule } from '@angular/forms'
import { BoardService } from './shared/board.service'


@NgModule({
  declarations: [
    AppComponent,
    Tv2Component,
    BoardTransactionComponent,
    EdebititemComponent,
    LcashitemComponent,
    EwithdrawalComponent,
    BlankboardComponent,
    SummaryComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    MenubarModule,
    CheckboxModule,
    DataTableModule,
    SharedModule,
    ButtonModule,
    DialogModule,
    BrowserAnimationsModule,
    OverlayPanelModule,
    FieldsetModule,
    MessagesModule,
    TabViewModule,
    OrderListModule,
    RouterModule.forRoot(routes),
    ReactiveFormsModule
  ],
  providers: [Tv2Service, ItemCashingService, BoardService],
  bootstrap: [AppComponent]
})
export class AppModule { }
