import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LcashitemComponent } from './lcashitem.component';

describe('LcashitemComponent', () => {
  let component: LcashitemComponent;
  let fixture: ComponentFixture<LcashitemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LcashitemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LcashitemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
