
export class BoardEvent {



}
