

export interface BaseDebitItem {

}