import { BoardItem } from './boarditem.model'
export class PaperItem implements BoardItem {

}