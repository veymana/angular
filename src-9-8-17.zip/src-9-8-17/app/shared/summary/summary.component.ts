import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'trnx-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.scss']
})
export class SummaryComponent implements OnInit {

  constructor() { }
  @Input("summary") summaryDlg: boolean = false;
  ngOnInit() {
  }

}
