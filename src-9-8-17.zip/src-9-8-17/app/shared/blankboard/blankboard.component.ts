import { Component, OnInit, Input } from '@angular/core';
import { MenubarModule, MenuItem } from 'primeng/primeng';
import { ItemCashingService } from '../../itemcashing/itemcashing.service'
import { BoardService } from '../../shared/board.service';

@Component({
  selector: 'blank-board',
  templateUrl: './blankboard.component.html',
  styleUrls: ['./blankboard.component.scss']
})
export class BlankboardComponent implements OnInit {

  @Input() displayBoard: boolean = false;
  dlgWidth: number;
  dlgHeight: number = 1200;
  items: MenuItem[];
  hostUpdateDlg: boolean = true;
  hotkeysHelp: boolean = true;

  constructor(private icService: ItemCashingService, private bs: BoardService) {
    this.dlgWidth = window.screen.width - 20;
    this.items = icService.getMenuItems();
  }
  ngOnInit() {
    this.bs.boardEvent.subscribe((event) => {
      console.log("EVENT RECIEVED..");
      this.hotkeysHelp = false;
    });
  }

}
