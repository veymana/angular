import { Routes, RouterModule } from '@angular/router';
import { EwithdrawalComponent } from './ewithdrawal/ewithdrawal.component';

export const routes: Routes = [
    {
        path: 'ewidthdrawal',
        component: EwithdrawalComponent,
    }
];