import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EwithdrawalComponent } from './ewithdrawal.component';

describe('EwithdrawalComponent', () => {
  let component: EwithdrawalComponent;
  let fixture: ComponentFixture<EwithdrawalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EwithdrawalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EwithdrawalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
