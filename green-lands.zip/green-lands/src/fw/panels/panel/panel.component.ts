import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'fw-panel',
  templateUrl: './panel.component.html',
  styleUrls: ['./panel.component.css']
})
export class PanelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
