import { GreenLandsPage } from './app.po';

describe('green-lands App', () => {
  let page: GreenLandsPage;

  beforeEach(() => {
    page = new GreenLandsPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
