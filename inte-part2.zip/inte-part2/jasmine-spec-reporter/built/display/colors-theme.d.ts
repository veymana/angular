interface String {
    successful: String;
    failed: String;
    pending: String;
}
