"use strict";
var Configuration = (function () {
    function Configuration() {
    }
    return Configuration;
}());
exports.Configuration = Configuration;
//# sourceMappingURL=configuration.js.map