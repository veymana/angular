import { Component,Input,Output,EventEmitter } from '@angular/core';
import {MenubarModule,MenuItem} from 'primeng/primeng';
import {CheckboxModule} from 'primeng/primeng';
import {DataTableModule,SharedModule} from 'primeng/primeng';
import {ButtonModule} from 'primeng/primeng';
import {DialogModule} from 'primeng/primeng';
import {OverlayPanelModule} from 'primeng/primeng';
import {FieldsetModule} from 'primeng/primeng';
import {MessagesModule} from 'primeng/primeng';
import {TabViewModule} from 'primeng/primeng';

@Component({
  selector: 'item-cashing-ewithdrawal',
  templateUrl: 'item-cashing.component.html',
  styleUrls: ['item-cashing.component.css']
})
export class ItemCashingEWithdrawalComponent {
    title = 'Store Vision Teller';
    items: MenuItem[];
    selectedValues: string[] = [];
    accounts;
    @Input()
    display=true; 
    @Output() onItemCashingClose = new EventEmitter<boolean>();
    @Output() onTv2Close = new EventEmitter<boolean>();
   
 
  pinSelect:boolean=false;
  selectedAccount: Account;

  tab1Display: string="none";
  tab2Display: string="block";
  hostUpdateDlg: boolean=false;
  submitEnabled:boolean=true;
  submitTitle: string="Submit";
  hostStatus: string="none";
  transState: string="construct";
  summaryDlg: boolean=false;
  lessCashAmt: number=65879;
  isBoardGreen: boolean=false;

  tab1Style :string ="transaction_tab_inactive transaction_tab_good_to_go";
  tab2Style :string ="transaction_tab_active transaction_tab_good_to_go";

    showDialog() {
        this.display = true;
    }

    closeSession(){
     
      this.transState="summary";

      this.tab1Style = "transaction_tab_inactive transaction_tab_good_to_go";
      this.tab2Style = "transaction_tab_active transaction_tab_good_to_go";
      this.hostStatus="none";
      this.submitTitle="submitt";

       this.tab2Display="block";
       this.tab1Display="none";

      this.submitEnabled=true;
      this.summaryDlg=false;
      this.onItemCashingClose.emit(false); 
    }
 
 submitHost(){

        if("conclude"===this.transState){
          this.summaryDlg=true;
          this.transState="summary";
          return;
        }
      this.hostUpdateDlg=true;
      //Prototype purpose only
      setTimeout(() => {
            this.hostUpdateDlg=false;
            this.submitEnabled=false;
            this.submitTitle="Complete";
            this.hostStatus="block";
            this.transState="conclude";
          }, 1000);
 }
 onTv2CloseHandle(agreed: boolean) {
     this.display=false;
  }

  closeTv2(){
      this.onTv2Close.emit(false); 
  }

 continueNextTab(){
   this.tab2Display="none";
   this.tab1Display="block";
   this.tab1Style  ="transaction_tab_active transaction_tab_good_to_go";
   this.tab2Style  ="transaction_tab_inactive transaction_tab_good_to_go";

      this.submitEnabled=false;

      this.transState="collect";
      this.isBoardGreen=true;
 }

   registerHotKey($event) {

         if ($event.keyCode == 35 && "summary"==this.transState){
             this.closeSession();
          }
     if ($event.keyCode == 13 && "collect"==this.transState){
             this.submitHost();
          }
      if ($event.keyCode == 13 && "conclude"==this.transState && this.isBoardGreen){
             this.submitHost();
          }

        if (($event.keyCode == 116 ||$event.keyCode == 84) && $event.altKey){
           // $event.stopPropagation();
          //  $event.preventDefault();

            if(this.display){
            //this.display=false;
            }
            else{
             /// this.display=true;
            }

        }
   } 
    
    msgs = [{severity:'info', summary:'', detail:'PIN updated'}];
    pinMsgs = [{severity:'info', summary:'', detail:'Verify that customer knows current PIN and click OK to start PIN Pad'}];



}
