import { Component,Input,Output,EventEmitter } from '@angular/core';
import {MenubarModule,MenuItem} from 'primeng/primeng';
import {CheckboxModule} from 'primeng/primeng';
import {DataTableModule,SharedModule} from 'primeng/primeng';
import {ButtonModule} from 'primeng/primeng';
import {DialogModule} from 'primeng/primeng';
import {OverlayPanelModule} from 'primeng/primeng';
import {FieldsetModule} from 'primeng/primeng';
import {MessagesModule} from 'primeng/primeng';
import {TabViewModule} from 'primeng/primeng';
import {Tv2Service} from './tv2.service';

@Component({
  selector: 'tv2-app',
  templateUrl: 'tv2.component.html',
  styleUrls: ['tv2.component.css']
})
export class Tv2Component {
    title = 'Store Vision Teller';
    items: MenuItem[];
    selectedValues: string[] = [];
    accounts;
    
    @Output() onCbClose = new EventEmitter<boolean>();
     
    cbDisplay=false; 
    tv2Display=true;
    
   constructor(private tv2Service:Tv2Service) {
     this.accounts= tv2Service.getMockAccounts();
     this.items= this.getMenuItems();
    }
 
   pinSelect:boolean=false;
   selectedAccount: Account;
   pinpadStatus: string="eWithdrawal Ready";

    showCbDialog() {
        this.cbDisplay = true;
        this.pinpadStatus = "Customer waiting"
    }

onItemCashingCloseHandle(status: boolean){
    this.cbDisplay=false;
   this.pinpadStatus = "eWithdrawal Ready";
}
   registerHotKey($event) {
        console.log("TV2 Component:"+$event.keyCode);
        if (($event.keyCode == 116 ||$event.keyCode == 84) && $event.altKey){
            $event.stopPropagation();
            $event.preventDefault();

            if(this.cbDisplay){
            this.cbDisplay=false;
            }
            else{
              this.cbDisplay=true;
            }

        }
   } 
    
    msgs = [{severity:'info', summary:'', detail:'PIN updated'}];
    pinMsgs = [{severity:'info', summary:'', detail:'Verify that customer knows current PIN and click OK to start PIN Pad'}];

getMenuItems(){
       this.items = [
                            {
                                label: 'Selected',
                                items: [
                                    {label: 'Select PIN'},
                                    {label: 'PINPAD View'},
                                    {label: 'Reset PINPAD'},
                                    {label: 'Express Send '}  
                                ]
                            },
                            {
                                label: 'Services',
                                items: [
                                    {label: 'Select PIN',command: (event) =>{
                                    this.pinSelect=true;
                                }},
                                    {label: 'PINPAD View'},
                                    {label: 'Reset PINPAD'},
                                    {label: 'Express Send '}
                                ]
                            },
                            {
                                label: 'Administration',
                                items: [
                                    {label: 'Select PIN'},
                                    {label: 'PINPAD View'},
                                    {label: 'Reset PINPAD'},
                                    {label: 'Express Send '}
                                ]
                            },
                            {
                                label: 'Customer Session',
                                items: [
                                        {label: 'Select PIN'},
                                    {label: 'PINPAD View'},
                                    {label: 'Reset PINPAD'},
                                    {label: 'Express Send '}
                                ]
                            },
                            {
                                label: 'Customer Session',
                                items: [
                            {label: 'Select PIN'},
                                    {label: 'PINPAD View'},
                                    {label: 'Reset PINPAD'},
                                    {label: 'Express Send '}
                                ]
                            }
        ];
return this.items;
}

}
