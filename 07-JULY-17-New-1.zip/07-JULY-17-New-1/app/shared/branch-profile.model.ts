

export class BranchProfile {
  id: number;
  type:string;
  branchCode:string;
  
}