

export class CustomerSession {
  id: number;
  type:string;
  branchCode:string;
  
}