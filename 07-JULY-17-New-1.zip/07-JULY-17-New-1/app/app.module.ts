import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';

import { FormsModule } from '@angular/forms';
import {HttpModule} from '@angular/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MenubarModule,MenuItem} from 'primeng/primeng';
import {CheckboxModule} from 'primeng/primeng';
import {DataTableModule,SharedModule} from 'primeng/primeng';
import {ButtonModule} from 'primeng/primeng';
import {DialogModule} from 'primeng/primeng';
import {OverlayPanelModule} from 'primeng/primeng';
import {FieldsetModule} from 'primeng/primeng';
import {MessagesModule} from 'primeng/primeng';
import {TabViewModule} from 'primeng/primeng';
import {Tv2Component} from './tv2/tv2.component';
import {CashboxComponent} from './cashbox/cashbox.component';
import {Tv2Service} from './tv2/tv2.service';
import {CashboxService} from './cashbox/cashbox.service';
import {ItemCashingEWithdrawalComponent} from './cashbox/item-cashing-ewithdraw/item-cashing.component' ;


@NgModule({
  declarations: [
    AppComponent,
    Tv2Component,
    CashboxComponent,
    ItemCashingEWithdrawalComponent
    ],
  imports: [
    BrowserModule,
    FormsModule ,
    HttpModule,
    MenubarModule,
    CheckboxModule,
    DataTableModule,
    SharedModule,
    ButtonModule,
    DialogModule,
    BrowserAnimationsModule,
    OverlayPanelModule,
    FieldsetModule,
    MessagesModule,
    TabViewModule
  ],
  providers: [Tv2Service,CashboxService],
  bootstrap: [AppComponent]
})
export class AppModule { }
