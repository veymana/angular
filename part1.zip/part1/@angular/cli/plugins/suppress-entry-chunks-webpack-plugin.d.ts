export declare class SuppressExtractedTextChunksWebpackPlugin {
    constructor();
    apply(compiler: any): void;
}
