export declare function requireProjectModule(root: string, moduleName: string): any;
