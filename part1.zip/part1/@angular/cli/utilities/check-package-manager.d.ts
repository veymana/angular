export declare function checkYarnOrCNPM(): Promise<void>;
